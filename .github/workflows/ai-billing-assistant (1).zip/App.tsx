
import React, { useState, useEffect } from 'react';
import type { Invoice, Product, Customer, BillSettings, Vendor, StaffMember, Expense, UserInfo, PurchaseBill } from './types.ts';
import { useLocalStorage } from './hooks/useLocalStorage.ts';
import Header from './components/Header.tsx';
import Sidebar from './components/Sidebar.tsx';
import Dashboard from './components/Dashboard.tsx';
import InventoryPage from './components/InventoryPage.tsx';
import BillingPage from './components/BillingPage.tsx';
import CustomersPage from './components/CustomersPage.tsx';
import VendorsPage from './components/VendorsPage.tsx';
import StaffPage from './components/StaffPage.tsx';
import ExpensesPage from './components/ExpensesPage.tsx';
import SettingsPage from './components/SettingsPage.tsx';
import LockScreenModal from './components/modals/LockScreenModal.tsx';
import ConfirmationModal from './components/modals/ConfirmationModal.tsx';
import { googleApiService } from './services/googleApiService.ts';

// Type definitions for page navigation and theme
export type Page = 'Dashboard' | 'Inventory' | 'Billing' | 'Customers' | 'Vendors' | 'Staff' | 'My Expenses' | 'Settings';
export type Theme = 'light' | 'dark' | 'system';

// Initial seed data for a better first-time user experience
const initialProducts: Product[] = [
  { id: 'prod-1', name: 'Wireless Mouse', salesTrend: 11, purchasePrice: 18.50, salePrice: 25.99, quantity: 33, lowStockAlert: 10 },
  { id: 'prod-2', name: 'Mechanical Keyboard', salesTrend: 2, purchasePrice: 55.00, salePrice: 70.99, quantity: 27, lowStockAlert: 5 },
  { id: 'prod-3', name: '4K Monitor', salesTrend: 2, purchasePrice: 280.00, salePrice: 349.99, quantity: 17, lowStockAlert: 5 },
  { id: 'prod-4', name: 'USB-C Hub', salesTrend: 0, purchasePrice: 30.00, salePrice: 45.50, quantity: 100, lowStockAlert: 20 },
  { id: 'prod-5', name: 'Webcam with Ring Light', salesTrend: 0, purchasePrice: 45.00, salePrice: 65.00, quantity: 40, lowStockAlert: 10 },
  { id: 'prod-6', name: 'HP Pump', salesTrend: 12, purchasePrice: 3200.00, salePrice: 4000.00, quantity: 28, lowStockAlert: 15 },
  { id: 'prod-7', name: 'Water Pump', salesTrend: 4, purchasePrice: 1500.00, salePrice: 2000.00, quantity: 92, lowStockAlert: 25 },
  { id: 'prod-8', name: 'HT Cable', salesTrend: 4, purchasePrice: 350.00, salePrice: 500.00, quantity: 44, lowStockAlert: 10 },
];

const initialCustomers: Customer[] = [
    { id: 'cust-1', name: 'Salman', contactNumbers: ['salman@example.com'], balance: 0, transactions: [], claims: [] },
    { id: 'cust-2', name: 'Zahid', contactNumbers: ['555-1234'], balance: 1250, transactions: [], claims: [] },
    { id: 'cust-3', name: 'Ahmad', contactNumbers: ['ahmad@example.com'], balance: 0, transactions: [], claims: [] },
    { 
        id: 'cust-4', 
        name: 'Islam', 
        contactNumbers: ['03236054731'], 
        balance: 54000.00, 
        transactions: [
             { id: 'tx-claim-1', date: new Date('2025-08-18T10:00:00Z').toISOString(), description: 'Claim Logged: Wt claim', amount: 0, balanceAfter: 54000.00 }
        ], 
        claims: [
            { id: 'claim-1', date: new Date('2025-08-18T10:00:00Z').toISOString(), description: 'Wt claim', amount: 0, status: 'Pending' }
        ] 
    },
];

const initialVendors: Vendor[] = [
    { id: 'vend-1', name: 'Ali Supplies', contactNumbers: ['1244'], bankAccounts: [], balance: 0.00, transactions: [], claims: [] },
];

const initialStaff: StaffMember[] = [
    { id: 'staff-1', name: 'Tahir', contactNumbers: [], monthlySalary: 25000, payments: [] },
];

const initialExpenses: Expense[] = [
    { id: 'exp-1', date: new Date('2025-08-17T12:00:00Z').toISOString(), description: 'Office utilities', amount: 500 },
];

function App() {
  // Local storage backed state for application data
  const [invoices, setInvoices] = useLocalStorage<Invoice[]>('invoices', []);
  const [products, setProducts] = useLocalStorage<Product[]>('products', initialProducts);
  const [customers, setCustomers] = useLocalStorage<Customer[]>('customers', initialCustomers);
  const [vendors, setVendors] = useLocalStorage<Vendor[]>('vendors', initialVendors);
  const [purchaseBills, setPurchaseBills] = useLocalStorage<PurchaseBill[]>('purchaseBills', []);
  const [staff, setStaff] = useLocalStorage<StaffMember[]>('staff', initialStaff);
  const [expenses, setExpenses] = useLocalStorage<Expense[]>('expenses', initialExpenses);
  const [securityCode, setSecurityCode] = useLocalStorage<string>('securityCode', '0000');
  const [theme, setTheme] = useLocalStorage<Theme>('theme', 'system');
  const [billSettings, setBillSettings] = useLocalStorage<BillSettings>('billSettings', {
    width: 6,
    height: 7.5,
    companyName: 'Your Company Name',
    companyLogo: '',
    notes: 'Thank you for your business!',
    autoBackupEnabled: true,
  });
  
  // UI State
  const [activePage, setActivePage] = useState<Page>('Billing');
  const [unlockModal, setUnlockModal] = useState<{ isOpen: boolean; page: Page | null; error: boolean }>({ isOpen: false, page: null, error: false });

  // Cloud Sync State
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null);
  const [lastBackupDate, setLastBackupDate] = useLocalStorage<string | null>('lastBackupDate', null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [restoreConfirm, setRestoreConfirm] = useState<{ open: boolean, data: any | null }>({ open: false, data: null });

  // Check login status on app load
  useEffect(() => {
    const checkStatus = async () => {
      const user = await googleApiService.checkSignInStatus();
      if (user) {
        setUserInfo(user);
        setIsLoggedIn(true);
        const metadata = await googleApiService.getBackupMetadata();
        if (metadata) {
          setLastBackupDate(metadata.modifiedTime);
        }
      }
    };
    checkStatus();
  }, []);

  // Theme management effect
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = () => {
      if (theme === 'system') {
        document.documentElement.classList.toggle('dark', mediaQuery.matches);
      }
    };
    
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else if (theme === 'light') {
      document.documentElement.classList.remove('dark');
    } else {
      document.documentElement.classList.toggle('dark', mediaQuery.matches);
      mediaQuery.addEventListener('change', handleChange);
    }

    return () => mediaQuery.removeEventListener('change', handleChange);
  }, [theme]);
  
  // --- Cloud Sync Handlers ---
  const gatherAppData = () => ({
    invoices, products, customers, vendors, purchaseBills, staff, expenses, billSettings, securityCode
  });

  const handleManualBackup = async () => {
    if (!isLoggedIn) {
      alert("Please log in to back up your data.");
      return;
    }
    setIsSyncing(true);
    try {
      const appData = gatherAppData();
      const metadata = await googleApiService.uploadBackup(appData);
      setLastBackupDate(metadata.modifiedTime);
      alert("Backup successful!");
    } catch (error) {
      console.error("Backup failed:", error);
      alert("Backup failed. Please try again.");
    } finally {
      setIsSyncing(false);
    }
  };

  const applyBackup = (backupData: any) => {
    setInvoices(backupData.invoices || []);
    setProducts(backupData.products || initialProducts);
    setCustomers(backupData.customers || initialCustomers);
    setVendors(backupData.vendors || initialVendors);
    setPurchaseBills(backupData.purchaseBills || []);
    setStaff(backupData.staff || initialStaff);
    setExpenses(backupData.expenses || initialExpenses);
    if (backupData.billSettings) setBillSettings(backupData.billSettings);
    if (backupData.securityCode) setSecurityCode(backupData.securityCode);
    alert("Data restored successfully from Google Drive.");
  };

  const handlePromptRestore = async () => {
    setIsSyncing(true);
    try {
      const backup = await googleApiService.getLatestBackup();
      if (backup) {
        setRestoreConfirm({ open: true, data: backup });
      } else {
        alert("No backup found on Google Drive.");
      }
    } catch (error) {
       console.error("Restore failed:", error);
       alert("Failed to fetch backup. Please try again.");
    } finally {
      setIsSyncing(false);
    }
  };

  const handleLogin = async () => {
    try {
      const user = await googleApiService.signIn();
      setUserInfo(user);
      setIsLoggedIn(true);
      
      const backup = await googleApiService.getLatestBackup();
      if (backup) {
        setRestoreConfirm({ open: true, data: backup });
      }
    } catch (error) {
      console.error("Login failed:", error);
      alert("Google Sign-In failed. Please try again.");
    }
  };

  const handleLogout = async () => {
    await googleApiService.signOut();
    setUserInfo(null);
    setIsLoggedIn(false);
  };
  
  // Auto-backup logic
  useEffect(() => {
    if (isLoggedIn && billSettings.autoBackupEnabled) {
      const ONE_DAY_MS = 24 * 60 * 60 * 1000;
      const now = Date.now();
      const lastBackupTime = lastBackupDate ? new Date(lastBackupDate).getTime() : 0;

      if (now - lastBackupTime > ONE_DAY_MS) {
        console.log("Performing automatic daily backup...");
        handleManualBackup();
      }
    }
  }, [isLoggedIn, lastBackupDate, billSettings.autoBackupEnabled]);


  // --- Page Navigation & Security ---
  const lockedPages: Page[] = ['Dashboard', 'Vendors', 'Staff', 'My Expenses'];

  const handleMenuSelect = (page: Page) => {
    if (lockedPages.includes(page) && activePage !== page) {
      setUnlockModal({ isOpen: true, page: page, error: false });
    } else {
      setActivePage(page);
    }
  };

  const handleUnlockAttempt = (code: string) => {
    if (code === securityCode) {
      if (unlockModal.page) {
        setActivePage(unlockModal.page);
      }
      setUnlockModal({ isOpen: false, page: null, error: false });
    } else {
      setUnlockModal(prev => ({ ...prev, error: true }));
      setTimeout(() => setUnlockModal(prev => ({ ...prev, error: false })), 500);
    }
  };

  // --- Core Business Logic ---
  const handleSaveInvoice = (invoice: Invoice) => {
    // Update or add the invoice
    setInvoices(prevInvoices => {
      const existing = prevInvoices.find(inv => inv.id === invoice.id);
      if (existing) {
        return prevInvoices.map(inv => inv.id === invoice.id ? invoice : inv);
      }
      return [invoice, ...prevInvoices].sort((a, b) => new Date(b.invoiceDate).getTime() - new Date(a.invoiceDate).getTime());
    });

    // Update customer transaction history and balance if applicable
    if (invoice.customerId) {
        setCustomers(prev => prev.map(c => {
            if (c.id === invoice.customerId) {
                // BUG FIX: Correctly calculate the value of the transaction itself.
                // The transaction amount is the new grand total minus any old balance that was part of the calculation.
                const transactionValue = invoice.grandTotal - (invoice.oldBalance ?? 0);
                
                const newTransaction = {
                    id: crypto.randomUUID(),
                    date: invoice.invoiceDate,
                    description: `Invoice #${invoice.invoiceNumber} (${invoice.type})`,
                    amount: transactionValue, // This is the value of the current invoice/transaction
                    balanceAfter: invoice.grandTotal, // The new balance IS the grand total
                    type: 'invoice' as const,
                    relatedId: invoice.id,
                };
                return { ...c, balance: invoice.grandTotal, transactions: [newTransaction, ...c.transactions] };
            }
            return c;
        }));
    }

    // Adjust product quantities in inventory
    setProducts(prevProducts => {
        const updatedProducts = [...prevProducts];
        invoice.items.forEach(item => {
            const productIndex = updatedProducts.findIndex(p => p.id === item.id);
            if (productIndex > -1) {
                if (invoice.type === 'Return / Credit') {
                    updatedProducts[productIndex].quantity += item.quantity;
                } else {
                    updatedProducts[productIndex].quantity -= item.quantity;
                }
            }
        });
        return updatedProducts;
    });
  };
  
  // --- Page Renderer ---
  const renderPage = () => {
    switch (activePage) {
      case 'Dashboard':
        return <Dashboard invoices={invoices} customers={customers} vendors={vendors} staff={staff} expenses={expenses} />;
      case 'Inventory':
        return <InventoryPage products={products} setProducts={setProducts} securityCode={securityCode} />;
      case 'Billing':
        return <BillingPage
                    onSaveInvoice={handleSaveInvoice}
                    products={products}
                    customers={customers}
                    setCustomers={setCustomers}
                    lastInvoiceNumber={invoices[0]?.invoiceNumber}
                    billSettings={billSettings}
                    invoices={invoices}
                />;
      case 'Customers':
        return <CustomersPage customers={customers} setCustomers={setCustomers} products={products} setProducts={setProducts} securityCode={securityCode} invoices={invoices} billSettings={billSettings} />;
      case 'Vendors':
        return <VendorsPage vendors={vendors} setVendors={setVendors} products={products} setProducts={setProducts} purchaseBills={purchaseBills} setPurchaseBills={setPurchaseBills} securityCode={securityCode} />;
      case 'Staff':
        return <StaffPage staff={staff} setStaff={setStaff} billSettings={billSettings} securityCode={securityCode} />;
      case 'My Expenses':
        return <ExpensesPage expenses={expenses} setExpenses={setExpenses} securityCode={securityCode} />;
      case 'Settings':
        return <SettingsPage 
                    settings={billSettings} 
                    setSettings={setBillSettings} 
                    securityCode={securityCode} 
                    setSecurityCode={setSecurityCode} 
                    theme={theme} 
                    setTheme={setTheme}
                    isLoggedIn={isLoggedIn}
                    userInfo={userInfo}
                    lastBackupDate={lastBackupDate}
                    onBackup={handleManualBackup}
                    onRestore={handlePromptRestore}
                    isSyncing={isSyncing}
                />;
      default:
        return (
          <div className="container mx-auto p-8 text-center">
            <h2 className="text-3xl font-bold text-slate-800 dark:text-slate-100 mb-4">{activePage}</h2>
            <p className="text-slate-500 dark:text-slate-400">This feature is not yet implemented.</p>
          </div>
        );
    }
  }

  return (
    <div className="h-screen flex flex-col bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-gray-200 font-sans">
      <Header isLoggedIn={isLoggedIn} userInfo={userInfo} onLogin={handleLogin} onLogout={handleLogout} />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar activeItem={activePage} onSelectItem={handleMenuSelect} />
        <main className="flex-1 overflow-y-auto">
          {renderPage()}
        </main>
      </div>
      <LockScreenModal 
        isOpen={unlockModal.isOpen}
        onClose={() => setUnlockModal({ isOpen: false, page: null, error: false })}
        onUnlock={handleUnlockAttempt}
        pageName={unlockModal.page}
        error={unlockModal.error}
      />
       <ConfirmationModal
        isOpen={restoreConfirm.open}
        onClose={() => setRestoreConfirm({ open: false, data: null })}
        onConfirm={() => {
            if (restoreConfirm.data) applyBackup(restoreConfirm.data);
            setRestoreConfirm({ open: false, data: null });
        }}
        title="Restore from Backup"
        message="A backup was found on your Google Drive. Would you like to restore this data? This will overwrite any data currently on this device."
        confirmButtonText="Yes, Restore"
      />
    </div>
  );
}

export default App;
