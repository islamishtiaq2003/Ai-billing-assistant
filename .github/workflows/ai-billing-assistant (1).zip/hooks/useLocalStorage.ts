import { useState, useEffect } from 'react';

/**
 * A custom React hook that provides a state variable that is persisted to localStorage.
 * It behaves like `useState`, but automatically saves the value to localStorage on change
 * and retrieves it on initialization.
 *
 * @template T The type of the value to be stored.
 * @param {string} key The key to use for storing the value in localStorage.
 * @param {T} initialValue The initial value to use if no value is found in localStorage.
 * @returns {[T, React.Dispatch<React.SetStateAction<T>>]} A tuple containing the stored value and a function to update it.
 */
export function useLocalStorage<T>(key: string, initialValue: T): [T, React.Dispatch<React.SetStateAction<T>>] {
  // Get the initial value from localStorage or use the provided initialValue.
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error(`Error reading localStorage key "${key}":`, error);
      return initialValue;
    }
  });

  // Use useEffect to update localStorage whenever the storedValue changes.
  useEffect(() => {
    try {
      const valueToStore = JSON.stringify(storedValue);
      window.localStorage.setItem(key, valueToStore);
    } catch (error) {
      console.error(`Error setting localStorage key "${key}":`, error);
    }
  }, [key, storedValue]);

  return [storedValue, setStoredValue];
}