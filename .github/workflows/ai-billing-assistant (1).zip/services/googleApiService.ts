import type { UserInfo } from '../types.ts';

const USER_KEY = 'google_user_info';
const BACKUP_KEY = 'google_drive_backup';
const BACKUP_META_KEY = 'google_drive_backup_meta';

// This is a MOCK service to simulate Google Drive and Auth interactions.
// In a real application, this would use the Google API client libraries (gapi, gis).

export const googleApiService = {
  // Simulates the one-tap sign-in or a popup login flow
  signIn: async (): Promise<UserInfo> => {
    // In a real app, this would open a Google login prompt.
    // Here, we'll just create and store a mock user.
    await new Promise(res => setTimeout(res, 500)); // Simulate network delay
    const mockUser: UserInfo = {
      name: 'Test User',
      email: 'test.user@example.com',
      picture: 'https://lh3.googleusercontent.com/a/ACg8ocJ-1234567890abcdefghijklmnopqrstuvwxyz=s96-c',
    };
    localStorage.setItem(USER_KEY, JSON.stringify(mockUser));
    return mockUser;
  },

  // Simulates signing out
  signOut: async (): Promise<void> => {
    localStorage.removeItem(USER_KEY);
    return Promise.resolve();
  },

  // Checks if a user session exists
  checkSignInStatus: async (): Promise<UserInfo | null> => {
    const userJson = localStorage.getItem(USER_KEY);
    return userJson ? JSON.parse(userJson) : null;
  },
  
  // Simulates uploading the app data blob to Google Drive
  uploadBackup: async (appData: object): Promise<{ modifiedTime: string }> => {
     await new Promise(res => setTimeout(res, 1500)); // Simulate upload delay
     const backupData = JSON.stringify(appData);
     localStorage.setItem(BACKUP_KEY, backupData);
     const metadata = { modifiedTime: new Date().toISOString() };
     localStorage.setItem(BACKUP_META_KEY, JSON.stringify(metadata));
     return metadata;
  },

  // Simulates fetching metadata for the latest backup file
  getBackupMetadata: async (): Promise<{ modifiedTime: string } | null> => {
    const metaJson = localStorage.getItem(BACKUP_META_KEY);
    return metaJson ? JSON.parse(metaJson) : null;
  },

  // Simulates downloading and parsing the backup file from Google Drive
  getLatestBackup: async (): Promise<any | null> => {
    await new Promise(res => setTimeout(res, 1000)); // Simulate download delay
    const backupJson = localStorage.getItem(BACKUP_KEY);
    return backupJson ? JSON.parse(backupJson) : null;
  }
};