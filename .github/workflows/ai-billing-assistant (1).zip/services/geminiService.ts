import { GoogleGenAI } from "@google/genai";

// Warn the developer if the API key is not set in the environment.
// AI features will be disabled without it.
if (!process.env.API_KEY) {
  console.warn("API_KEY environment variable not set. AI features will not work.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

/**
 * Generates a brief, professional invoice line item description using the Gemini API.
 * @param prompt - The basic product or service name to generate a description for.
 * @returns A promise that resolves to the generated description string.
 * @throws An error if the API key is not configured or if the API call fails.
 */
export async function generateDescription(prompt: string): Promise<string> {
  if (!process.env.API_KEY) {
    throw new Error("Gemini API key is not configured.");
  }
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Generate a brief, professional, one-sentence invoice line item description for the following product or service. Do not use any markdown or special formatting. The product/service is: "${prompt}"`,
       config: {
        temperature: 0.5,
        topP: 0.95,
        topK: 64,
        maxOutputTokens: 100,
        // Disable thinking for faster, more direct responses for this simple task.
        thinkingConfig: { thinkingBudget: 0 }
       }
    });

    return response.text.trim();
  } catch (error) {
    console.error("Error generating description from Gemini:", error);
    throw new Error("Failed to generate description from AI. Please check your connection and API key.");
  }
}