/**
 * Enum for the possible statuses of an invoice.
 */
export enum InvoiceStatus {
  Draft = 'Draft',
  Paid = 'Paid',
  Overdue = 'Overdue',
}

/**
 * Defines the type of an invoice, affecting calculations and layout.
 */
export type InvoiceType = 'Retail' | 'Wholesale' | 'Return / Credit';

/**
 * Represents a single line item in an invoice or purchase bill.
 */
export interface LineItem {
  id: string; // Corresponds to product ID
  name: string;
  quantity: number;
  price: number;
}

/**
 * Represents a complete invoice document.
 */
export interface Invoice {
  id: string;
  invoiceNumber: string;
  customerName: string;
  customerContact?: string;
  customerId?: string;
  invoiceDate: string;
  dueDate: string;
  items: LineItem[];
  status: InvoiceStatus;
  type: InvoiceType;
  grandTotal: number;
  billDiscount?: number;
  claimCharges?: number;
  oldBalance?: number;
}

/**
 * Represents a bill for items purchased from a vendor.
 */
export interface PurchaseBill {
  id: string;
  vendorId: string;
  date: string;
  items: LineItem[];
  total: number;
}

/**
 * Represents a product in the inventory.
 */
export interface Product {
  id: string;
  name: string;
  salesTrend: number;
  purchasePrice: number;
  salePrice: number;
  quantity: number;
  lowStockAlert: number;
}

/**
 * Represents a financial transaction for a customer or vendor.
 */
export interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number; // Positive for sales/purchases, negative for payments
  balanceAfter: number;
  relatedId?: string; // e.g., invoiceId, purchaseBillId
  type?: 'invoice' | 'purchase' | 'payment' | 'claim' | 'opening_balance' | 'adjustment';
}

/**
 * Represents a warranty claim by a customer or to a vendor.
 */
export interface Claim {
  id: string;
  date: string;
  description: string;
  amount: number;
  status: 'Pending' | 'Resolved';
}

/**
 * Represents a customer of the business.
 */
export interface Customer {
    id: string;
    name: string;
    contactNumbers: string[];
    balance: number;
    transactions: Transaction[];
    claims: Claim[];
}

/**
 * Represents a vendor or supplier to the business.
 */
export interface Vendor {
    id: string;
    name: string;
    contactNumbers: string[];
    bankAccounts: string[];
    balance: number; // Money owed to the vendor
    transactions: Transaction[];
    claims: Claim[];
}

/**
 * Defines the type of payment made to a staff member.
 */
export type StaffPaymentType = 'Salary' | 'Advance';

/**
 * Represents a single payment made to a staff member.
 */
export interface StaffPayment {
  id: string;
  date: string;
  type: StaffPaymentType;
  amount: number;
  notes?: string;
}

/**
 * Represents a staff member of the business.
 */
export interface StaffMember {
  id: string;
  name: string;
  contactNumbers: string[];
  monthlySalary: number;
  payments: StaffPayment[];
}

/**
 * Represents a general business expense.
 */
export interface Expense {
  id: string;
  date: string;
  description: string;
  amount: number;
}

/**
 * Represents the logged-in user's information.
 */
export interface UserInfo {
    name: string;
    email: string;
    picture: string;
}

/**
 * Represents the settings for invoice customization and printing.
 */
export interface BillSettings {
    width: number; // in inches
    height: number; // in inches
    companyName?: string;
    companyLogo?: string; // base64 string
    notes?: string;
    autoBackupEnabled?: boolean;
}
