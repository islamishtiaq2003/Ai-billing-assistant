import React, { useState, useMemo } from 'react';
import type { Product } from '../types.ts';
import PlusIcon from './icons/PlusIcon.tsx';
import SearchIcon from './icons/SearchIcon.tsx';
import PencilIcon from './icons/PencilIcon.tsx';
import TrashIcon from './icons/TrashIcon.tsx';
import ExclamationTriangleIcon from './icons/ExclamationTriangleIcon.tsx';
import ProductFormModal from './ProductFormModal.tsx';
import ConfirmationModal from './modals/ConfirmationModal.tsx';

interface InventoryPageProps {
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  securityCode: string;
}

const inventoryTableHeaders: { key: string, label: string, align: 'left' | 'right' | 'center' }[] = [
    { key: 'name', label: 'Name', align: 'left' },
    { key: 'salesTrend', label: 'Sales Trend', align: 'right' },
    { key: 'salePriceFormatted', label: 'Price', align: 'right' },
    { key: 'status', label: 'Stock Status', align: 'center' },
    { key: 'quantity', label: 'Quantity', align: 'right' },
    { key: 'actions', label: 'Actions', align: 'center' },
];


const InventoryPage: React.FC<InventoryPageProps> = ({ products, setProducts, securityCode }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [productToEdit, setProductToEdit] = useState<Product | null>(null);
  const [itemToDelete, setItemToDelete] = useState<string | null>(null);

  const filteredProducts = useMemo(() => {
    if (!products) return [];
    return products.filter(product =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase())
    ).sort((a,b) => a.name.localeCompare(b.name));
  }, [products, searchTerm]);

  const lowStockItems = useMemo(() => {
    if (!products) return [];
    return products.filter(p => p.quantity <= p.lowStockAlert);
  }, [products]);

  const handleAddProduct = () => {
    setProductToEdit(null);
    setIsModalOpen(true);
  };

  const handleEditProduct = (product: Product) => {
    setProductToEdit(product);
    setIsModalOpen(true);
  };

  const handleDeleteProduct = (id: string) => {
    setItemToDelete(id);
  };
  
  const confirmDeleteProduct = () => {
    if (!itemToDelete) return;
    setProducts(prevProducts => prevProducts.filter(p => p.id !== itemToDelete));
    setItemToDelete(null);
  };

  const handleSaveProduct = (product: Product) => {
    setProducts(prev => {
      const exists = prev.some(p => p.id === product.id);
      if (exists) {
        return prev.map(p => p.id === product.id ? product : p);
      }
      return [...prev, product];
    });
    setIsModalOpen(false);
  };

  const getStockStatus = (product: Product) => {
    if (product.quantity <= 0) return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300">Out of Stock</span>;
    if (product.quantity <= product.lowStockAlert) return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300">Low Stock</span>;
    return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">In Stock</span>;
  };

  return (
    <div className="container mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
      <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-100">Inventory</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        <div className="lg:col-span-2 bg-white dark:bg-gray-900 p-6 rounded-xl border border-gray-200 dark:border-gray-800 shadow-sm">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-4">
            <div>
              <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100">Product Inventory</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400">View, manage, and organize your products.</p>
            </div>
            <div className="flex items-center space-x-2 w-full sm:w-auto">
              <div className="relative flex-grow">
                <SearchIcon className="h-5 w-5 text-gray-400 absolute top-1/2 left-3 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search products..."
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 w-full border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 focus:ring-2 focus:ring-primary-500 focus:outline-none"
                  aria-label="Search products"
                />
              </div>
              <button onClick={handleAddProduct} className="flex items-center space-x-2 px-3 py-2 text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 whitespace-nowrap" aria-label="Add new product">
                <PlusIcon className="h-5 w-5" />
                <span className="hidden sm:inline">Add Product</span>
              </button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
              <thead className="bg-gray-50 dark:bg-gray-800">
                <tr>
                  {inventoryTableHeaders.map(header => (
                     <th key={header.key} scope="col" className={`px-6 py-3 text-${header.align} text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider`}>{header.label}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
                {filteredProducts.map(product => (
                  <tr key={product.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-left font-medium text-gray-900 dark:text-gray-100">{product.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-500 dark:text-gray-400">{product.salesTrend}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-500 dark:text-gray-400">Rs.{product.salePrice.toFixed(2)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-center">{getStockStatus(product)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-500 dark:text-gray-400">{product.quantity}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-center space-x-2">
                      <button onClick={() => handleEditProduct(product)} className="p-1 text-gray-400 hover:text-primary-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500" aria-label={`Edit ${product.name}`}>
                          <PencilIcon className="h-5 w-5" />
                      </button>
                      <button onClick={() => handleDeleteProduct(product.id)} className="p-1 text-gray-400 hover:text-red-600 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500" aria-label={`Delete ${product.name}`}>
                          <TrashIcon className="h-5 w-5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
             {filteredProducts.length === 0 && (
                <div className="text-center py-10">
                    <p className="text-gray-500 dark:text-gray-400">No products found.</p>
                </div>
            )}
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 p-6 rounded-xl border border-gray-200 dark:border-gray-800 shadow-sm">
           <div className="flex items-center space-x-3 mb-4">
              <ExclamationTriangleIcon className="h-6 w-6 text-yellow-500" />
              <div>
                <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100">Low Stock Items</h2>
                 <p className="text-sm text-gray-500 dark:text-gray-400">Items that need to be re-ordered.</p>
              </div>
           </div>
           {lowStockItems.length > 0 ? (
                <ul className="space-y-2">
                    {lowStockItems.map(item => (
                        <li key={item.id} className="flex justify-between items-center text-sm p-2 rounded-md bg-gray-50 dark:bg-gray-800/50">
                            <span className="font-medium text-gray-700 dark:text-gray-200">{item.name}</span>
                            <span className="text-yellow-600 dark:text-yellow-400 font-semibold">{item.quantity} left</span>
                        </li>
                    ))}
                </ul>
           ) : (
                <p className="text-center py-8 text-sm text-gray-500 dark:text-gray-400">No items are low on stock.</p>
           )}
        </div>
      </div>
      
      <ProductFormModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveProduct}
        productToEdit={productToEdit}
      />
      <ConfirmationModal
        isOpen={!!itemToDelete}
        onClose={() => setItemToDelete(null)}
        onConfirm={confirmDeleteProduct}
        title="Delete Product"
        message="Are you sure you want to delete this product? This action cannot be undone."
        requiresCode={true}
        securityCode={securityCode}
        confirmButtonText="Confirm Deletion"
      />
    </div>
  );
};

export default InventoryPage;