
import React, { useState, useMemo, useEffect } from 'react';
import type { Invoice, Product, Customer, LineItem, InvoiceType, BillSettings, Claim } from '../types.ts';
import { InvoiceStatus } from '../types.ts';
import PlusIcon from './icons/PlusIcon.tsx';
import UserIcon from './icons/UserIcon.tsx';
import EnvelopeIcon from './icons/EnvelopeIcon.tsx';
import ChevronDownIcon from './icons/ChevronDownIcon.tsx';
import TrashIcon from './icons/TrashIcon.tsx';
import WrenchIcon from './icons/WrenchIcon.tsx';
import ViewInvoiceModal from './modals/ViewInvoiceModal.tsx';
import InvoicePreview from './InvoicePreview.tsx';
import ProcessClaimModal from './modals/ProcessClaimModal.tsx';
import CubeIcon from './icons/CubeIcon.tsx';

interface BillingPageProps {
    onSaveInvoice: (invoice: Invoice) => void;
    products: Product[];
    customers: Customer[];
    setCustomers: React.Dispatch<React.SetStateAction<Customer[]>>;
    lastInvoiceNumber?: string;
    billSettings: BillSettings;
    invoices: Invoice[];
}

type BillLineItem = LineItem & { billItemId: string };


const RecentBillPreviewContent: React.FC<{ invoice: Invoice, billSettings: BillSettings }> = ({ invoice, billSettings }) => {
    
    const formattedDate = new Date(invoice.invoiceDate).toLocaleDateString('en-US', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    });

    const isSmallFormat = invoice.type === 'Retail' || invoice.type === 'Return / Credit';
    const widthInPx = isSmallFormat ? 300 : billSettings.width * 100;
    
    const transactionTotal = useMemo(() => {
        const itemsTotal = invoice.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
        const transactionValue = itemsTotal + (invoice.claimCharges || 0) - (invoice.billDiscount || 0);
        return transactionValue;
    }, [invoice]);
    
    return (
       <div
            className="bg-white text-black font-sans p-4 shadow-lg rounded-lg text-[10px]"
            style={{ width: `${widthInPx}px`, border: '1px solid #333' }}
        >
            {/* Header */}
            <div className="flex justify-between items-start pb-2">
                <div>
                    <p className="font-bold text-lg">{billSettings.companyName || 'Your Company Name'}</p>
                     {billSettings.companyLogo ? (
                         <img src={billSettings.companyLogo} alt="Company Logo" className="h-10 w-10 object-contain rounded-md bg-gray-100 mt-1 p-1" />
                    ) : (
                        <div className="bg-black text-white p-2 rounded-md mt-1 inline-block">
                           <CubeIcon className="w-6 h-6" />
                        </div>
                    )}
                </div>
                <div className="text-right">
                    <h2 className="font-bold text-lg tracking-wide">INVOICE</h2>
                    <p className="font-mono mt-1">#{invoice.invoiceNumber}</p>
                    <p className="mt-1">Date: {formattedDate}</p>
                </div>
            </div>

            <div className="text-left text-xs pb-2">
                <p><span className="font-bold">To:</span> {invoice.customerName || 'Walking Customer'}</p>
            </div>

            <div className="border-b border-black w-full my-2"></div>

            {/* Item Headers */}
            <div className="flex justify-between font-bold py-1 text-xs">
                <span className="w-[25%] text-left">Total</span>
                <span className="w-[20%] text-left">Price</span>
                <span className="w-[15%] text-center">Qty</span>
                <span className="w-[40%] text-right">Item</span>
            </div>
            
            <div className="border-b border-black w-full"></div>


            <div className="min-h-[100px] py-2 text-xs">
                {invoice.items.length === 0 ? (
                    <p className="text-gray-500 text-center py-10">No items added yet</p>
                ) : (
                    <div className="space-y-1">
                        {invoice.items.map((item, index) => (
                             <div key={`${item.id}-${index}`} className="flex justify-between items-start">
                                <span className="w-[25%] text-left">{(item.quantity * item.price).toFixed(2)}</span>
                                <span className="w-[20%] text-left">{item.price.toFixed(2)}</span>
                                <span className="w-[15%] text-center">{item.quantity}</span>
                                <span className="w-[40%] text-right break-words">{item.name}</span>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* Footer */}
            <div className="mt-auto pt-2">
                 <div className="border-t-2 border-black my-2"></div>

                {(invoice.type === 'Wholesale' || invoice.type === 'Return / Credit') ? (
                    <>
                        <div className="flex justify-between items-center text-xs mb-1">
                            <span className="font-semibold">{invoice.type === 'Return / Credit' ? 'Return Total' : 'Total'}</span>
                            <span className="font-semibold">Rs.{transactionTotal.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between items-center text-xs mb-1">
                            <span className="font-semibold">Old Balance</span>
                            <span className="font-semibold">Rs.{(invoice.oldBalance || 0).toFixed(2)}</span>
                        </div>
                    </>
                ) : (
                    <>
                        {invoice.billDiscount && invoice.billDiscount > 0 && (
                            <div className="flex justify-between items-center text-xs mb-1">
                                <span className="font-semibold">Discount</span>
                                <span className="font-semibold">- Rs.{invoice.billDiscount.toFixed(2)}</span>
                            </div>
                        )}
                        
                        {invoice.claimCharges && invoice.claimCharges > 0 && (
                            <div className="flex justify-between items-center text-xs mb-1">
                                <span className="font-semibold">Claim Charges</span>
                                <span className="font-semibold">+ Rs.{invoice.claimCharges.toFixed(2)}</span>
                            </div>
                        )}
                    </>
                )}

                 <div className="flex justify-start items-end mt-1">
                    <div>
                        <p className="text-xs">Grand Total</p>
                        <p className="font-bold text-xl">Rs.{invoice.grandTotal.toFixed(2)}</p>
                    </div>
                </div>
            </div>
            {billSettings.notes && billSettings.notes.trim() !== '' && (
                <div className="mt-2 pt-2 border-t border-dashed border-black">
                    <p className="text-center text-[9px] italic whitespace-pre-wrap">{billSettings.notes}</p>
                </div>
            )}
        </div>
    );
};

const BillingPage: React.FC<BillingPageProps> = ({ onSaveInvoice, products, customers, setCustomers, lastInvoiceNumber, invoices, billSettings }) => {
    
    const getNextInvoiceNumber = () => {
        if (!lastInvoiceNumber) return '000001';
        const numPart = parseInt(lastInvoiceNumber.replace(/[^0-9]/g, ''), 10);
        return (numPart + 1).toString().padStart(6, '0');
    };
    
    // Form State
    const [invoiceType, setInvoiceType] = useState<InvoiceType>('Retail');
    const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
    const [customerName, setCustomerName] = useState('');
    const [customerContact, setCustomerContact] = useState('');
    const [lineItems, setLineItems] = useState<BillLineItem[]>([]);
    const [claimCharges, setClaimCharges] = useState('');
    const [discount, setDiscount] = useState('');
    const [discountType, setDiscountType] = useState<'fixed' | 'percentage'>('percentage');
    const [oldBalance, setOldBalance] = useState(0);
    const [pendingClaims, setPendingClaims] = useState<Claim[]>([]);
    const [openBillId, setOpenBillId] = useState<string | null>(null);

    // Add Item State
    const [selectedProductId, setSelectedProductId] = useState('');
    const [itemPrice, setItemPrice] = useState(0);
    const [itemQty, setItemQty] = useState(1);
    
    // Modal State
    const [viewingInvoice, setViewingInvoice] = useState<Invoice | null>(null);
    const [generatedInvoice, setGeneratedInvoice] = useState<Invoice | null>(null);
    const [processingClaim, setProcessingClaim] = useState<Claim | null>(null);

    const invoiceNumber = useMemo(getNextInvoiceNumber, [lastInvoiceNumber]);
    
    const { subtotal, grandTotal, discountAmount } = useMemo(() => {
        const itemsTotal = lineItems.reduce((sum, item) => sum + item.quantity * item.price, 0);
        const claims = parseFloat(claimCharges) || 0;
        
        let calculatedDiscount = 0;
        const discountValue = parseFloat(discount) || 0;

        if (invoiceType === 'Wholesale') {
            if (discountType === 'percentage' && discountValue > 0) {
                calculatedDiscount = (itemsTotal * discountValue) / 100;
            } else {
                calculatedDiscount = discountValue;
            }
        } else { // Retail and Return/Credit
            calculatedDiscount = discountValue;
        }

        const transactionTotal = itemsTotal + claims - calculatedDiscount;
        
        let finalGrandTotal = transactionTotal;
        if (invoiceType === 'Wholesale') {
            finalGrandTotal = transactionTotal + oldBalance;
        } else if (invoiceType === 'Return / Credit') {
            finalGrandTotal = oldBalance - transactionTotal;
        }

        return { subtotal: transactionTotal, grandTotal: finalGrandTotal, discountAmount: calculatedDiscount };
    }, [lineItems, claimCharges, discount, discountType, invoiceType, oldBalance]);

    // Effect to handle price suggestions and locking
    useEffect(() => {
        if (selectedProductId) {
            const product = products.find(p => p.id === selectedProductId);
            if (product) {
                if (invoiceType === 'Wholesale' || invoiceType === 'Return / Credit') {
                    setItemPrice(product.salePrice);
                } else if (invoiceType === 'Retail') {
                    // if user just switched to retail from another type, clear price
                    if (itemPrice === product.salePrice) {
                        setItemPrice(0);
                    }
                }
            }
        }
    }, [invoiceType, selectedProductId, products]);


    const handleCustomerSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const id = e.target.value;
        setSelectedCustomerId(id);
        if (id) {
            const customer = customers.find(c => c.id === id);
            if(customer) {
                setCustomerName(customer.name);
                setCustomerContact(customer.contactNumbers[0] || '');
                setOldBalance(customer.balance);
                setPendingClaims(customer.claims.filter(c => c.status === 'Pending'));
            }
        } else {
            setCustomerName('');
            setCustomerContact('');
            setOldBalance(0);
            setPendingClaims([]);
        }
    };
    
    const handleProductSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const id = e.target.value;
        setSelectedProductId(id);
        if(id) {
            const product = products.find(p => p.id === id);
            if (product) {
                if (invoiceType === 'Retail') {
                     setItemPrice(0); // Clear price for manual entry
                } else {
                    setItemPrice(product.salePrice);
                }
            }
        } else {
            setItemPrice(0);
        }
    };
    
    const handleAddItem = () => {
        const product = products.find(p => p.id === selectedProductId);
        if (!product) {
            alert('Please select a product.');
            return;
        }
        
        if (itemPrice <= 0 && invoiceType !== 'Return / Credit') {
             if (invoiceType === 'Retail' && product.salePrice > 0) {
                // If retail price is empty, but a wholesale price exists, auto-fill it
                setItemPrice(product.salePrice);
            } else {
                alert('Please enter a valid price for the item.');
                return;
            }
        }
        
        const finalPrice = invoiceType === 'Retail' && itemPrice === 0 ? product.salePrice : itemPrice;

        const newItem: BillLineItem = {
            id: product.id,
            name: product.name,
            price: finalPrice,
            quantity: itemQty,
            billItemId: crypto.randomUUID(),
        };
        
        setLineItems(prev => [...prev, newItem]);
        
        // Reset add item form
        setSelectedProductId('');
        setItemPrice(0);
        setItemQty(1);
    };

    const handleRemoveItem = (billItemId: string) => {
        setLineItems(prev => prev.filter((item) => item.billItemId !== billItemId));
    };
    
    const resetForm = () => {
        setInvoiceType('Retail');
        setSelectedCustomerId('');
        setCustomerName('');
        setCustomerContact('');
        setLineItems([]);
        setSelectedProductId('');
        setItemPrice(0);
        setItemQty(1);
        setClaimCharges('');
        setDiscount('');
        setDiscountType('percentage');
        setOldBalance(0);
        setPendingClaims([]);
    };
    
    const handleConfirmProcessClaim = ({ replacementProductId, claimCharges: charges }: { replacementProductId?: string; claimCharges: number; }) => {
        if (!processingClaim || !selectedCustomerId) return;

        if (replacementProductId) {
            const product = products.find(p => p.id === replacementProductId);
            if (product) {
                const newItem: BillLineItem = {
                    id: product.id,
                    name: `${product.name} (Claim Replacement)`,
                    price: 0,
                    quantity: 1,
                    billItemId: crypto.randomUUID(),
                };
                setLineItems(prev => [...prev, newItem]);
            }
        }

        if (charges !== 0) {
            setClaimCharges(prev => ((parseFloat(prev) || 0) + charges).toString());
        }

        setCustomers(prevCustomers => prevCustomers.map(c => {
            if (c.id === selectedCustomerId) {
                return {
                    ...c,
                    claims: c.claims.map(cl => 
                        cl.id === processingClaim.id ? { ...cl, status: 'Resolved' } : cl
                    )
                };
            }
            return c;
        }));
        
        setPendingClaims(prev => prev.filter(c => c.id !== processingClaim.id));
        setProcessingClaim(null);
    };


    const handleGenerateBill = () => {
        if (lineItems.length === 0) {
            alert('Please add at least one item to the bill.');
            return;
        }
        
        let finalCustomerId = selectedCustomerId;
        if (!selectedCustomerId && customerName.trim()) {
            const newCustomer: Customer = {
                id: crypto.randomUUID(),
                name: customerName.trim(),
                contactNumbers: customerContact.trim() ? [customerContact.trim()] : [],
                balance: 0,
                claims: [],
                transactions: []
            };
            setCustomers(prev => [...prev, newCustomer]);
            finalCustomerId = newCustomer.id;
        }
        
        const claims = parseFloat(claimCharges) || 0;

        const newInvoice: Invoice = {
            id: crypto.randomUUID(),
            invoiceNumber,
            customerName: customerName.trim() || 'Walking Customer',
            customerContact: customerContact.trim(),
            customerId: finalCustomerId,
            invoiceDate: new Date().toISOString(),
            dueDate: new Date(new Date().setDate(new Date().getDate() + 7)).toISOString(),
            items: lineItems.map(({ billItemId, ...item }) => item),
            status: InvoiceStatus.Paid,
            type: invoiceType,
            claimCharges: claims,
            billDiscount: discountAmount,
            grandTotal: grandTotal,
            oldBalance: (invoiceType === 'Wholesale' || invoiceType === 'Return / Credit') ? oldBalance : undefined,
        };
        
        onSaveInvoice(newInvoice);
        setGeneratedInvoice(newInvoice);
    };

    const handleCloseGeneratedInvoiceModal = () => {
        setGeneratedInvoice(null);
        resetForm();
    };


    return (
        <div className="container mx-auto p-4 sm:p-6 lg:p-8">
            <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100 mb-6">Billing</h1>
            
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 items-start">
                {/* Left Column: Form Steps */}
                <div className="lg:col-span-3 space-y-6">
                    
                    {/* Step 1: Customer & Type */}
                    <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                        <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">Step 1: Customer & Type</h2>
                        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Select transaction type and customer details.</p>
                        
                        <div className="mt-4">
                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Type</label>
                            <div className="flex items-center space-x-4 mt-2">
                                {(['Retail', 'Wholesale', 'Return / Credit'] as InvoiceType[]).map(type => (
                                    <label key={type} className="flex items-center space-x-2 cursor-pointer">
                                        <input type="radio" name="invoiceType" value={type} checked={invoiceType === type} onChange={() => setInvoiceType(type)} className="form-radio h-4 w-4 text-primary-600 focus:ring-primary-500 border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900" />
                                        <span className="text-sm text-slate-700 dark:text-slate-200">{type}</span>
                                    </label>
                                ))}
                            </div>
                        </div>

                        <div className="mt-4">
                             <label htmlFor="customer" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Select Customer</label>
                             <div className="relative mt-1">
                                <select id="customer" value={selectedCustomerId} onChange={handleCustomerSelect} className="block w-full appearance-none rounded-md border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 px-3 py-2 shadow-sm focus:border-primary-500 focus:outline-none focus:ring-primary-500 sm:text-sm">
                                    <option value="">Select an existing customer</option>
                                    {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                                </select>
                                <ChevronDownIcon className="pointer-events-none absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
                             </div>
                        </div>
                        
                        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="customerName" className="flex items-center text-sm font-medium text-slate-700 dark:text-slate-300">
                                    <UserIcon className="h-4 w-4 mr-1.5 text-slate-400" /> Customer Name
                                </label>
                                <input type="text" id="customerName" placeholder="Enter name for new customer" value={customerName} onChange={e => setCustomerName(e.target.value)} className="mt-1 block w-full rounded-md border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 px-3 py-2 shadow-sm focus:border-primary-500 focus:outline-none focus:ring-primary-500 sm:text-sm"/>
                            </div>
                             <div>
                                <label htmlFor="customerContact" className="flex items-center text-sm font-medium text-slate-700 dark:text-slate-300">
                                    Customer Contact
                                </label>
                                <div className="relative mt-1">
                                    <input type="text" id="customerContact" placeholder="Phone or Email" value={customerContact} onChange={e => setCustomerContact(e.target.value)} className="block w-full rounded-md border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 px-3 py-2 shadow-sm focus:border-primary-500 focus:outline-none focus:ring-primary-500 sm:text-sm"/>
                                    <EnvelopeIcon className="pointer-events-none absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
                                </div>
                            </div>
                        </div>

                        {pendingClaims.length > 0 && (
                            <div className="mt-4 p-4 rounded-lg border-l-4 border-yellow-500 bg-yellow-50 dark:bg-yellow-900/50">
                                <h4 className="font-bold text-yellow-800 dark:text-yellow-300">Pending Warranty Claims</h4>
                                <ul className="mt-2 space-y-2">
                                    {pendingClaims.map(claim => (
                                        <li key={claim.id} className="flex justify-between items-center text-sm">
                                            <span className="text-slate-700 dark:text-slate-300">{claim.description}</span>
                                            <button
                                                onClick={() => setProcessingClaim(claim)}
                                                className="flex items-center space-x-1.5 px-2.5 py-1 text-xs font-semibold text-white bg-primary-600 rounded-md hover:bg-primary-700"
                                            >
                                                <WrenchIcon className="h-3 w-3" />
                                                <span>Process</span>
                                            </button>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}
                    </div>
                    
                    {/* Step 2: Add Items */}
                    <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                         <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">Step 2: Add Items</h2>
                        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Add products to the transaction.</p>
                        
                        <div className="mt-4">
                            <label htmlFor="product" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Product</label>
                            <div className="relative mt-1">
                                <select id="product" value={selectedProductId} onChange={handleProductSelect} className="block w-full appearance-none rounded-md border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 px-3 py-2 shadow-sm focus:border-primary-500 focus:outline-none focus:ring-primary-500 sm:text-sm">
                                    <option value="">Select a product</option>
                                    {products.map(p => <option key={p.id} value={p.id}>{p.name} (In Stock: {p.quantity})</option>)}
                                </select>
                                <ChevronDownIcon className="pointer-events-none absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
                            </div>
                        </div>

                        <div className="mt-4 grid grid-cols-3 gap-4">
                            <div className="col-span-2">
                                <label htmlFor="price" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Price</label>
                                <div className="relative mt-1">
                                    <input
                                        type="number"
                                        id="price"
                                        value={itemPrice === 0 ? '' : itemPrice}
                                        onChange={e => setItemPrice(parseFloat(e.target.value) || 0)}
                                        placeholder=""
                                        className="block w-full rounded-md border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 px-3 py-2 shadow-sm focus:border-primary-500 focus:outline-none focus:ring-primary-500 sm:text-sm disabled:bg-slate-100 dark:disabled:bg-slate-800/50 disabled:cursor-not-allowed"
                                        disabled={invoiceType !== 'Retail'}
                                    />
                                    {invoiceType === 'Retail' && selectedProductId && itemPrice === 0 && (
                                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500 pointer-events-none sm:text-sm">
                                            {products.find(p => p.id === selectedProductId)?.purchasePrice.toFixed(2)}
                                        </span>
                                    )}
                                </div>
                            </div>
                             <div>
                                <label htmlFor="qty" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Qty</label>
                                <input type="number" id="qty" value={itemQty} onChange={e => setItemQty(parseInt(e.target.value) || 1)} className="mt-1 block w-full rounded-md border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 px-3 py-2 shadow-sm focus:border-primary-500 focus:outline-none focus:ring-primary-500 sm:text-sm"/>
                            </div>
                        </div>
                        
                        <div className="mt-4">
                            <button onClick={handleAddItem} className="w-full flex justify-center items-center space-x-2 px-4 py-2 text-sm text-primary-600 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/50 rounded-lg hover:bg-primary-100 dark:hover:bg-primary-900/80 focus:outline-none focus:ring-2 focus:ring-primary-500 transition-colors">
                                <PlusIcon className="h-5 w-5" />
                                <span>Add Item</span>
                            </button>
                        </div>
                    </div>

                    {/* Step 3: Review & Finalize */}
                    <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                        <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">Step 3: Review & Finalize</h2>
                        <div className="mt-4 border rounded-lg overflow-hidden border-slate-200 dark:border-slate-700">
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm">
                                    <thead className="bg-slate-50 dark:bg-slate-800/50">
                                        <tr>
                                            <th className="w-10"></th>
                                            <th className="p-2 text-left font-semibold text-slate-600 dark:text-slate-300">Total</th>
                                            <th className="p-2 text-left font-semibold text-slate-600 dark:text-slate-300">Price</th>
                                            <th className="p-2 text-left font-semibold text-slate-600 dark:text-slate-300">Qty</th>
                                            <th className="p-2 text-right font-semibold text-slate-600 dark:text-slate-300 w-2/5">Item</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {lineItems.length === 0 ? (
                                            <tr><td colSpan={5} className="text-center p-8 text-slate-500 dark:text-slate-400">No items added yet</td></tr>
                                        ) : (
                                            lineItems.map((item) => (
                                                <tr key={item.billItemId} className="border-t border-slate-200 dark:border-slate-700">
                                                    <td className="p-2 text-center w-10">
                                                        <button onClick={() => handleRemoveItem(item.billItemId)} className="text-slate-400 hover:text-red-500 p-1">
                                                            <TrashIcon className="h-4 w-4" />
                                                        </button>
                                                    </td>
                                                    <td className="p-2 font-semibold text-left text-slate-800 dark:text-slate-100">Rs.{(item.quantity * item.price).toFixed(2)}</td>
                                                    <td className="p-2 text-left text-slate-600 dark:text-slate-300">Rs.{item.price.toFixed(2)}</td>
                                                    <td className="p-2 text-left text-slate-600 dark:text-slate-300">{item.quantity}</td>
                                                    <td className="p-2 font-medium text-right text-slate-800 dark:text-slate-100">{item.name}</td>
                                                </tr>
                                            ))
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="claimCharges" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Claim Charges (Rs.)</label>
                                <input type="number" id="claimCharges" value={claimCharges} onChange={e => setClaimCharges(e.target.value)} placeholder="e.g. 100" className="mt-1 block w-full rounded-md border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 px-3 py-2 shadow-sm focus:border-primary-500 focus:outline-none focus:ring-primary-500 sm:text-sm"/>
                            </div>
                            <div>
                                <label htmlFor="discount" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Discount</label>
                                <div className="flex items-center space-x-2 mt-1">
                                    {invoiceType === 'Wholesale' && (
                                        <div className="flex-shrink-0 flex items-center bg-slate-100 dark:bg-slate-800 rounded-md p-0.5">
                                            <button type="button" onClick={() => setDiscountType('percentage')} className={`px-2 py-1 text-xs rounded-md transition-all ${discountType === 'percentage' ? 'bg-white dark:bg-slate-700 shadow' : 'hover:bg-white/50 dark:hover:bg-slate-900/50'}`}>%</button>
                                            <button type="button" onClick={() => setDiscountType('fixed')} className={`px-2 py-1 text-xs rounded-md transition-all ${discountType === 'fixed' ? 'bg-white dark:bg-slate-700 shadow' : 'hover:bg-white/50 dark:hover:bg-slate-900/50'}`}>Rs.</button>
                                        </div>
                                    )}
                                    <input type="number" id="discount" value={discount} onChange={e => setDiscount(e.target.value)} placeholder={invoiceType === 'Wholesale' ? (discountType === 'percentage' ? 'e.g. 5' : 'e.g. 100') : 'e.g. 50'} className="block w-full rounded-md border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 px-3 py-2 shadow-sm focus:border-primary-500 focus:outline-none focus:ring-primary-500 sm:text-sm"/>
                                </div>
                            </div>
                        </div>
                        
                        <div className="mt-6 border-t border-slate-200 dark:border-slate-700 pt-4 flex justify-between items-center">
                            <div>
                                <span className="text-xl font-bold text-slate-900 dark:text-slate-50">Grand Total: </span>
                                <span className="text-xl font-bold text-slate-900 dark:text-slate-50">Rs.{grandTotal.toFixed(2)}</span>
                            </div>
                            <button onClick={handleGenerateBill} className="px-6 py-2.5 text-base font-medium text-white bg-green-600 rounded-md shadow-sm hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                                Generate Bill
                            </button>
                        </div>
                    </div>
                </div>

                {/* Right Column: Live Preview */}
                <div className="lg:col-span-2 lg:sticky lg:top-6">
                    <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                        <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">Preview</h2>
                        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">This is how your document will look.</p>
                        <div className="mt-4 flex justify-center bg-gray-100 dark:bg-gray-800 p-4 rounded-lg">
                             <InvoicePreview
                                invoiceNumber={invoiceNumber}
                                invoiceDate={new Date().toISOString().split('T')[0]}
                                items={lineItems}
                                billSettings={billSettings}
                                grandTotal={grandTotal}
                                discountAmount={discountAmount}
                                claimCharges={parseFloat(claimCharges) || 0}
                                invoiceType={invoiceType}
                                customerName={customerName}
                                oldBalance={oldBalance}
                                subtotal={subtotal}
                            />
                        </div>
                    </div>
                </div>
            </div>

             {/* New Recent Bills Section */}
            <div className="mt-12">
                <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100 mb-4">Recent Bills</h2>
                {invoices.length > 0 ? (
                    <div className="space-y-2">
                        {invoices.slice(0, 5).map(invoice => (
                            <div key={invoice.id} className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
                                <button 
                                    className="w-full flex justify-between items-center p-4 text-left hover:bg-slate-50 dark:hover:bg-slate-800/50"
                                    onClick={() => setOpenBillId(openBillId === invoice.id ? null : invoice.id)}
                                    aria-expanded={openBillId === invoice.id}
                                >
                                    <div className="font-semibold text-slate-700 dark:text-slate-200">
                                        Bill #{invoice.invoiceNumber} - <span className="font-normal text-slate-500 dark:text-slate-400">{invoice.type}</span>
                                    </div>
                                    <div className="flex items-center space-x-4">
                                        <span className="text-sm text-slate-500 dark:text-slate-400">{new Date(invoice.invoiceDate).toLocaleDateString()}</span>
                                        <ChevronDownIcon className={`h-5 w-5 text-slate-400 transition-transform ${openBillId === invoice.id ? 'rotate-180' : ''}`} />
                                    </div>
                                </button>
                                {openBillId === invoice.id && (
                                    <div className="p-4 bg-slate-50 dark:bg-slate-800/50 flex justify-center border-t border-slate-200 dark:border-slate-700">
                                        <RecentBillPreviewContent invoice={invoice} billSettings={billSettings} />
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-10 px-6 bg-white dark:bg-slate-900 rounded-lg shadow-sm border border-slate-200 dark:border-slate-700">
                        <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                        <h3 className="mt-2 text-lg font-medium text-slate-900 dark:text-slate-100">No bills have been created yet</h3>
                        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Your recent transactions will appear here.</p>
                    </div>
                )}
            </div>

            {generatedInvoice && 
                <ViewInvoiceModal 
                    isOpen={!!generatedInvoice} 
                    onClose={handleCloseGeneratedInvoiceModal} 
                    invoice={generatedInvoice} 
                    billSettings={billSettings} 
                />
            }
            {processingClaim && (
                <ProcessClaimModal 
                    isOpen={!!processingClaim}
                    onClose={() => setProcessingClaim(null)}
                    onConfirm={handleConfirmProcessClaim}
                    claim={processingClaim}
                    products={products}
                />
            )}
        </div>
    );
};

export default BillingPage;
