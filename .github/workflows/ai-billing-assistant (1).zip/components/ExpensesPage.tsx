

import React, { useState, useMemo } from 'react';
import type { Expense } from '../types';
import PlusCircleIcon from './icons/PlusCircleIcon';
import TrashIcon from './icons/TrashIcon';
import ConfirmationModal from './modals/ConfirmationModal';

interface ExpensesPageProps {
  expenses: Expense[];
  setExpenses: React.Dispatch<React.SetStateAction<Expense[]>>;
  securityCode: string;
}

const StatCard: React.FC<{ title: string; amount: number }> = ({ title, amount }) => (
  <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm flex justify-between items-center">
    <div>
      <p className="text-sm font-medium text-slate-500 dark:text-slate-400">{title}</p>
      <p className="text-2xl font-bold text-slate-800 dark:text-slate-100">Rs.{amount.toFixed(2)}</p>
    </div>
    <span className="text-lg font-semibold text-slate-300 dark:text-slate-600">Rs.</span>
  </div>
);

const ExpensesPage: React.FC<ExpensesPageProps> = ({ expenses, setExpenses, securityCode }) => {
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [itemToDelete, setItemToDelete] = useState<string | null>(null);

  const { todayTotal, weekTotal, monthTotal } = useMemo(() => {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    const startOfWeek = new Date(startOfToday);
    startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay());
    
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    let todayTotal = 0;
    let weekTotal = 0;
    let monthTotal = 0;

    for (const expense of expenses) {
      const expenseDate = new Date(expense.date);
      if (expenseDate >= startOfMonth) {
        monthTotal += expense.amount;
        if (expenseDate >= startOfWeek) {
          weekTotal += expense.amount;
          if (expenseDate >= startOfToday) {
            todayTotal += expense.amount;
          }
        }
      }
    }
    return { todayTotal, weekTotal, monthTotal };
  }, [expenses]);

  const groupedExpenses = useMemo(() => {
    const sorted = [...expenses].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    return sorted.reduce((acc, expense) => {
      const dateKey = new Date(expense.date).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });
      if (!acc[dateKey]) {
        acc[dateKey] = [];
      }
      acc[dateKey].push(expense);
      return acc;
    }, {} as Record<string, Expense[]>);
  }, [expenses]);

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (!description.trim() || isNaN(numAmount) || numAmount <= 0) {
      alert('Please enter a valid description and amount.');
      return;
    }

    const newExpense: Expense = {
      id: crypto.randomUUID(),
      date: new Date().toISOString(),
      description: description.trim(),
      amount: numAmount,
    };

    setExpenses(prev => [newExpense, ...prev]);
    setDescription('');
    setAmount('');
  };

  const handleDeleteExpense = (id: string) => {
    setItemToDelete(id);
  };
  
  const confirmDeleteExpense = () => {
    if (!itemToDelete) return;
    setExpenses(prev => prev.filter(exp => exp.id !== itemToDelete));
    setItemToDelete(null);
  };

  return (
    <div className="container mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
      <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">My Expenses</h1>

      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
        <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">Log a New Expense</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Record any miscellaneous business expenses here.</p>
        <form onSubmit={handleAddExpense} className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
          <div className="md:col-span-2">
            <label htmlFor="description" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Description</label>
            <input
              type="text"
              id="description"
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="e.g., Office supplies, utility bill"
              className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              required
            />
          </div>
          <div>
            <label htmlFor="amount" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Amount (Rs.)</label>
            <input
              type="number"
              id="amount"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              placeholder="e.g., 500"
              className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              required
            />
          </div>
          <div className="md:col-span-3">
             <button type="submit" className="flex items-center space-x-2 px-4 py-2 text-sm text-primary-600 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/50 rounded-lg hover:bg-primary-100 dark:hover:bg-primary-900/80 focus:outline-none focus:ring-2 focus:ring-primary-500 transition-colors">
                 <PlusCircleIcon className="h-5 w-5" />
                 <span>Add Expense</span>
             </button>
          </div>
        </form>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard title="Today's Expenses" amount={todayTotal} />
        <StatCard title="This Week's Expenses" amount={weekTotal} />
        <StatCard title="This Month's Expenses" amount={monthTotal} />
      </div>

      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
        <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">Expense History</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">A log of all recorded general expenses.</p>
        <div className="mt-4 space-y-4">
            {Object.keys(groupedExpenses).length > 0 ? (
                Object.entries(groupedExpenses).map(([date, expensesOnDate]) => (
                    <div key={date}>
                        <h3 className="text-sm font-semibold text-slate-600 dark:text-slate-300 mb-2">{date}</h3>
                        <div className="border border-slate-200 dark:border-slate-700 rounded-md">
                            <table className="w-full text-sm">
                                <thead>
                                    <tr className="border-b border-slate-200 dark:border-slate-700">
                                        <th className="text-left font-medium p-2 text-slate-500 dark:text-slate-400">Description</th>
                                        <th className="text-right font-medium p-2 text-slate-500 dark:text-slate-400">Amount</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {expensesOnDate.map(expense => (
                                        <tr key={expense.id} className="border-t border-slate-200 dark:border-slate-700">
                                            <td className="p-2 text-slate-700 dark:text-slate-200">{expense.description}</td>
                                            <td className="p-2 text-right font-medium text-slate-800 dark:text-slate-100">Rs.{expense.amount.toFixed(2)}</td>
                                            <td className="p-2 text-right w-10">
                                                <button onClick={() => handleDeleteExpense(expense.id)} className="text-slate-400 hover:text-red-500 p-1">
                                                    <TrashIcon className="h-4 w-4" />
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                ))
            ) : (
                <p className="text-center py-8 text-slate-500 dark:text-slate-400">No expenses recorded yet.</p>
            )}
        </div>
      </div>
      <ConfirmationModal
        isOpen={!!itemToDelete}
        onClose={() => setItemToDelete(null)}
        onConfirm={confirmDeleteExpense}
        title="Delete Expense"
        message="Are you sure you want to delete this expense? This action cannot be undone."
        requiresCode={true}
        securityCode={securityCode}
        confirmButtonText="Confirm Deletion"
      />
    </div>
  );
};

export default ExpensesPage;
