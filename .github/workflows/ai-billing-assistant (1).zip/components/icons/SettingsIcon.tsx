import React from 'react';

const SettingsIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.594 3.94c.09-.542.56-1.008 1.11-1.212.55-.203 1.166-.234 1.744-.082.578.152 1.093.528 1.417 1.001.325.473.483 1.047.417 1.621-.065.574-.356 1.12-.778 1.528a4.53 4.53 0 0 1-1.39 1.002.44.44 0 0 0-.175.316V12a.75.75 0 0 1-1.5 0v-1.764a.438.438 0 0 0-.175-.316 4.49 4.49 0 0 1-1.39-1.002c-.422-.408-.713-.954-.778-1.528-.066-.574.092-1.148.417-1.621.324-.473.839-.849 1.417-1.001a1.99 1.99 0 0 1 1.744-.082 1.99 1.99 0 0 1 1.11 1.212Z M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 15.75a3.75 3.75 0 1 0 0-7.5 3.75 3.75 0 0 0 0 7.5Z" />
  </svg>
);

export default SettingsIcon;