import React from 'react';

const CustomersIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 19.128a9.38 9.38 0 0 0 2.625.372 9.337 9.337 0 0 0 4.121-1.063M15 19.128v-3.872M15 19.128c-1.556 0-3.041-.26-4.372-.738M15 19.128a9.38 9.38 0 0 0-2.625.372M10.5 18.375c-1.556 0-3.041-.26-4.372-.738m4.372.738v-3.872m0 3.872a9.38 9.38 0 0 1-2.625-.372m2.625.372a9.337 9.337 0 0 1 4.121-1.063M10.5 18.375c-1.556 0-3.041-.26-4.372-.738m4.372.738a9.38 9.38 0 0 1-2.625-.372m-2.25-13.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM16.5 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
  </svg>
);

export default CustomersIcon;