import React from 'https://esm.sh/react@18.2.0';

const ArchiveBoxIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 7.5V6.108c0-1.135.845-2.098 1.976-2.192.373-.03.748-.03 1.125 0 1.131.094 1.976 1.057 1.976 2.192V7.5m-9 7.5h9v6.75a1.5 1.5 0 0 1-1.5 1.5h-6a1.5 1.5 0 0 1-1.5-1.5v-6.75Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 1.5v5.25A2.25 2.25 0 0 1 13.5 9h-6a2.25 2.25 0 0 1-2.25-2.25V1.5m10.5 0a2.25 2.25 0 0 0-2.25-2.25h-3a2.25 2.25 0 0 0-2.25 2.25" />
  </svg>
);

export default ArchiveBoxIcon;