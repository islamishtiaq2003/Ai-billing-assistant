import React, { useState, useMemo, useRef } from 'react';
import type { Invoice, Customer, Vendor, StaffMember, Expense } from '../types.ts';
import WalletIcon from './icons/WalletIcon.tsx';
import TrendingUpIcon from './icons/TrendingUpIcon.tsx';
import AdjustmentsIcon from './icons/AdjustmentsIcon.tsx';
import BuildingStorefrontIcon from './icons/BuildingStorefrontIcon.tsx';
import BriefcaseIcon from './icons/BriefcaseIcon.tsx';
import ChartBarIcon from './icons/ChartBarIcon.tsx';
import ListBulletIcon from './icons/ListBulletIcon.tsx';
import TopProductsModal from './modals/TopProductsModal.tsx';
import DuesListModal from './modals/DuesListModal.tsx';

type Period = '7 Days' | 'This Month' | 'This Year';
type ModalType = 'topProducts' | 'customerDues' | 'vendorDues' | null;

interface DashboardProps {
    invoices: Invoice[];
    customers: Customer[];
    vendors: Vendor[];
    staff: StaffMember[];
    expenses: Expense[];
}

const StatCard: React.FC<{ title: string, amount: string, subtitle: string, icon: React.FC<React.SVGProps<SVGSVGElement>>, colorClass: string, extraClasses?: string }> = ({ title, amount, subtitle, icon: Icon, colorClass, extraClasses = '' }) => (
    <div className={`p-5 rounded-xl shadow-sm text-white ${colorClass} ${extraClasses}`}>
        <div className="flex justify-between items-start">
            <div>
                <p className="text-sm font-medium opacity-80">{title}</p>
                <p className="text-3xl font-bold mt-1">{amount}</p>
                <p className="text-xs opacity-70 mt-1">{subtitle}</p>
            </div>
            <div className="bg-white/20 p-2 rounded-lg">
                <Icon className="h-5 w-5" />
            </div>
        </div>
    </div>
);

const ChartCard: React.FC<{ children: React.ReactNode, title: string, subtitle: string, icon: React.FC<React.SVGProps<SVGSVGElement>>, extraClasses?: string, activePeriod?: Period, onPeriodChange?: (period: Period) => void }> = ({ children, title, subtitle, icon: Icon, extraClasses = '', activePeriod, onPeriodChange }) => {
    return (
        <div className={`bg-white dark:bg-gray-900 p-6 rounded-xl border border-gray-200 dark:border-gray-800 shadow-sm ${extraClasses}`}>
            <div className="flex justify-between items-start">
                <div className="flex items-center space-x-3">
                    <div className="bg-primary-100 dark:bg-primary-900/50 p-2 rounded-lg text-primary-600 dark:text-primary-300">
                        <Icon className="h-6 w-6" />
                    </div>
                    <div>
                        <h3 className="font-bold text-gray-800 dark:text-gray-100">{title}</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{subtitle}</p>
                    </div>
                </div>
                {title.includes('Overview') && onPeriodChange && (
                    <div className="flex space-x-1 bg-gray-100 dark:bg-gray-800 p-1 rounded-md text-sm">
                        {(['7 Days', 'This Month', 'This Year'] as Period[]).map(tab => (
                            <button key={tab} onClick={() => onPeriodChange(tab)} className={`px-3 py-1 rounded ${activePeriod === tab ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-800 dark:text-gray-100 font-semibold' : 'text-gray-500 dark:text-gray-400'}`}>
                                {tab}
                            </button>
                        ))}
                    </div>
                )}
            </div>
            <div className="mt-6">
                {children}
            </div>
        </div>
    );
}

const DynamicLineChart: React.FC<{ chartData: { labels: string[]; data: number[] }; color: string; name: string; }> = ({ chartData, color, name }) => {
    const { labels, data } = chartData;
    const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
    const svgRef = useRef<SVGSVGElement>(null);
    const gradientId = `gradient-${name.toLowerCase().replace(' ', '-')}`;

    if (data.every(d => d === 0) || data.length === 0) {
        return <div className="h-[180px] flex items-center justify-center text-gray-500 dark:text-gray-400">No data available for this period.</div>;
    }

    const SVG_WIDTH = 400;
    const SVG_HEIGHT = 180;
    const MARGIN = { top: 20, right: 10, bottom: 40, left: 50 };
    const CHART_WIDTH = SVG_WIDTH - MARGIN.left - MARGIN.right;
    const CHART_HEIGHT = SVG_HEIGHT - MARGIN.top - MARGIN.bottom;

    const maxDataValue = Math.max(...data) * 1.2 || 1;

    const getCoords = (value: number, index: number) => {
        const x = MARGIN.left + (data.length > 1 ? (index / (data.length - 1)) * CHART_WIDTH : CHART_WIDTH / 2);
        const y = MARGIN.top + CHART_HEIGHT - (value / maxDataValue) * CHART_HEIGHT;
        return { x, y };
    };
    
    const linePath = (points: {x: number, y: number}[]) => {
        if (points.length < 2) return '';
        let path = `M ${points[0].x} ${points[0].y}`;
        for (let i = 0; i < points.length - 1; i++) {
            const x_mid = (points[i].x + points[i + 1].x) / 2;
            const y_mid = (points[i].y + points[i + 1].y) / 2;
            const cp_x1 = (x_mid + points[i].x) / 2;
            const cp_y1 = (y_mid + points[i].y) / 2;
            const cp_x2 = (x_mid + points[i + 1].x) / 2;
            const cp_y2 = (y_mid + points[i + 1].y) / 2;
            path += ` Q ${cp_x1}, ${cp_y1}, ${x_mid}, ${y_mid}`;
            path += ` Q ${cp_x2}, ${cp_y2}, ${points[i + 1].x}, ${points[i + 1].y}`;
        }
        return path;
    };
    
    const dataPoints = data.map((d,i) => getCoords(d,i));
    const smoothedLinePath = linePath(dataPoints);

    const areaPath = `${smoothedLinePath} L ${getCoords(0, data.length > 1 ? data.length - 1 : 0).x} ${MARGIN.top + CHART_HEIGHT} L ${MARGIN.left} ${MARGIN.top + CHART_HEIGHT} Z`;

    const handleMouseMove = (event: React.MouseEvent<SVGSVGElement>) => {
        if (!svgRef.current || data.length === 0) return;
        const svg = svgRef.current;
        const rect = svg.getBoundingClientRect();
        const svgX = ((event.clientX - rect.left) / rect.width) * SVG_WIDTH;

        if (svgX < MARGIN.left || svgX > MARGIN.left + CHART_WIDTH) {
            setHoveredIndex(null);
            return;
        }

        let index;
        if (data.length > 1) {
            index = Math.round(((svgX - MARGIN.left) / CHART_WIDTH) * (data.length - 1));
        } else {
            index = 0;
        }

        if (index >= 0 && index < data.length) {
            setHoveredIndex(index);
        } else {
            setHoveredIndex(null);
        }
    };

    const handleMouseLeave = () => {
        setHoveredIndex(null);
    };
    
    const yAxisLabels = [0, 0.25, 0.5, 0.75, 1].map(tick => {
        const value = maxDataValue * tick;
        const y = MARGIN.top + CHART_HEIGHT - (CHART_HEIGHT * tick);
        return { value, y };
    });

    const hoveredData = hoveredIndex !== null && data[hoveredIndex] !== undefined ? {
        x: getCoords(data[hoveredIndex], hoveredIndex).x,
        y: getCoords(data[hoveredIndex], hoveredIndex).y,
        value: data[hoveredIndex],
        label: labels[hoveredIndex]
    } : null;

    return (
        <div className="relative">
             <svg 
                ref={svgRef}
                viewBox={`0 0 ${SVG_WIDTH} ${SVG_HEIGHT}`} 
                className="w-full h-auto"
                onMouseMove={handleMouseMove}
                onMouseLeave={handleMouseLeave}
             >
                <defs>
                    <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={color} stopOpacity={0.4} />
                        <stop offset="100%" stopColor={color} stopOpacity={0} />
                    </linearGradient>
                </defs>
                <g className="text-xs text-gray-400 dark:text-gray-500" fill="currentColor">
                    {yAxisLabels.map(({ value, y }, i) => (
                        <g key={i}>
                            <text x={MARGIN.left - 8} y={y} dy="0.3em" textAnchor="end">{`Rs.${Math.round(value)}`}</text>
                            <line x1={MARGIN.left} x2={SVG_WIDTH - MARGIN.right} y1={y} y2={y} className="stroke-current opacity-20 dark:opacity-10" strokeDasharray="2,2" />
                        </g>
                    ))}
                    {labels.map((label, i) => {
                         if (labels.length > 15 && i % 3 !== 0) return null;
                         if (labels.length > 7 && i % 2 !== 0) return null;
                        const { x } = getCoords(0, i);
                        return <text key={i} x={x} y={SVG_HEIGHT - 5} textAnchor="middle">{label}</text>
                    })}
                </g>
                
                <path d={areaPath} fill={`url(#${gradientId})`} />
                <path d={smoothedLinePath} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                
                {hoveredData && (
                    <g>
                        <line 
                            x1={hoveredData.x} y1={MARGIN.top}
                            x2={hoveredData.x} y2={MARGIN.top + CHART_HEIGHT}
                            stroke={color}
                            strokeWidth="1"
                            strokeDasharray="3,3"
                        />
                        <circle 
                            cx={hoveredData.x}
                            cy={hoveredData.y}
                            r="4"
                            fill={color}
                            stroke="white"
                            strokeWidth="2"
                            className="drop-shadow"
                        />
                    </g>
                )}
                
            </svg>
            {hoveredData && (
                <div 
                    className="absolute p-2 text-xs bg-gray-800/90 text-white rounded-md shadow-xl pointer-events-none transition-opacity border border-gray-700/50 backdrop-blur-sm"
                    style={{
                        left: `${(hoveredData.x / SVG_WIDTH) * 100}%`,
                        top: `${(hoveredData.y / SVG_HEIGHT) * 100}%`,
                        transform: 'translate(-50%, -120%)',
                        whiteSpace: 'nowrap'
                    }}
                >
                    <div className="font-semibold">{hoveredData.label}</div>
                    <div>Rs.{hoveredData.value.toFixed(2)} {name}</div>
                </div>
            )}
        </div>
    );
};

const TopProductsChart: React.FC<{ products: { name: string; quantity: number }[] }> = ({ products }) => {
    if (products.length === 0) {
        return <div className="text-center py-10 text-gray-500 dark:text-gray-400">No sales data found.</div>
    }
    const max = Math.max(...products.map(p => p.quantity), 1);

    return (
        <div className="space-y-4">
            {products.map((p, i) => (
                <div key={i} className="flex items-center">
                    <p className="w-36 text-sm text-gray-500 dark:text-gray-400 text-right pr-4 truncate">{p.name}</p>
                    <div className="flex-1 bg-gray-100 dark:bg-gray-700 rounded-full h-6 relative">
                         <div className="bg-primary-500 h-6 rounded-full flex items-center justify-end pr-2 text-white text-xs font-bold" style={{ width: `${(p.quantity / max) * 100}%` }}>
                           {p.quantity} sold
                         </div>
                    </div>
                </div>
            ))}
        </div>
    );
};

const getStartDate = (period: Period): Date => {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  switch (period) {
    case '7 Days':
      return new Date(today.setDate(today.getDate() - 6));
    case 'This Month':
      return new Date(today.getFullYear(), today.getMonth(), 1);
    case 'This Year':
      return new Date(today.getFullYear(), 0, 1);
  }
};

const Dashboard: React.FC<DashboardProps> = ({ invoices, customers, vendors, staff, expenses }) => {
    
    const [salesPeriod, setSalesPeriod] = useState<Period>('This Month');
    const [expensesPeriod, setExpensesPeriod] = useState<Period>('This Month');
    const [activeModal, setActiveModal] = useState<ModalType>(null);

    const totalRevenue = useMemo(() => {
        return invoices.reduce((sum, inv) => {
            if (inv.type === 'Return / Credit') {
                return sum - inv.grandTotal;
            }
            return sum + inv.grandTotal;
        }, 0);
    }, [invoices]);
    const billCount = invoices.length;

    const totalCustomerDues = useMemo(() => customers.reduce((sum, c) => sum + c.balance, 0), [customers]);

    const { totalVendorDues, totalPurchases } = useMemo(() => {
        const totalDues = vendors.reduce((sum, v) => sum + v.balance, 0);
        const purchases = vendors.reduce((vendorSum, vendor) => {
            const vendorPurchases = vendor.transactions
                .filter(t => t.type === 'purchase' && t.amount > 0)
                .reduce((txSum, tx) => txSum + tx.amount, 0);
            return vendorSum + vendorPurchases;
        }, 0);
        return { totalVendorDues: totalDues, totalPurchases: purchases };
    }, [vendors]);

    const { totalPaidThisMonth, totalAdvancesThisMonth, totalSalariesPaidThisMonth } = useMemo(() => {
        const now = new Date();
        const currentMonth = now.getMonth();
        const currentYear = now.getFullYear();

        let advances = 0;
        let salaries = 0;

        staff.forEach(member => {
            member.payments.forEach(p => {
                const paymentDate = new Date(p.date);
                if (paymentDate.getMonth() === currentMonth && paymentDate.getFullYear() === currentYear) {
                    if (p.type === 'Advance') {
                        advances += p.amount;
                    } else if (p.type === 'Salary') {
                        salaries += p.amount;
                    }
                }
            });
        });
        
        return { 
            totalPaidThisMonth: advances + salaries,
            totalAdvancesThisMonth: advances,
            totalSalariesPaidThisMonth: salaries
        };
    }, [staff]);

    const totalGeneralExpenses = useMemo(() => expenses.reduce((sum, expense) => sum + expense.amount, 0), [expenses]);
    const netAmount = totalRevenue - totalGeneralExpenses - totalPaidThisMonth;

    const salesChartData = useMemo(() => {
        const startDate = getStartDate(salesPeriod);
        const endDate = new Date();
        const filtered = invoices.filter(i => new Date(i.invoiceDate) >= startDate && new Date(i.invoiceDate) <= endDate);
        
        const dataMap = new Map<string, number>();
        let labels: string[] = [];

        if (salesPeriod === 'This Year') {
            labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            labels.forEach(l => dataMap.set(l, 0));
            filtered.forEach(inv => {
                const month = new Date(inv.invoiceDate).toLocaleString('default', { month: 'short' });
                const amount = inv.type === 'Return / Credit' ? -inv.grandTotal : inv.grandTotal;
                dataMap.set(month, (dataMap.get(month) || 0) + amount);
            });
        } else {
            const numDays = salesPeriod === '7 Days' ? 7 : endDate.getDate();
            for (let i = 0; i < numDays; i++) {
                const date = new Date(startDate);
                date.setDate(startDate.getDate() + i);
                const label = date.toLocaleDateString('en-US', { day: 'numeric', month: 'short' });
                labels.push(label);
                dataMap.set(label, 0);
            }
            filtered.forEach(inv => {
                const label = new Date(inv.invoiceDate).toLocaleDateString('en-US', { day: 'numeric', month: 'short' });
                if (dataMap.has(label)) {
                    const amount = inv.type === 'Return / Credit' ? -inv.grandTotal : inv.grandTotal;
                    dataMap.set(label, (dataMap.get(label) || 0) + amount);
                }
            });
        }
        return { labels, data: labels.map(l => dataMap.get(l) || 0) };
    }, [invoices, salesPeriod]);

    const expensesChartData = useMemo(() => {
        const startDate = getStartDate(expensesPeriod);
        const endDate = new Date();
        const filtered = expenses.filter(e => new Date(e.date) >= startDate && new Date(e.date) <= endDate);
        
        const dataMap = new Map<string, number>();
        let labels: string[] = [];

        if (expensesPeriod === 'This Year') {
            labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            labels.forEach(l => dataMap.set(l, 0));
            filtered.forEach(exp => {
                const month = new Date(exp.date).toLocaleString('default', { month: 'short' });
                dataMap.set(month, (dataMap.get(month) || 0) + exp.amount);
            });
        } else {
            const numDays = expensesPeriod === '7 Days' ? 7 : endDate.getDate();
            for (let i = 0; i < numDays; i++) {
                const date = new Date(startDate);
                date.setDate(startDate.getDate() + i);
                const label = date.toLocaleDateString('en-US', { day: 'numeric', month: 'short' });
                labels.push(label);
                dataMap.set(label, 0);
            }
            filtered.forEach(exp => {
                const label = new Date(exp.date).toLocaleDateString('en-US', { day: 'numeric', month: 'short' });
                if (dataMap.has(label)) {
                    dataMap.set(label, (dataMap.get(label) || 0) + exp.amount);
                }
            });
        }
        return { labels, data: labels.map(l => dataMap.get(l) || 0) };
    }, [expenses, expensesPeriod]);
    
     const fullTopProductsData = useMemo(() => {
        const productSales = new Map<string, { name: string, quantity: number }>();
        invoices.forEach(invoice => {
            if (invoice.type !== 'Return / Credit') {
                invoice.items.forEach(item => {
                    const existing = productSales.get(item.id) || { name: item.name, quantity: 0 };
                    productSales.set(item.id, {
                        ...existing,
                        quantity: existing.quantity + item.quantity
                    });
                });
            }
        });

        return Array.from(productSales.values())
            .sort((a, b) => b.quantity - a.quantity)
    }, [invoices]);

    const top5ProductsData = useMemo(() => fullTopProductsData.slice(0, 5), [fullTopProductsData]);
    
    const customerDuesData = useMemo(() => {
        return customers
            .filter(c => c.balance > 0)
            .map(c => ({ name: c.name, balance: c.balance }))
            .sort((a, b) => b.balance - a.balance);
    }, [customers]);

    const vendorDuesData = useMemo(() => {
        return vendors
            .filter(v => v.balance > 0)
            .map(v => ({ name: v.name, balance: v.balance }))
            .sort((a, b) => b.balance - a.balance);
    }, [vendors]);


    return (
        <div className="container mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
            <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-100">Dashboard</h1>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard 
                    title="Net Amount" 
                    amount={`Rs.${netAmount.toFixed(2)}`}
                    subtitle="(Revenue) - (Expenses)" 
                    icon={WalletIcon} 
                    colorClass="bg-gray-700 dark:bg-gray-800"
                    extraClasses="lg:col-span-2"
                />
                 <StatCard 
                    title="Total Revenue" 
                    amount={`Rs.${totalRevenue.toFixed(2)}`}
                    subtitle={`From ${billCount} bills`}
                    icon={TrendingUpIcon} 
                    colorClass="bg-primary-600"
                />
                <div 
                    className="p-5 rounded-xl shadow-sm bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 cursor-pointer transition-transform hover:scale-[1.02] hover:shadow-lg"
                    onClick={() => setActiveModal('customerDues')}
                    role="button"
                    tabIndex={0}
                    aria-label="View customer dues details"
                >
                    <div className="flex justify-between items-start">
                        <div>
                             <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Customer Dues</p>
                             <p className="text-3xl font-bold mt-1 text-gray-800 dark:text-gray-100">{`Rs.${totalCustomerDues.toFixed(2)}`}</p>
                             <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">Total amount receivable</p>
                        </div>
                        <div className="bg-gray-100 dark:bg-gray-800 p-2 rounded-lg text-gray-500 dark:text-gray-300">
                            <AdjustmentsIcon className="h-5 w-5" />
                        </div>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                 <div 
                    className="cursor-pointer transition-transform hover:scale-[1.02] rounded-xl"
                    onClick={() => setActiveModal('vendorDues')}
                    role="button"
                    tabIndex={0}
                    aria-label="View vendor dues details"
                >
                    <StatCard 
                        title="Vendor Dues" 
                        amount={`Rs.${totalVendorDues.toFixed(2)}`}
                        subtitle={`Total purchases: Rs.${totalPurchases.toFixed(2)}`}
                        icon={BuildingStorefrontIcon} 
                        colorClass="bg-orange-500"
                    />
                </div>
                 <StatCard 
                    title="Staff Payroll (This Month)" 
                    amount={`Rs.${totalPaidThisMonth.toFixed(2)}`}
                    subtitle={`Salary: Rs.${totalSalariesPaidThisMonth.toFixed(2)} | Advance: Rs.${totalAdvancesThisMonth.toFixed(2)}`} 
                    icon={BriefcaseIcon} 
                    colorClass="bg-amber-600"
                />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <ChartCard title="Sales Overview" subtitle="Total sales over a selected period." icon={ChartBarIcon} activePeriod={salesPeriod} onPeriodChange={setSalesPeriod}>
                    <DynamicLineChart chartData={salesChartData} color="#38bdf8" name="Sales" />
                </ChartCard>
                <ChartCard title="Expenses Overview" subtitle="All spending over a selected period." icon={ChartBarIcon} activePeriod={expensesPeriod} onPeriodChange={setExpensesPeriod}>
                    <DynamicLineChart chartData={expensesChartData} color="#f97316" name="Expenses" />
                </ChartCard>
            </div>

             <div className="grid grid-cols-1">
                 <div 
                    className="cursor-pointer transition-transform hover:scale-[1.02] rounded-xl"
                    onClick={() => setActiveModal('topProducts')}
                    role="button"
                    tabIndex={0}
                    aria-label="View top selling products"
                >
                    <ChartCard title="Top Selling Products" subtitle="Your 5 most popular products by quantity sold." icon={ListBulletIcon}>
                        <TopProductsChart products={top5ProductsData} />
                    </ChartCard>
                </div>
             </div>
             
            <TopProductsModal 
                isOpen={activeModal === 'topProducts'}
                onClose={() => setActiveModal(null)}
                productsData={fullTopProductsData}
            />
            <DuesListModal 
                isOpen={activeModal === 'customerDues'}
                onClose={() => setActiveModal(null)}
                title="Customers with Outstanding Balance"
                data={customerDuesData}
            />
            <DuesListModal 
                isOpen={activeModal === 'vendorDues'}
                onClose={() => setActiveModal(null)}
                title="Vendors to be Paid"
                data={vendorDuesData}
            />

        </div>
    );
};

export default Dashboard;