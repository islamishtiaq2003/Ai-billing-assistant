import React, { useState } from 'react';
import type { BillSettings, UserInfo } from '../types.ts';
import type { Theme } from '../App.tsx';
import BuildingOfficeIcon from './icons/BuildingOfficeIcon.tsx';
import LockIcon from './icons/LockIcon.tsx';
import SunIcon from './icons/SunIcon.tsx';
import MoonIcon from './icons/MoonIcon.tsx';
import ComputerDesktopIcon from './icons/ComputerDesktopIcon.tsx';
import GoogleIcon from './icons/GoogleIcon.tsx';
import CheckCircleIcon from './icons/CheckCircleIcon.tsx';
import CloudArrowUpIcon from './icons/CloudArrowUpIcon.tsx';
import CloudArrowDownIcon from './icons/CloudArrowDownIcon.tsx';

interface SettingsPageProps {
    settings: BillSettings;
    setSettings: React.Dispatch<React.SetStateAction<BillSettings>>;
    securityCode: string;
    setSecurityCode: React.Dispatch<React.SetStateAction<string>>;
    theme: Theme;
    setTheme: (theme: Theme) => void;
    isLoggedIn: boolean;
    userInfo: UserInfo | null;
    lastBackupDate: string | null;
    onBackup: () => void;
    onRestore: () => void;
    isSyncing: boolean;
}

const SettingsPage: React.FC<SettingsPageProps> = ({ 
    settings, setSettings, securityCode, setSecurityCode, theme, setTheme,
    isLoggedIn, userInfo, lastBackupDate, onBackup, onRestore, isSyncing
}) => {

    const [currentCode, setCurrentCode] = useState('');
    const [newCode, setNewCode] = useState('');
    const [confirmCode, setConfirmCode] = useState('');

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value, type } = e.target;
        if (type === 'checkbox') {
            const { checked } = e.target as HTMLInputElement;
            setSettings(prev => ({ ...prev, [name]: checked }));
        } else {
             setSettings(prev => ({
                ...prev,
                [name]: type === 'number' || type === 'radio' ? parseFloat(value) || 0 : value,
            }));
        }
    };

    const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setSettings(prev => ({ ...prev, companyLogo: reader.result as string }));
            };
            reader.readAsDataURL(file);
        }
    };

    const handleRemoveLogo = () => {
        setSettings(prev => ({...prev, companyLogo: ''}));
    };
    
    const handleCodeChange = (e: React.FormEvent) => {
        e.preventDefault();
        if (currentCode !== securityCode) {
            alert('Error: The "Current Security Code" you entered is incorrect.');
            return;
        }
        if (!newCode || newCode.length < 4) {
            alert('Error: The new security code must be at least 4 characters long.');
            return;
        }
        if (newCode !== confirmCode) {
            alert('Error: The new security codes do not match.');
            return;
        }
        setSecurityCode(newCode);
        alert('Success! Your security code has been updated.');
        setCurrentCode('');
        setNewCode('');
        setConfirmCode('');
    };

    const themeOptions: { name: Theme, label: string, icon: React.FC<React.SVGProps<SVGSVGElement>> }[] = [
        { name: 'light', label: 'Light', icon: SunIcon },
        { name: 'dark', label: 'Dark', icon: MoonIcon },
        { name: 'system', label: 'System', icon: ComputerDesktopIcon }
    ];

    return (
        <div className="container mx-auto p-4 sm:p-6 lg:p-8">
            <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-100 mb-6">Settings</h1>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                 <div className="bg-white dark:bg-gray-900 p-6 rounded-xl border border-gray-200 dark:border-gray-800 shadow-sm md:col-span-2">
                    <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100">Cloud Backup</h2>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 mb-4">Keep your data safe and synced across devices by backing up to Google Drive.</p>
                     {isLoggedIn && userInfo ? (
                         <div className="space-y-4">
                            <div className="flex items-center space-x-3 p-3 bg-green-50 dark:bg-green-900/50 rounded-lg">
                                <CheckCircleIcon className="h-6 w-6 text-green-500" />
                                <div>
                                    <p className="font-semibold text-green-800 dark:text-green-300">Signed in as {userInfo.name}</p>
                                    <p className="text-xs text-green-600 dark:text-green-400">Backup is active.</p>
                                </div>
                            </div>
                            <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                                <p className="text-sm font-medium text-gray-600 dark:text-gray-300">Last Backup:</p>
                                <p className="text-sm text-gray-800 dark:text-gray-100">{lastBackupDate ? new Date(lastBackupDate).toLocaleString() : 'No backup found'}</p>
                            </div>
                            <div className="flex items-center space-x-2">
                                <button onClick={onBackup} disabled={isSyncing} className="flex items-center space-x-2 w-full justify-center px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700 disabled:bg-primary-400 disabled:cursor-wait">
                                    {isSyncing ? <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : <CloudArrowUpIcon className="h-5 w-5" />}
                                    <span>{isSyncing ? 'Backing up...' : 'Backup Now'}</span>
                                </button>
                                <button onClick={onRestore} disabled={isSyncing} className="flex items-center space-x-2 w-full justify-center px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-600 disabled:opacity-50">
                                    <CloudArrowDownIcon className="h-5 w-5"/>
                                    <span>Restore from Backup</span>
                                </button>
                            </div>
                            <div className="flex items-center pt-2">
                                <input type="checkbox" id="autoBackupEnabled" name="autoBackupEnabled" checked={settings.autoBackupEnabled} onChange={handleInputChange} className="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500"/>
                                <label htmlFor="autoBackupEnabled" className="ml-2 block text-sm text-gray-900 dark:text-gray-300">Enable automatic daily backup</label>
                            </div>
                         </div>
                     ) : (
                         <div className="text-center p-4 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg">
                            <p className="font-medium text-gray-800 dark:text-gray-200">Backup is not enabled.</p>
                            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Please log in with your Google account to start backing up your data.</p>
                         </div>
                     )}
                 </div>

                 <div className="bg-white dark:bg-gray-900 p-6 rounded-xl border border-gray-200 dark:border-gray-800 shadow-sm md:col-span-2">
                    <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100">Appearance</h2>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 mb-4">Choose your preferred theme.</p>
                     <div className="flex space-x-2 rounded-lg bg-gray-100 dark:bg-gray-800 p-1">
                        {themeOptions.map(option => (
                            <button
                                key={option.name}
                                onClick={() => setTheme(option.name)}
                                className={`w-full flex justify-center items-center space-x-2 px-3 py-2 text-sm font-semibold rounded-md transition-colors ${theme === option.name ? 'bg-white dark:bg-gray-700 shadow text-gray-800 dark:text-gray-50' : 'text-gray-600 dark:text-gray-300 hover:bg-white/50 dark:hover:bg-gray-700/50'}`}
                            >
                                <option.icon className="h-5 w-5" />
                                <span>{option.label}</span>
                            </button>
                        ))}
                    </div>
                 </div>
                 
                <div className="bg-white dark:bg-gray-900 p-6 rounded-xl border border-gray-200 dark:border-gray-800 shadow-sm md:col-span-2">
                    <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100">Invoice Customization</h2>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 mb-4">Add your company branding and custom notes to your invoices.</p>
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="companyName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Company Name</label>
                            <input
                                type="text"
                                name="companyName"
                                id="companyName"
                                value={settings.companyName || ''}
                                onChange={handleInputChange}
                                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                                placeholder="Your Company Name"
                            />
                        </div>
                         <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Company Logo</label>
                            <div className="mt-1 flex items-center space-x-4">
                                {settings.companyLogo ? (
                                    <img src={settings.companyLogo} alt="Company Logo Preview" className="h-16 w-16 object-contain rounded-md bg-gray-100 dark:bg-gray-700 p-1" />
                                ) : (
                                    <div className="h-16 w-16 flex items-center justify-center bg-gray-100 dark:bg-gray-700 rounded-md text-gray-400">
                                        <BuildingOfficeIcon className="h-8 w-8" />
                                    </div>
                                )}
                                <div>
                                    <input type="file" id="logo-upload" className="hidden" accept="image/*" onChange={handleLogoChange} />
                                    <button type="button" onClick={() => document.getElementById('logo-upload')?.click()} className="px-3 py-1.5 text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors">
                                        Upload Logo
                                    </button>
                                    {settings.companyLogo && (
                                        <button type="button" onClick={handleRemoveLogo} className="ml-2 px-3 py-1.5 text-sm font-medium text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300">
                                            Remove
                                        </button>
                                    )}
                                </div>
                            </div>
                            <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">Recommended: Square image (PNG or JPG) under 50KB.</p>
                        </div>
                        <div>
                            <label htmlFor="notes" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Notes</label>
                            <textarea
                                name="notes"
                                id="notes"
                                value={settings.notes || ''}
                                onChange={handleInputChange}
                                rows={3}
                                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                                placeholder="e.g. All items are non-refundable."
                            />
                            <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">Appears at the very bottom of invoices. If left empty, nothing will be shown.</p>
                        </div>
                    </div>
                </div>
                 <div className="bg-white dark:bg-gray-900 p-6 rounded-xl border border-gray-200 dark:border-gray-800 shadow-sm md:col-span-2">
                    <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100">Security</h2>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 mb-4">Change the security code required for sensitive actions like deletions or manual balance adjustments.</p>
                    <form onSubmit={handleCodeChange} className="space-y-4">
                        <div>
                            <label htmlFor="currentCode" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Current Security Code</label>
                            <input
                                type="password"
                                name="currentCode"
                                id="currentCode"
                                value={currentCode}
                                onChange={(e) => setCurrentCode(e.target.value)}
                                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                                required
                            />
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="newCode" className="block text-sm font-medium text-gray-700 dark:text-gray-300">New Security Code</label>
                                <input
                                    type="password"
                                    name="newCode"
                                    id="newCode"
                                    value={newCode}
                                    onChange={(e) => setNewCode(e.target.value)}
                                    className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                                    required
                                />
                            </div>
                            <div>
                                <label htmlFor="confirmCode" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Confirm New Code</label>
                                <input
                                    type="password"
                                    name="confirmCode"
                                    id="confirmCode"
                                    value={confirmCode}
                                    onChange={(e) => setConfirmCode(e.target.value)}
                                    className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                                    required
                                />
                            </div>
                        </div>
                        <div className="pt-2">
                             <button type="submit" className="flex items-center space-x-2 px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
                                <LockIcon className="h-4 w-4" />
                                <span>Update Code</span>
                            </button>
                        </div>
                    </form>
                 </div>
            </div>
        </div>
    );
};

export default SettingsPage;