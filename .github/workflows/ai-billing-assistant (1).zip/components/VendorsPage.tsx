import React, { useState, useMemo } from 'react';
import type { Vendor, Product, LineItem, PurchaseBill, Transaction } from '../types';
import SearchIcon from './icons/SearchIcon';
import UserPlusIcon from './icons/UserPlusIcon';
import DocumentTextIcon from './icons/DocumentTextIcon';
import CurrencyRupeeIcon from './icons/CurrencyRupeeIcon';
import ArchiveBoxIcon from './icons/ArchiveBoxIcon';
import AddVendorModal from './modals/AddVendorModal';
import RecordPurchaseModal from './modals/RecordPurchaseModal';
import LogClaimModal from './modals/LogClaimModal';
import RecordPaymentModal from './modals/RecordPaymentModal';
import VendorsIcon from './icons/VendorsIcon';
import TrashIcon from './icons/TrashIcon';
import PencilIcon from './icons/PencilIcon';
import ConfirmationModal from './modals/ConfirmationModal';
import ViewPurchaseBillModal from './modals/ViewPurchaseBillModal';

interface VendorsPageProps {
  vendors: Vendor[];
  setVendors: React.Dispatch<React.SetStateAction<Vendor[]>>;
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  purchaseBills: PurchaseBill[];
  setPurchaseBills: React.Dispatch<React.SetStateAction<PurchaseBill[]>>;
  securityCode: string;
}

const VendorsPage: React.FC<VendorsPageProps> = ({ vendors, setVendors, products, setProducts, purchaseBills, setPurchaseBills, securityCode }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedVendorId, setSelectedVendorId] = useState<string | null>(null);

  const [isAddModalOpen, setAddModalOpen] = useState(false);
  const [isPurchaseModalOpen, setPurchaseModalOpen] = useState(false);
  const [isClaimModalOpen, setClaimModalOpen] = useState(false);
  const [isPaymentModalOpen, setPaymentModalOpen] = useState(false);
  const [vendorToEdit, setVendorToEdit] = useState<Vendor | null>(null);
  const [itemToDelete, setItemToDelete] = useState<string | null>(null);
  const [viewingPurchase, setViewingPurchase] = useState<PurchaseBill | null>(null);
  const [pendingBalanceChange, setPendingBalanceChange] = useState<{ vendor: Vendor; originalBalance: number } | null>(null);


  const filteredVendors = useMemo(() => {
    return vendors.filter(vendor =>
      vendor.name.toLowerCase().includes(searchTerm.toLowerCase())
    ).sort((a, b) => a.name.localeCompare(b.name));
  }, [vendors, searchTerm]);

  const selectedVendor = useMemo(() => {
    return vendors.find(c => c.id === selectedVendorId) || null;
  }, [vendors, selectedVendorId]);

  const handleOpenAddModal = () => {
    setVendorToEdit(null);
    setAddModalOpen(true);
  };
  
  const handleOpenEditModal = (vendor: Vendor) => {
    setVendorToEdit(vendor);
    setAddModalOpen(true);
  };

  const handleSaveVendor = (vendor: Vendor) => {
    const originalVendor = vendors.find(v => v.id === vendor.id);

    if (originalVendor && originalVendor.balance !== vendor.balance) {
      setPendingBalanceChange({ vendor, originalBalance: originalVendor.balance });
    } else {
      setVendors(prev => {
        const exists = prev.some(v => v.id === vendor.id);
        if (exists) {
          return prev.map(v => (v.id === vendor.id ? vendor : v));
        }
        return [...prev, vendor];
      });
    }
    setAddModalOpen(false);
  };

  const confirmBalanceChange = () => {
    if (!pendingBalanceChange) return;

    const { vendor, originalBalance } = pendingBalanceChange;
    const adjustmentAmount = vendor.balance - originalBalance;
    
    const adjustmentTransaction: Transaction = {
      id: crypto.randomUUID(),
      date: new Date().toISOString(),
      description: 'Manual Balance Adjustment',
      amount: adjustmentAmount,
      balanceAfter: vendor.balance,
      type: 'adjustment',
    };

    setVendors(prev => prev.map(v => 
      v.id === vendor.id 
        ? { ...vendor, transactions: [adjustmentTransaction, ...v.transactions] } 
        : v
    ));
    setPendingBalanceChange(null);
  };

  const handleDeleteVendor = (vendorId: string) => {
    setItemToDelete(vendorId);
  };
  
  const confirmDeleteVendor = () => {
    if (!itemToDelete) return;
    setVendors(prevVendors => prevVendors.filter(v => v.id !== itemToDelete));
    if (selectedVendorId === itemToDelete) {
      setSelectedVendorId(null);
    }
    setItemToDelete(null);
  };

  const handleSavePurchase = (items: LineItem[], total: number) => {
    if (!selectedVendorId) return;
    
    const newPurchaseBill: PurchaseBill = {
        id: crypto.randomUUID(),
        vendorId: selectedVendorId,
        date: new Date().toISOString(),
        items,
        total,
    };
    setPurchaseBills(prev => [newPurchaseBill, ...prev]);

    setVendors(prev => prev.map(v => {
        if (v.id === selectedVendorId) {
            const newBalance = v.balance + total;
            const newTransaction: Transaction = {
                id: crypto.randomUUID(),
                date: new Date().toISOString(),
                description: `Purchase Bill #${newPurchaseBill.id.slice(-6)}`,
                amount: total,
                balanceAfter: newBalance,
                relatedId: newPurchaseBill.id,
                type: 'purchase',
            };
            return { ...v, balance: newBalance, transactions: [newTransaction, ...v.transactions] };
        }
        return v;
    }));

    setProducts(prevProducts => {
        const updatedProducts = [...prevProducts];
        items.forEach(item => {
            const productIndex = updatedProducts.findIndex(p => p.id === item.id);
            if (productIndex !== -1) {
                updatedProducts[productIndex].quantity += item.quantity;
            }
        });
        return updatedProducts;
    });

    setPurchaseModalOpen(false);
    alert('Purchase recorded successfully!');
  };

  const handleSaveClaim = ({ description, amount, replacementProductId }: { description: string; amount: number; replacementProductId?: string; }) => {
    if (!selectedVendorId) return;

    const isImmediateResolution = amount !== 0 || !!replacementProductId;

    setVendors(prev => prev.map(v => {
      if (v.id === selectedVendorId) {
        let newBalance = v.balance;
        const transactionsToAdd: Transaction[] = [];

        // For vendors, a claim amount reduces the balance we owe them.
        const effectiveAmount = -amount;

        if (amount !== 0) {
          newBalance += effectiveAmount;
          transactionsToAdd.push({
            id: crypto.randomUUID(),
            date: new Date().toISOString(),
            description: `Claim: ${description}`,
            amount: effectiveAmount,
            balanceAfter: newBalance,
            type: 'claim',
          });
        }

        if (replacementProductId) {
          const product = products.find(p => p.id === replacementProductId);
          if (product) {
            transactionsToAdd.push({
              id: crypto.randomUUID(),
              date: new Date().toISOString(),
              description: `Replacement Received: ${product.name}`,
              amount: 0,
              balanceAfter: newBalance,
              type: 'claim',
            });
          }
        }
        
        const newClaim = {
          id: crypto.randomUUID(),
          date: new Date().toISOString(),
          description,
          amount,
          status: isImmediateResolution ? 'Resolved' as const : 'Pending' as const,
        };

        if (!isImmediateResolution) {
            transactionsToAdd.push({
                id: crypto.randomUUID(),
                date: new Date().toISOString(),
                description: `Claim Logged: ${description}`,
                amount: 0,
                balanceAfter: v.balance,
                type: 'claim',
            });
        }
        
        return {
          ...v,
          balance: newBalance,
          claims: [newClaim, ...v.claims],
          transactions: [...transactionsToAdd, ...v.transactions],
        };
      }
      return v;
    }));
    
    if (replacementProductId) {
      // We received a replacement from the vendor, so our stock increases.
      setProducts(prev => prev.map(p =>
        p.id === replacementProductId ? { ...p, quantity: p.quantity + 1 } : p
      ));
    }

    setClaimModalOpen(false);
    alert(`Claim ${isImmediateResolution ? 'processed' : 'logged'} successfully!`);
  };


   const handleToggleClaimStatus = (claimId: string) => {
    if (!selectedVendorId) return;
    setVendors(prev => prev.map(v => {
        if (v.id === selectedVendorId) {
            return {
                ...v,
                claims: v.claims.map(claim => 
                    claim.id === claimId 
                    ? { ...claim, status: claim.status === 'Pending' ? 'Resolved' : 'Pending' }
                    : claim
                )
            };
        }
        return v;
    }));
  };

  const handleSavePayment = (amount: number) => {
    if (!selectedVendorId) return;
    
    setVendors(prev => prev.map(v => {
        if (v.id === selectedVendorId) {
            const newBalance = v.balance - amount;
            const newTransaction: Transaction = {
                id: crypto.randomUUID(),
                date: new Date().toISOString(),
                description: 'Payment Made',
                amount: -amount,
                balanceAfter: newBalance,
                type: 'payment',
            };
            return { ...v, balance: newBalance, transactions: [newTransaction, ...v.transactions] };
        }
        return v;
    }));
    
    setPaymentModalOpen(false);
    alert('Payment recorded successfully!');
  };

  return (
    <div className="container mx-auto p-4 sm:p-6 lg:p-8 h-full">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
        {/* Left Panel: Vendor List */}
        <div className="lg:col-span-1 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm flex flex-col h-[calc(100vh-10rem)]">
          <div className="p-4 border-b border-slate-200 dark:border-slate-700">
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">Vendors / Suppliers</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400">Select a vendor to view details.</p>
            <div className="mt-4 flex items-center space-x-2">
              <div className="relative flex-grow">
                  <SearchIcon className="h-5 w-5 text-slate-400 absolute top-1/2 left-3 -translate-y-1/2" />
                  <input
                      type="text"
                      placeholder="Search vendors..."
                      value={searchTerm}
                      onChange={e => setSearchTerm(e.target.value)}
                      className="pl-10 pr-4 py-2 w-full border border-slate-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-900 focus:ring-2 focus:ring-primary-500 focus:outline-none text-sm"
                  />
              </div>
              <button onClick={handleOpenAddModal} className="flex-shrink-0 p-2 text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500">
                  <UserPlusIcon className="h-5 w-5" />
              </button>
            </div>
          </div>
          <div className="overflow-y-auto flex-1">
            {filteredVendors.length > 0 ? (
                <ul>
                    {filteredVendors.map(vendor => (
                        <li key={vendor.id} onClick={() => setSelectedVendorId(vendor.id)} className={`group relative p-4 border-b border-slate-200 dark:border-slate-700 cursor-pointer transition-colors ${selectedVendorId === vendor.id ? 'bg-primary-50 dark:bg-primary-900/50' : 'hover:bg-slate-50 dark:hover:bg-slate-700/50'}`}>
                            <p className="font-semibold text-slate-800 dark:text-slate-100">{vendor.name}</p>
                            <p className="text-sm text-slate-500 dark:text-slate-400">Balance: Rs.{vendor.balance.toFixed(2)}</p>
                             <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button 
                                    onClick={(e) => { e.stopPropagation(); handleOpenEditModal(vendor); }} 
                                    className="p-2 text-slate-500 hover:text-primary-600 dark:hover:text-primary-400 rounded-full hover:bg-slate-200 dark:hover:bg-slate-600"
                                    aria-label={`Edit ${vendor.name}`}
                                >
                                    <PencilIcon className="h-4 w-4" />
                                </button>
                                <button 
                                    onClick={(e) => { e.stopPropagation(); handleDeleteVendor(vendor.id); }} 
                                    className="p-2 text-slate-500 hover:text-red-600 dark:hover:text-red-400 rounded-full hover:bg-slate-200 dark:hover:bg-slate-600"
                                    aria-label={`Delete ${vendor.name}`}
                                >
                                    <TrashIcon className="h-4 w-4" />
                                </button>
                            </div>
                        </li>
                    ))}
                </ul>
            ) : (
                <p className="text-center p-8 text-slate-500 dark:text-slate-400">No vendors found.</p>
            )}
          </div>
        </div>

        {/* Right Panel: Vendor Details */}
        <div className="lg:col-span-2 space-y-6 overflow-y-auto h-[calc(100vh-8.5rem)] pr-2">
          {selectedVendor ? (
            <>
              <div className="bg-white dark:bg-slate-800 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                 <div className="flex justify-between items-start">
                    <div>
                        <h3 className="text-2xl font-bold text-slate-800 dark:text-slate-100">{selectedVendor.name}</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">
                            {selectedVendor.contactNumbers.length > 0 ? selectedVendor.contactNumbers.join(', ') : 'No contact info'}
                        </p>
                    </div>
                    <div className="text-right">
                        <p className="text-sm text-slate-500 dark:text-slate-400">Current Balance</p>
                        <p className="text-3xl font-bold text-red-600 dark:text-red-400">Rs.{selectedVendor.balance.toFixed(2)}</p>
                    </div>
                 </div>
                 <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-700 flex flex-wrap gap-2">
                    <button onClick={() => setPurchaseModalOpen(true)} className="flex items-center space-x-2 px-3 py-2 text-sm text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-700 rounded-md hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">
                        <ArchiveBoxIcon className="h-5 w-5" />
                        <span>Record Purchase</span>
                    </button>
                    <button onClick={() => setClaimModalOpen(true)} className="flex items-center space-x-2 px-3 py-2 text-sm text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-700 rounded-md hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">
                        <DocumentTextIcon className="h-5 w-5" />
                        <span>Log a Claim</span>
                    </button>
                     <button onClick={() => setPaymentModalOpen(true)} className="flex items-center space-x-2 px-3 py-2 text-sm text-white bg-green-600 rounded-md hover:bg-green-700 transition-colors">
                        <CurrencyRupeeIcon className="h-5 w-5" />
                        <span>Record Payment</span>
                    </button>
                 </div>
              </div>
              <div className="bg-white dark:bg-slate-800 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                  <h4 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-4">Transaction History</h4>
                  <div className="overflow-x-auto">
                     {selectedVendor.transactions.length > 0 ? (
                       <table className="min-w-full text-sm">
                        <thead className="bg-slate-50 dark:bg-slate-700/50">
                            <tr>
                                <th className="text-left font-medium p-2 text-slate-500 dark:text-slate-400">Date</th>
                                <th className="text-left font-medium p-2 text-slate-500 dark:text-slate-400">Description</th>
                                <th className="text-right font-medium p-2 text-slate-500 dark:text-slate-400">Debit</th>
                                <th className="text-right font-medium p-2 text-slate-500 dark:text-slate-400">Credit</th>
                                <th className="text-right font-medium p-2 text-slate-500 dark:text-slate-400">Balance</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                           {[...selectedVendor.transactions].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(tx => {
                            const isPurchase = tx.type === 'purchase' && tx.relatedId;
                            return (
                                <tr 
                                    key={tx.id}
                                    onClick={() => {
                                        if (isPurchase) {
                                            const purchase = purchaseBills.find(p => p.id === tx.relatedId);
                                            if (purchase) setViewingPurchase(purchase);
                                        }
                                    }}
                                    className={isPurchase ? 'cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700' : ''}
                                >
                                    <td className="p-2 whitespace-nowrap text-slate-500 dark:text-slate-400">{new Date(tx.date).toLocaleDateString()}</td>
                                    <td className={`p-2 text-slate-700 dark:text-slate-200 ${isPurchase ? 'font-semibold text-primary-600 dark:text-primary-400' : ''}`}>{tx.description}</td>
                                    <td className="p-2 text-right font-mono text-green-600 dark:text-green-400">{tx.amount < 0 ? (-tx.amount).toFixed(2) : '-'}</td>
                                    <td className="p-2 text-right font-mono text-red-600 dark:text-red-400">{tx.amount > 0 ? tx.amount.toFixed(2) : '-'}</td>
                                    <td className="p-2 text-right font-semibold font-mono text-slate-800 dark:text-slate-100">Rs.{tx.balanceAfter.toFixed(2)}</td>
                                </tr>
                            )
                           })}
                        </tbody>
                       </table>
                     ) : (
                        <p className="text-center p-8 text-slate-500 dark:text-slate-400">No transactions found</p>
                     )}
                  </div>
              </div>
              
                <div className="bg-white dark:bg-slate-800 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                  <h4 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-4">Claim History</h4>
                  <div className="overflow-x-auto">
                     {selectedVendor.claims.length > 0 ? (
                       <table className="min-w-full text-sm">
                        <thead className="bg-slate-50 dark:bg-slate-700/50">
                            <tr>
                                <th className="text-left font-medium p-2 text-slate-500 dark:text-slate-400">Date</th>
                                <th className="text-left font-medium p-2 text-slate-500 dark:text-slate-400">Description</th>
                                <th className="text-right font-medium p-2 text-slate-500 dark:text-slate-400">Amount</th>
                                <th className="text-center font-medium p-2 text-slate-500 dark:text-slate-400">Status</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                           {selectedVendor.claims.map(claim => (
                            <tr key={claim.id}>
                                <td className="p-2 whitespace-nowrap text-slate-500 dark:text-slate-400">{new Date(claim.date).toLocaleDateString()}</td>
                                <td className="p-2 text-slate-700 dark:text-slate-200">{claim.description}</td>
                                <td className="p-2 text-right font-semibold font-mono text-slate-800 dark:text-slate-100">Rs.{claim.amount.toFixed(2)}</td>
                                <td className="p-2 text-center">
                                    {claim.status === 'Pending' ? (
                                        <button onClick={() => handleToggleClaimStatus(claim.id)} className="px-2 py-0.5 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300 hover:bg-yellow-200">
                                            {claim.status}
                                        </button>
                                    ) : (
                                        <span className="px-2 py-0.5 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">
                                            {claim.status}
                                        </span>
                                    )}
                                </td>
                            </tr>
                           ))}
                        </tbody>
                       </table>
                     ) : (
                        <p className="text-center p-8 text-slate-500 dark:text-slate-400">No claims found</p>
                     )}
                  </div>
              </div>
            </>
          ) : (
             <div className="bg-white dark:bg-slate-800 p-8 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm text-center h-full flex flex-col justify-center items-center">
                 <VendorsIcon className="h-16 w-16 text-slate-300 dark:text-slate-600" />
                <h3 className="mt-4 text-xl font-semibold text-slate-800 dark:text-slate-100">Select a Vendor</h3>
                <p className="mt-1 text-slate-500 dark:text-slate-400">Choose a vendor from the list to see their transaction history and details.</p>
             </div>
          )}
        </div>
      </div>
      
      <AddVendorModal isOpen={isAddModalOpen} onClose={() => setAddModalOpen(false)} onSave={handleSaveVendor} vendorToEdit={vendorToEdit} />
      {selectedVendor && (
        <>
            <RecordPurchaseModal isOpen={isPurchaseModalOpen} onClose={() => setPurchaseModalOpen(false)} onSave={handleSavePurchase} vendor={selectedVendor} products={products} />
            <LogClaimModal isOpen={isClaimModalOpen} onClose={() => setClaimModalOpen(false)} onSave={handleSaveClaim} party={selectedVendor} products={products} partyType="vendor" />
            <RecordPaymentModal isOpen={isPaymentModalOpen} onClose={() => setPaymentModalOpen(false)} onSave={handleSavePayment} party={selectedVendor} />
            <ViewPurchaseBillModal isOpen={!!viewingPurchase} onClose={() => setViewingPurchase(null)} purchaseBill={viewingPurchase!} vendor={selectedVendor} />
        </>
      )}

      <ConfirmationModal
        isOpen={!!itemToDelete}
        onClose={() => setItemToDelete(null)}
        onConfirm={confirmDeleteVendor}
        title="Delete Vendor"
        message="Are you sure you want to delete this vendor? This action cannot be undone."
        requiresCode={true}
        securityCode={securityCode}
        confirmButtonText="Confirm Deletion"
      />
      
      <ConfirmationModal
        isOpen={!!pendingBalanceChange}
        onClose={() => setPendingBalanceChange(null)}
        onConfirm={confirmBalanceChange}
        title="Confirm Balance Change"
        message={`You are about to manually change the balance for ${pendingBalanceChange?.vendor.name}. This will be recorded as a new transaction. Please confirm.`}
        requiresCode={true}
        securityCode={securityCode}
        confirmButtonText="Confirm Change"
      />

    </div>
  );
};

export default VendorsPage;