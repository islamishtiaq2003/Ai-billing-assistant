import React from 'react';
import type { Invoice } from '../types.ts';
import { InvoiceStatus } from '../types.ts';
import PlusIcon from './icons/PlusIcon.tsx';

interface InvoiceListProps {
  invoices: Invoice[];
  onSelectInvoice: (invoice: Invoice) => void;
  onCreateNew: () => void;
}

const statusColors: { [key in InvoiceStatus]: string } = {
  [InvoiceStatus.Paid]: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
  [InvoiceStatus.Draft]: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
  [InvoiceStatus.Overdue]: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
};

const calculateTotal = (invoice: Invoice): string => {
  return invoice.items.reduce((sum, item) => sum + item.quantity * item.price, 0).toFixed(2);
};

const InvoiceList: React.FC<InvoiceListProps> = ({ invoices, onSelectInvoice, onCreateNew }) => {
  return (
    <div className="container mx-auto p-4 sm:p-6 lg:p-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold text-gray-800 dark:text-gray-100">Invoices</h2>
        <button
          onClick={onCreateNew}
          className="flex items-center space-x-2 px-4 py-2 text-white bg-primary-600 rounded-lg shadow-md hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-opacity-75 transition-colors"
        >
          <PlusIcon className="h-5 w-5" />
          <span>New Invoice</span>
        </button>
      </div>

      {invoices.length === 0 ? (
        <div className="text-center py-16 px-6 bg-white dark:bg-gray-800 rounded-lg shadow-md">
          <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          <h3 className="mt-2 text-lg font-medium text-gray-900 dark:text-gray-100">No invoices yet</h3>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Get started by creating your first invoice.</p>
        </div>
      ) : (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
          <ul className="divide-y divide-gray-200 dark:divide-gray-700">
            {invoices.map((invoice) => (
              <li 
                key={invoice.id} 
                onClick={() => onSelectInvoice(invoice)} 
                className="hover:bg-gray-50 dark:hover:bg-gray-700/50 cursor-pointer transition-colors"
                role="button"
                tabIndex={0}
                onKeyDown={(e) => e.key === 'Enter' && onSelectInvoice(invoice)}
              >
                <div className="p-4 sm:p-6">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-primary-600 dark:text-primary-400 truncate">Invoice #{invoice.invoiceNumber}</p>
                    <div className="ml-2 flex-shrink-0 flex">
                      <p className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusColors[invoice.status]}`}>
                        {invoice.status}
                      </p>
                    </div>
                  </div>
                  <div className="mt-2 sm:flex sm:justify-between">
                    <div className="sm:flex">
                      <p className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                        {invoice.customerName}
                      </p>
                    </div>
                    <div className="mt-2 flex items-center text-sm text-gray-500 dark:text-gray-400 sm:mt-0">
                      <p className="font-bold text-lg text-gray-800 dark:text-gray-200">Rs.{calculateTotal(invoice)}</p>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default InvoiceList;