import React from 'react';
import type { LineItem, BillSettings, InvoiceType } from '../types.ts';
import CubeIcon from './icons/CubeIcon.tsx';

interface InvoicePreviewProps {
    invoiceNumber: string;
    invoiceDate: string;
    items: (LineItem & { billItemId: string })[];
    billSettings: BillSettings;
    grandTotal: number;
    invoiceType: InvoiceType;
    discountAmount?: number;
    claimCharges?: number;
    customerName?: string;
    oldBalance?: number;
    subtotal: number;
}

const InvoicePreview: React.FC<InvoicePreviewProps> = ({
    invoiceNumber,
    invoiceDate,
    items,
    billSettings,
    grandTotal,
    invoiceType,
    discountAmount,
    claimCharges,
    customerName,
    oldBalance,
    subtotal,
}) => {
    const formattedDate = new Date(invoiceDate).toLocaleDateString('en-US', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    });

    const isSmallFormat = invoiceType === 'Retail' || invoiceType === 'Return / Credit';
    const previewWidth = isSmallFormat ? '300px' : `${billSettings.width * 100}px`;

    return (
        <div
            className="bg-white text-black font-sans p-4 shadow-lg rounded-lg text-[10px]"
            style={{ width: previewWidth, border: '1px solid #333' }}
        >
            {/* Header */}
            <div className="flex justify-between items-start pb-2">
                <div>
                    <p className="font-bold text-lg">{billSettings.companyName || 'Your Company Name'}</p>
                    {billSettings.companyLogo ? (
                         <img src={billSettings.companyLogo} alt="Company Logo" className="h-10 w-10 object-contain rounded-md bg-gray-100 mt-1 p-1" />
                    ) : (
                        <div className="bg-black text-white p-2 rounded-md mt-1 inline-block">
                           <CubeIcon className="w-6 h-6" />
                        </div>
                    )}
                </div>
                <div className="text-right">
                    <h2 className="font-bold text-lg tracking-wide">INVOICE</h2>
                    <p className="font-mono mt-1">#{invoiceNumber}</p>
                    <p className="mt-1">Date: {formattedDate}</p>
                </div>
            </div>

            <div className="text-left text-xs pb-2">
                <p><span className="font-bold">To:</span> {customerName || 'Walking Customer'}</p>
            </div>

            <div className="border-b border-black w-full my-2"></div>

            {/* Item Headers */}
            <div className="flex justify-between font-bold py-1 text-xs">
                <span className="w-[25%] text-left">Total</span>
                <span className="w-[20%] text-left">Price</span>
                <span className="w-[15%] text-center">Qty</span>
                <span className="w-[40%] text-right">Item</span>
            </div>
            
            <div className="border-b border-black w-full"></div>


            <div className="min-h-[100px] py-2 text-xs">
                {items.length === 0 ? (
                    <p className="text-gray-500 text-center py-10">No items added yet</p>
                ) : (
                    <div className="space-y-1">
                        {items.map(item => (
                             <div key={item.billItemId} className="flex justify-between items-start">
                                <span className="w-[25%] text-left">{(item.quantity * item.price).toFixed(2)}</span>
                                <span className="w-[20%] text-left">{item.price.toFixed(2)}</span>
                                <span className="w-[15%] text-center">{item.quantity}</span>
                                <span className="w-[40%] text-right break-words">{item.name}</span>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* Footer */}
            <div className="mt-auto pt-2">
                 <div className="border-t-2 border-black my-2"></div>
                 
                {(invoiceType === 'Wholesale' || invoiceType === 'Return / Credit') ? (
                    <>
                        <div className="flex justify-between items-center text-xs mb-1">
                            <span className="font-semibold">{invoiceType === 'Return / Credit' ? 'Return Total' : 'Total'}</span>
                            <span className="font-semibold">Rs.{subtotal.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between items-center text-xs mb-1">
                            <span className="font-semibold">Old Balance</span>
                            <span className="font-semibold">Rs.{(oldBalance || 0).toFixed(2)}</span>
                        </div>
                    </>
                ) : (
                    <>
                        {discountAmount && discountAmount > 0 && (
                            <div className="flex justify-between items-center text-xs mb-1">
                                <span className="font-semibold">Discount</span>
                                <span className="font-semibold">- Rs.{discountAmount.toFixed(2)}</span>
                            </div>
                        )}

                        {claimCharges && claimCharges > 0 && (
                            <div className="flex justify-between items-center text-xs mb-1">
                                <span className="font-semibold">Claim Charges</span>
                                <span className="font-semibold">+ Rs.{claimCharges.toFixed(2)}</span>
                            </div>
                        )}
                    </>
                )}
                 
                 <div className="flex justify-start items-end mt-1">
                    <div>
                        <p className="text-xs">Grand Total</p>
                        <p className="font-bold text-xl">Rs.{grandTotal.toFixed(2)}</p>
                    </div>
                </div>
            </div>
            
            {billSettings.notes && billSettings.notes.trim() !== '' && (
                <div className="mt-2 pt-2 border-t border-dashed border-black">
                    <p className="text-center text-[9px] italic whitespace-pre-wrap">{billSettings.notes}</p>
                </div>
            )}
        </div>
    );
};

export default InvoicePreview;