
import React, { useState, useEffect } from 'react';
import type { Vendor } from '../../types';
import XMarkIcon from '../icons/XMarkIcon';
import PlusCircleIcon from '../icons/PlusCircleIcon';

interface AddVendorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (vendor: Vendor) => void;
  vendorToEdit?: Vendor | null;
}

const AddVendorModal: React.FC<AddVendorModalProps> = ({ isOpen, onClose, onSave, vendorToEdit }) => {
  const [name, setName] = useState('');
  const [contactNumbers, setContactNumbers] = useState(['']);
  const [bankAccounts, setBankAccounts] = useState(['']);
  const [balance, setBalance] = useState('');

  const isEditing = !!vendorToEdit;

  useEffect(() => {
    if (isOpen) {
      if (isEditing && vendorToEdit) {
        setName(vendorToEdit.name);
        setContactNumbers(vendorToEdit.contactNumbers.length > 0 ? vendorToEdit.contactNumbers : ['']);
        setBankAccounts(vendorToEdit.bankAccounts.length > 0 ? vendorToEdit.bankAccounts : ['']);
        setBalance(vendorToEdit.balance.toString());
      } else {
        setName('');
        setContactNumbers(['']);
        setBankAccounts(['']);
        setBalance('');
      }
    }
  }, [isOpen, vendorToEdit, isEditing]);


  const handleDynamicChange = (setter: React.Dispatch<React.SetStateAction<string[]>>, index: number, value: string) => {
    setter(prev => {
        const newItems = [...prev];
        newItems[index] = value;
        return newItems;
    });
  };

  const addDynamicField = (setter: React.Dispatch<React.SetStateAction<string[]>>) => {
    setter(prev => [...prev, '']);
  };

  const removeDynamicField = (setter: React.Dispatch<React.SetStateAction<string[]>>, fields: string[], index: number) => {
    if (fields.length > 1) {
      setter(prev => prev.filter((_, i) => i !== index));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
        alert('Vendor name is required.');
        return;
    }
    const newBalance = parseFloat(balance) || 0;
    const vendorData: Vendor = {
      id: vendorToEdit?.id || crypto.randomUUID(),
      name: name.trim(),
      contactNumbers: contactNumbers.filter(n => n.trim() !== ''),
      bankAccounts: bankAccounts.filter(b => b.trim() !== ''),
      balance: newBalance,
      transactions: vendorToEdit?.transactions || (newBalance > 0 ? [{
        id: crypto.randomUUID(),
        date: new Date().toISOString().split('T')[0],
        description: 'Opening Balance',
        amount: newBalance,
        balanceAfter: newBalance,
        type: 'opening_balance',
      }] : []),
      claims: vendorToEdit?.claims || [],
    };
    onSave(vendorData);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 backdrop-blur-sm" aria-modal="true" role="dialog">
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-md m-4">
        <form onSubmit={handleSubmit}>
          <div className="p-5 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center">
            <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">{isEditing ? 'Edit Vendor' : 'Add New Vendor'}</h3>
            <button type="button" onClick={onClose} className="p-1 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700">
              <XMarkIcon className="h-6 w-6" />
            </button>
          </div>
          <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
            <div>
              <label htmlFor="vendorName" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Vendor Name</label>
              <input type="text" id="vendorName" value={name} onChange={e => setName(e.target.value)} required className="block w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Contact Numbers</label>
              <div className="space-y-2">
                {contactNumbers.map((number, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <input type="text" placeholder="e.g. 0300-1234567" value={number} onChange={e => handleDynamicChange(setContactNumbers, index, e.target.value)} className="block w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm" />
                    {index > 0 && (
                      <button type="button" onClick={() => removeDynamicField(setContactNumbers, contactNumbers, index)} className="text-slate-400 hover:text-red-500">
                        <XMarkIcon className="h-5 w-5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
              <button type="button" onClick={() => addDynamicField(setContactNumbers)} className="mt-2 flex items-center text-sm font-medium text-primary-600 hover:text-primary-800 dark:text-primary-400 dark:hover:text-primary-200">
                 <PlusCircleIcon className="h-5 w-5 mr-1" /> Add Another Number
              </button>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Bank Accounts</label>
              <div className="space-y-2">
                {bankAccounts.map((account, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <input type="text" placeholder="e.g. Bank Al-Habib 1234..." value={account} onChange={e => handleDynamicChange(setBankAccounts, index, e.target.value)} className="block w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm" />
                    {index > 0 && (
                      <button type="button" onClick={() => removeDynamicField(setBankAccounts, bankAccounts, index)} className="text-slate-400 hover:text-red-500">
                        <XMarkIcon className="h-5 w-5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
              <button type="button" onClick={() => addDynamicField(setBankAccounts)} className="mt-2 flex items-center text-sm font-medium text-primary-600 hover:text-primary-800 dark:text-primary-400 dark:hover:text-primary-200">
                 <PlusCircleIcon className="h-5 w-5 mr-1" /> Add Bank Account
              </button>
            </div>
             <div>
              <label htmlFor="balance" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{isEditing ? 'Current Balance' : 'Opening Balance (Optional)'}</label>
              <input 
                type="number" 
                name="balance" 
                id="balance" 
                placeholder={isEditing ? 'Manual balance adjustment' : "Enter if you owe this vendor"}
                value={balance}
                onChange={e => setBalance(e.target.value)}
                className="block w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm" 
              />
               {isEditing && (
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  Changing this value will require security code confirmation and create a "Manual Balance Adjustment" transaction.
                </p>
              )}
            </div>
          </div>
          <div className="px-6 py-4 bg-slate-50 dark:bg-slate-900/50 border-t border-slate-200 dark:border-slate-700 flex justify-end space-x-2">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md hover:bg-slate-50 dark:hover:bg-slate-600 transition-colors">Cancel</button>
            <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">{isEditing ? 'Update Vendor' : 'Save Vendor'}</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddVendorModal;