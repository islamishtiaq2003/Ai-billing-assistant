

import React, { useRef } from 'react';
import type { StaffMember, BillSettings } from '../../types';
import html2canvas from 'html2canvas';
import XMarkIcon from '../icons/XMarkIcon';
import ArrowDownTrayIcon from '../icons/ArrowDownTrayIcon';
import PrintIcon from '../icons/PrintIcon';

interface SalaryReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  staff: StaffMember;
  advances: number;
  salaryPaid: number;
  payPeriod: string;
  billSettings: BillSettings;
}

const SalaryReceiptModal: React.FC<SalaryReceiptModalProps> = ({
  isOpen,
  onClose,
  staff,
  advances,
  salaryPaid,
  payPeriod,
  billSettings
}) => {
  const receiptRef = useRef<HTMLDivElement>(null);

  const handleSave = () => {
    if (receiptRef.current) {
      html2canvas(receiptRef.current, { backgroundColor: '#ffffff' }).then(canvas => {
        const link = document.createElement('a');
        link.download = `Salary_Slip_${staff.name.replace(' ', '_')}_${payPeriod}.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();
      });
    }
  };

  const handlePrint = () => {
    if (receiptRef.current) {
        const content = receiptRef.current.innerHTML;
        const iframe = document.createElement('iframe');
        iframe.style.position = 'absolute';
        iframe.style.width = '0';
        iframe.style.height = '0';
        iframe.style.border = '0';
        document.body.appendChild(iframe);

        const doc = iframe.contentWindow?.document;
        if (doc) {
            doc.open();
            doc.write('<html><head><title>Salary Slip</title>');
            doc.write('<style>body { font-family: sans-serif; width: 300px; margin: auto; color: black; } table { width: 100%; border-collapse: collapse; } img { max-width: 100%; }</style>');
            doc.write('</head><body>');
            doc.write(content);
            doc.write('</body></html>');
            doc.close();
            
            iframe.contentWindow?.focus();
            iframe.contentWindow?.print();
        }

        setTimeout(() => {
            document.body.removeChild(iframe);
        }, 1000);
    }
  };


  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 backdrop-blur-sm" aria-modal="true" role="dialog">
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-sm m-4">
        <div className="p-5 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center">
          <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">Salary Receipt Generated</h3>
          <button type="button" onClick={onClose} className="p-1 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700">
            <XMarkIcon className="h-6 w-6" />
          </button>
        </div>
        <div className="p-6 bg-slate-100 dark:bg-slate-900/50">
           <div ref={receiptRef} className="bg-white p-4 text-black text-sm w-[300px] mx-auto font-sans">
              <div className="text-center mb-4">
                {billSettings.companyLogo && (
                    <img src={billSettings.companyLogo} alt="Company Logo" className="max-h-16 mx-auto object-contain mb-2" />
                )}
                {billSettings.companyName && (
                    <p className="font-bold text-lg">{billSettings.companyName}</p>
                )}
                <p className="font-bold text-base mt-2">Salary Slip</p>
              </div>
              <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-xs mb-4">
                <span className="font-semibold">Staff Name:</span><span>{staff.name}</span>
                <span className="font-semibold">Pay Period:</span><span>{payPeriod}</span>
                <span className="font-semibold">Date:</span><span>{new Date().toLocaleDateString()}</span>
              </div>
              <table className="w-full text-xs">
                <thead>
                   <tr className="border-t-2 border-b-2 border-black">
                    <th className="text-left py-1">Description</th>
                    <th className="text-right py-1">Amount (Rs.)</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-dashed border-black">
                    <td className="py-1">Base Salary</td>
                    <td className="text-right py-1">{staff.monthlySalary.toFixed(2)}</td>
                  </tr>
                  <tr className="border-b border-dashed border-black">
                    <td className="py-1">Advances / Deductions</td>
                    <td className="text-right py-1 text-red-600">-{advances.toFixed(2)}</td>
                  </tr>
                </tbody>
              </table>
              <div className="mt-2 flex justify-between items-center bg-slate-100 p-2 font-bold">
                 <span>Net Salary Paid</span>
                 <span>Rs.{salaryPaid.toFixed(2)}</span>
              </div>
              <p className="text-center text-[10px] text-slate-500 mt-4">This is a computer-generated salary slip.</p>
           </div>
        </div>
        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-900/50 border-t border-slate-200 dark:border-slate-700 flex justify-end space-x-2">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md hover:bg-slate-50 dark:hover:bg-slate-600 transition-colors">Done</button>
            <button type="button" onClick={handleSave} className="flex items-center space-x-2 px-3 py-2 text-sm text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md hover:bg-slate-50 dark:hover:bg-slate-600 transition-colors">
                <ArrowDownTrayIcon className="h-5 w-5" />
                <span>Save</span>
            </button>
            <button type="button" onClick={handlePrint} className="flex items-center space-x-2 px-3 py-2 text-sm text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
                 <PrintIcon className="h-5 w-5" />
                <span>Print</span>
            </button>
        </div>
      </div>
    </div>
  );
};

export default SalaryReceiptModal;