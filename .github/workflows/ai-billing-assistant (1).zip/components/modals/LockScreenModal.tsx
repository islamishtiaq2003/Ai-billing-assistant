import React, { useState, useEffect, useRef } from 'react';
import LockIcon from '../icons/LockIcon.tsx';

interface LockScreenModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUnlock: (code: string) => void;
  pageName: string | null;
  error: boolean;
}

const LockScreenModal: React.FC<LockScreenModalProps> = ({ isOpen, onClose, onUnlock, pageName, error }) => {
  const [code, setCode] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      if(error) {
        setCode('');
      }
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen, error]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (code) {
      onUnlock(code);
    }
  };

  const shakeClass = error ? 'animate-shake' : '';

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50" aria-modal="true" role="dialog">
      <div className={`bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-sm m-4 p-8 text-center ${shakeClass}`}>
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-primary-100 dark:bg-primary-900/50">
          <LockIcon className="h-6 w-6 text-primary-600 dark:text-primary-300" />
        </div>
        <h3 className="mt-4 text-xl font-semibold text-gray-900 dark:text-white">Authentication Required</h3>
        <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
          Please enter your security code to access the <span className="font-bold">{pageName}</span> page.
        </p>
        <form onSubmit={handleSubmit}>
          <input
            ref={inputRef}
            type="password"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className={`mt-6 block w-full px-3 py-2 text-center text-xl tracking-[0.5em] font-mono
              bg-gray-100 dark:bg-gray-700 border rounded-md shadow-sm
              focus:outline-none focus:ring-2
              transition-colors duration-200
              ${error ? 'border-red-500 focus:ring-red-500 focus:border-red-500' : 'border-gray-300 dark:border-gray-600 focus:ring-primary-500 focus:border-primary-500'}`
            }
          />
           {error && <p className="mt-2 text-xs text-red-500">Incorrect code. Please try again.</p>}
          <div className="mt-6 flex justify-center space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 text-sm font-medium text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50"
              disabled={!code}
            >
              Unlock
            </button>
          </div>
        </form>
      </div>
       <style>{`
          @keyframes shake {
            10%, 90% { transform: translate3d(-1px, 0, 0); }
            20%, 80% { transform: translate3d(2px, 0, 0); }
            30%, 50%, 70% { transform: translate3d(-4px, 0, 0); }
            40%, 60% { transform: translate3d(4px, 0, 0); }
          }
          .animate-shake {
            animation: shake 0.5s cubic-bezier(.36,.07,.19,.97) both;
          }
        `}</style>
    </div>
  );
};

export default LockScreenModal;