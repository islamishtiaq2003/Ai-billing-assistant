import React, { useState, useEffect } from 'react';
import ExclamationTriangleIcon from '../icons/ExclamationTriangleIcon.tsx';

interface ConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  requiresCode?: boolean;
  securityCode?: string;
  confirmButtonText?: string;
}

const ConfirmationModal: React.FC<ConfirmationModalProps> = ({ isOpen, onClose, onConfirm, title, message, requiresCode = false, securityCode = '0000', confirmButtonText = 'Confirm' }) => {
  const [code, setCode] = useState('');
  const [isCodeCorrect, setIsCodeCorrect] = useState(!requiresCode);

  useEffect(() => {
    if (isOpen) {
      setCode('');
      setIsCodeCorrect(!requiresCode);
    }
  }, [isOpen, requiresCode]);

  useEffect(() => {
    if (requiresCode) {
      setIsCodeCorrect(code === securityCode);
    }
  }, [code, requiresCode, securityCode]);

  const handleConfirm = () => {
    if (isCodeCorrect) {
      onConfirm();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50" aria-modal="true" role="dialog">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-sm m-4">
        <div className="p-6">
          <div className="flex items-start space-x-4">
            <div className="flex-shrink-0 h-12 w-12 flex items-center justify-center rounded-full bg-red-100 dark:bg-red-900/50">
              <ExclamationTriangleIcon className="h-6 w-6 text-red-600 dark:text-red-400" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-100" id="modal-title">
                {title}
              </h3>
              <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                {message}
              </p>
            </div>
          </div>
          {requiresCode && (
            <div className="mt-4">
              <label htmlFor="securityCode" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                Please enter the security code to confirm this action.
              </label>
              <input
                type="password"
                id="securityCode"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                autoFocus
              />
            </div>
          )}
        </div>
        <div className="px-6 py-4 bg-gray-50 dark:bg-gray-900/50 border-t border-gray-200 dark:border-gray-700 flex justify-end space-x-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleConfirm}
            disabled={!isCodeCorrect}
            className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md shadow-sm hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 disabled:bg-red-300 disabled:cursor-not-allowed"
          >
            {confirmButtonText}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationModal;