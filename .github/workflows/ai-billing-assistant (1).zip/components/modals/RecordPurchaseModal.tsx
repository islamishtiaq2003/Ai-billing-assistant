
import React, { useState, useMemo } from 'react';
import type { Vendor, Product, LineItem } from '../../types';
import XMarkIcon from '../icons/XMarkIcon';
import PlusIcon from '../icons/PlusIcon';
import ChevronDownIcon from '../icons/ChevronDownIcon';
import TrashIcon from '../icons/TrashIcon';

interface RecordPurchaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (items: LineItem[], total: number) => void;
  vendor: Vendor;
  products: Product[];
}

const RecordPurchaseModal: React.FC<RecordPurchaseModalProps> = ({ isOpen, onClose, onSave, vendor, products }) => {
  const [lineItems, setLineItems] = useState<LineItem[]>([]);

  // Add Item State
  const [selectedProductId, setSelectedProductId] = useState('');
  const [purchasePrice, setPurchasePrice] = useState(0);
  const [quantity, setQuantity] = useState(1);

  const total = useMemo(() => {
    return lineItems.reduce((sum, item) => sum + item.quantity * item.price, 0);
  }, [lineItems]);

  const resetForm = () => {
    setLineItems([]);
    setSelectedProductId('');
    setPurchasePrice(0);
    setQuantity(1);
  };
  
  const handleProductSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const id = e.target.value;
    setSelectedProductId(id);
    if (id) {
        const product = products.find(p => p.id === id);
        if (product) setPurchasePrice(product.purchasePrice);
    } else {
        setPurchasePrice(0);
    }
  };

  const handleAddItem = () => {
    const product = products.find(p => p.id === selectedProductId);
    if (!product) {
      alert('Please select a product.');
      return;
    }
    const newItem: LineItem = {
      id: product.id,
      name: product.name,
      price: purchasePrice,
      quantity: quantity,
    };
    setLineItems(prev => [...prev, newItem]);
    
    // Reset add item form
    setSelectedProductId('');
    setPurchasePrice(0);
    setQuantity(1);
  };

  const handleRemoveItem = (productId: string) => {
    setLineItems(prev => prev.filter(item => item.id !== productId));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (lineItems.length === 0) {
      alert('Please add at least one item to the bill.');
      return;
    }
    onSave(lineItems, total);
    resetForm();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 backdrop-blur-sm" aria-modal="true" role="dialog">
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-lg m-4">
        <form onSubmit={handleSubmit}>
          <div className="p-5 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center">
            <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">Record Purchase Bill</h3>
            <button type="button" onClick={onClose} className="p-1 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700">
              <XMarkIcon className="h-6 w-6" />
            </button>
          </div>
          <div className="p-6 max-h-[70vh] overflow-y-auto">
            <p className="text-sm text-slate-600 dark:text-slate-300">
              Recording a new purchase bill for <span className="font-semibold">{vendor.name}</span>.
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              This will update the vendor's balance and increase product stock quantities.
            </p>

            <div className="mt-4 border border-slate-200 dark:border-slate-700 rounded-lg p-4">
              <h4 className="font-semibold text-slate-800 dark:text-slate-100 mb-2">Add Items</h4>
              <div className="space-y-3">
                 <div>
                    <label htmlFor="product" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Product</label>
                    <div className="relative mt-1">
                        <select id="product" value={selectedProductId} onChange={handleProductSelect} className="block w-full appearance-none rounded-md border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 px-3 py-2 shadow-sm focus:border-primary-500 focus:outline-none focus:ring-primary-500 sm:text-sm">
                            <option value="">Select a product</option>
                            {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                        </select>
                        <ChevronDownIcon className="pointer-events-none absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
                    </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="purchasePrice" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Purchase Price</label>
                        <input type="number" id="purchasePrice" value={purchasePrice} onChange={e => setPurchasePrice(parseFloat(e.target.value) || 0)} className="mt-1 block w-full rounded-md border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 px-3 py-2 shadow-sm focus:border-primary-500 focus:outline-none focus:ring-primary-500 sm:text-sm"/>
                    </div>
                    <div>
                        <label htmlFor="quantity" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Quantity</label>
                        <input type="number" id="quantity" value={quantity} onChange={e => setQuantity(parseInt(e.target.value) || 1)} className="mt-1 block w-full rounded-md border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 px-3 py-2 shadow-sm focus:border-primary-500 focus:outline-none focus:ring-primary-500 sm:text-sm"/>
                    </div>
                </div>
                <button type="button" onClick={handleAddItem} className="w-full flex justify-center items-center space-x-2 px-4 py-2 text-sm text-primary-600 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/50 rounded-lg hover:bg-primary-100 dark:hover:bg-primary-900/80 focus:outline-none focus:ring-2 focus:ring-primary-500 transition-colors">
                    <PlusIcon className="h-5 w-5" />
                    <span>Add to Bill</span>
                </button>
              </div>
            </div>

            <div className="mt-4 border border-slate-200 dark:border-slate-700 rounded-lg p-4">
                <h4 className="font-semibold text-slate-800 dark:text-slate-100 mb-2">Bill Items</h4>
                 {lineItems.length === 0 ? (
                    <p className="text-center text-sm text-slate-400 py-4">No items added</p>
                 ) : (
                    <table className="w-full text-sm">
                        <thead>
                            <tr className="border-b border-slate-200 dark:border-slate-700">
                                <th className="text-left font-medium pb-1">Item</th>
                                <th className="text-center font-medium pb-1">Qty</th>
                                <th className="text-right font-medium pb-1">Price</th>
                                <th className="text-right font-medium pb-1">Total</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            {lineItems.map(item => (
                                <tr key={item.id}>
                                    <td className="py-1">{item.name}</td>
                                    <td className="text-center">{item.quantity}</td>
                                    <td className="text-right">{item.price.toFixed(2)}</td>
                                    <td className="text-right font-medium">{(item.quantity * item.price).toFixed(2)}</td>
                                    <td className="text-right">
                                        <button type="button" onClick={() => handleRemoveItem(item.id)} className="text-slate-400 hover:text-red-500 p-1"><TrashIcon className="h-4 w-4" /></button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                 )}
                 <div className="mt-4 pt-2 border-t border-slate-200 dark:border-slate-700 flex justify-end">
                    <div className="flex items-center space-x-4">
                        <span className="font-semibold text-slate-800 dark:text-slate-100">Total:</span>
                        <span className="font-bold text-xl text-slate-900 dark:text-slate-50">Rs.{total.toFixed(2)}</span>
                    </div>
                 </div>
            </div>

          </div>
          <div className="px-6 py-4 bg-slate-50 dark:bg-slate-900/50 border-t border-slate-200 dark:border-slate-700 flex justify-end space-x-2">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md hover:bg-slate-50 dark:hover:bg-slate-600 transition-colors">Cancel</button>
            <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">Record Purchase Bill</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default RecordPurchaseModal;