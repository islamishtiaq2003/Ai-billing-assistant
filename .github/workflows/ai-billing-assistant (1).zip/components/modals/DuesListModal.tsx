

import React from 'react';
import XMarkIcon from '../icons/XMarkIcon.tsx';
import CurrencyRupeeIcon from '../icons/CurrencyRupeeIcon.tsx';

interface DuesListModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  data: { name: string; balance: number }[];
}

const DuesListModal: React.FC<DuesListModalProps> = ({ isOpen, onClose, title, data }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 backdrop-blur-sm" onClick={onClose} aria-modal="true" role="dialog">
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-lg m-4 flex flex-col max-h-[80vh]" onClick={e => e.stopPropagation()}>
        <div className="p-5 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center flex-shrink-0">
          <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">{title}</h3>
          <button type="button" onClick={onClose} className="p-1 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700">
            <XMarkIcon className="h-6 w-6" />
          </button>
        </div>
        <div className="p-6 overflow-y-auto">
          {data.length > 0 ? (
            <table className="min-w-full text-sm">
              <thead className="sticky top-0 bg-slate-50 dark:bg-slate-700/50">
                <tr>
                  <th className="w-12 text-center font-medium p-2 text-slate-500 dark:text-slate-400">Rank</th>
                  <th className="text-left font-medium p-2 text-slate-500 dark:text-slate-400">Name</th>
                  <th className="text-right font-medium p-2 text-slate-500 dark:text-slate-400">Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                {data.map((item, index) => (
                  <tr key={item.name + index}>
                    <td className="p-2 text-center text-slate-500 dark:text-slate-400">{index + 1}</td>
                    <td className="p-2 font-medium text-slate-800 dark:text-slate-100">{item.name}</td>
                    <td className="p-2 text-right font-semibold text-slate-700 dark:text-slate-200">Rs.{item.balance.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="text-center py-10 text-slate-500 dark:text-slate-400">
              <CurrencyRupeeIcon className="mx-auto h-12 w-12 text-slate-400" />
              <p className="mt-2">No dues to display.</p>
            </div>
          )}
        </div>
        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-900/50 border-t border-slate-200 dark:border-slate-700 flex justify-end flex-shrink-0">
          <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md hover:bg-slate-50 dark:hover:bg-slate-600 transition-colors">Close</button>
        </div>
      </div>
    </div>
  );
};

export default DuesListModal;