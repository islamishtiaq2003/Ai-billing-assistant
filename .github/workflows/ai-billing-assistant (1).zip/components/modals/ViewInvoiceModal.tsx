import React, { useMemo } from 'react';
import type { Invoice, BillSettings } from '../../types.ts';
import html2canvas from 'html2canvas';
import XMarkIcon from '../icons/XMarkIcon.tsx';
import ArrowDownTrayIcon from '../icons/ArrowDownTrayIcon.tsx';
import PrintIcon from '../icons/PrintIcon.tsx';
import CubeIcon from '../icons/CubeIcon.tsx';

interface ViewInvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: Invoice;
  billSettings: BillSettings;
}

const InvoicePreviewContent: React.FC<{ invoice: Invoice, billSettings: BillSettings }> = ({ invoice, billSettings }) => {
    
    const formattedDate = new Date(invoice.invoiceDate).toLocaleDateString('en-US', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    });

    const isSmallFormat = invoice.type === 'Retail' || invoice.type === 'Return / Credit';
    const widthInPx = isSmallFormat ? 300 : billSettings.width * 100;
    
    const transactionTotal = useMemo(() => {
        const itemsTotal = invoice.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
        const transactionValue = itemsTotal + (invoice.claimCharges || 0) - (invoice.billDiscount || 0);
        return transactionValue;
    }, [invoice]);
    
    return (
       <div
            className="bg-white text-black font-sans p-4 shadow-lg rounded-lg text-[10px]"
            style={{ width: `${widthInPx}px`, border: '1px solid #333' }}
        >
            {/* Header */}
            <div className="flex justify-between items-start pb-2">
                <div>
                    <p className="font-bold text-lg">{billSettings.companyName || 'Your Company Name'}</p>
                     {billSettings.companyLogo ? (
                         <img src={billSettings.companyLogo} alt="Company Logo" className="h-10 w-10 object-contain rounded-md bg-gray-100 mt-1 p-1" />
                    ) : (
                        <div className="bg-black text-white p-2 rounded-md mt-1 inline-block">
                           <CubeIcon className="w-6 h-6" />
                        </div>
                    )}
                </div>
                <div className="text-right">
                    <h2 className="font-bold text-lg tracking-wide">INVOICE</h2>
                    <p className="font-mono mt-1">#{invoice.invoiceNumber}</p>
                    <p className="mt-1">Date: {formattedDate}</p>
                </div>
            </div>

            <div className="text-left text-xs pb-2">
                <p><span className="font-bold">To:</span> {invoice.customerName || 'Walking Customer'}</p>
            </div>

            <div className="border-b border-black w-full my-2"></div>

            {/* Item Headers */}
            <div className="flex justify-between font-bold py-1 text-xs">
                <span className="w-[25%] text-left">Total</span>
                <span className="w-[20%] text-left">Price</span>
                <span className="w-[15%] text-center">Qty</span>
                <span className="w-[40%] text-right">Item</span>
            </div>
            
            <div className="border-b border-black w-full"></div>


            <div className="min-h-[100px] py-2 text-xs">
                {invoice.items.length === 0 ? (
                    <p className="text-gray-500 text-center py-10">No items added yet</p>
                ) : (
                    <div className="space-y-1">
                        {invoice.items.map((item, index) => (
                             <div key={`${item.id}-${index}`} className="flex justify-between items-start">
                                <span className="w-[25%] text-left">{(item.quantity * item.price).toFixed(2)}</span>
                                <span className="w-[20%] text-left">{item.price.toFixed(2)}</span>
                                <span className="w-[15%] text-center">{item.quantity}</span>
                                <span className="w-[40%] text-right break-words">{item.name}</span>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* Footer */}
            <div className="mt-auto pt-2">
                 <div className="border-t-2 border-black my-2"></div>

                {(invoice.type === 'Wholesale' || invoice.type === 'Return / Credit') ? (
                    <>
                        <div className="flex justify-between items-center text-xs mb-1">
                            <span className="font-semibold">{invoice.type === 'Return / Credit' ? 'Return Total' : 'Total'}</span>
                            <span className="font-semibold">Rs.{transactionTotal.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between items-center text-xs mb-1">
                            <span className="font-semibold">Old Balance</span>
                            <span className="font-semibold">Rs.{(invoice.oldBalance || 0).toFixed(2)}</span>
                        </div>
                    </>
                ) : (
                    <>
                        {invoice.billDiscount && invoice.billDiscount > 0 && (
                            <div className="flex justify-between items-center text-xs mb-1">
                                <span className="font-semibold">Discount</span>
                                <span className="font-semibold">- Rs.{invoice.billDiscount.toFixed(2)}</span>
                            </div>
                        )}
                        
                        {invoice.claimCharges && invoice.claimCharges > 0 && (
                            <div className="flex justify-between items-center text-xs mb-1">
                                <span className="font-semibold">Claim Charges</span>
                                <span className="font-semibold">+ Rs.{invoice.claimCharges.toFixed(2)}</span>
                            </div>
                        )}
                    </>
                )}

                 <div className="flex justify-start items-end mt-1">
                    <div>
                        <p className="text-xs">Grand Total</p>
                        <p className="font-bold text-xl">Rs.{invoice.grandTotal.toFixed(2)}</p>
                    </div>
                </div>
            </div>
            {billSettings.notes && billSettings.notes.trim() !== '' && (
                <div className="mt-2 pt-2 border-t border-dashed border-black">
                    <p className="text-center text-[9px] italic whitespace-pre-wrap">{billSettings.notes}</p>
                </div>
            )}
        </div>
    );
};


const ViewInvoiceModal: React.FC<ViewInvoiceModalProps> = ({ isOpen, onClose, invoice, billSettings }) => {
    const previewRef = React.useRef<HTMLDivElement>(null);

    const getPrintableContent = () => {
        return previewRef.current?.innerHTML || '';
    };

    const handleSave = () => {
        const nodeToRender = previewRef.current?.querySelector('div[class*="font-sans"]');
        if (nodeToRender) {
             html2canvas(nodeToRender as HTMLElement, { 
                backgroundColor: '#ffffff',
                scale: 3
            }).then(canvas => {
                const link = document.createElement('a');
                link.download = `Invoice_${invoice.invoiceNumber}.png`;
                link.href = canvas.toDataURL('image/png');
                link.click();
            });
        }
    };

    const handlePrint = () => {
        const content = getPrintableContent();
        if (!content) return;
        
        const isSmallFormat = invoice.type === 'Retail' || invoice.type === 'Return / Credit';
        const width = isSmallFormat ? '3in' : `${billSettings.width}in`;

        const iframe = document.createElement('iframe');
        iframe.style.position = 'absolute';
        iframe.style.width = '0';
        iframe.style.height = '0';
        iframe.style.border = '0';
        document.body.appendChild(iframe);

        const doc = iframe.contentWindow?.document;
        if (doc) {
            doc.open();
            doc.write('<html><head><title>Invoice</title>');
            doc.write(`<style>
                @page { size: auto; margin: 0mm; }
                body { margin: 0; font-family: sans-serif; }
                .invoice-container { width: ${width}; margin: 0; padding: 0; color: black; }
                h3, span, p, div, h2, table, th, td { color: black !important; }
                .bg-black { background-color: #000 !important; -webkit-print-color-adjust: exact; color-adjust: exact; }
                .text-white { color: #ffffff !important; }
                .text-gray-500 { color: #6B7280 !important; }
            </style>`);
            doc.write('</head><body><div class="invoice-container">');
            doc.write(content);
            doc.write('</div></body></html>');
            doc.close();
            
            iframe.contentWindow?.focus();
            iframe.contentWindow?.print();
        }

        setTimeout(() => {
            document.body.removeChild(iframe);
        }, 1000);
    };


  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-start z-50 backdrop-blur-sm p-4 overflow-y-auto" onClick={onClose}>
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-3xl m-4" onClick={e => e.stopPropagation()}>
        <div className="p-5 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center">
          <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">Invoice Details</h3>
          <button type="button" onClick={onClose} className="p-1 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700">
            <XMarkIcon className="h-6 w-6" />
          </button>
        </div>
        <div className="p-6 max-h-[70vh] overflow-y-auto bg-slate-100 dark:bg-slate-900/50 flex justify-center">
           <div ref={previewRef}>
                <InvoicePreviewContent invoice={invoice} billSettings={billSettings} />
           </div>
        </div>
        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-900/50 border-t border-slate-200 dark:border-slate-700 flex justify-end space-x-2">
          <button type="button" onClick={handleSave} className="flex items-center space-x-2 px-3 py-2 text-sm text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md hover:bg-slate-50 dark:hover:bg-slate-600 transition-colors">
              <ArrowDownTrayIcon className="h-5 w-5" />
              <span>Save</span>
          </button>
          <button type="button" onClick={handlePrint} className="flex items-center space-x-2 px-3 py-2 text-sm text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
               <PrintIcon className="h-5 w-5" />
              <span>Print</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ViewInvoiceModal;