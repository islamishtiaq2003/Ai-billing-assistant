
import React, { useState } from 'react';
import XMarkIcon from '../icons/XMarkIcon.tsx';
import ChartBarIcon from '../icons/ChartBarIcon.tsx';

interface TopProductsModalProps {
  isOpen: boolean;
  onClose: () => void;
  productsData: { name: string; quantity: number }[];
}

const TopProductsModal: React.FC<TopProductsModalProps> = ({ isOpen, onClose, productsData }) => {
  const [limit, setLimit] = useState<50 | 100>(50);
  
  if (!isOpen) return null;

  const displayedProducts = productsData.slice(0, limit);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 backdrop-blur-sm" onClick={onClose} aria-modal="true" role="dialog">
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-2xl m-4 flex flex-col max-h-[80vh]" onClick={e => e.stopPropagation()}>
        <div className="p-5 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center flex-shrink-0">
          <div>
            <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">Top Selling Products</h3>
            <div className="mt-2 flex space-x-1 bg-slate-100 dark:bg-slate-700 p-1 rounded-md text-sm">
                {( [50, 100] as const ).map(num => (
                    <button key={num} onClick={() => setLimit(num)} className={`px-3 py-1 rounded ${limit === num ? 'bg-white dark:bg-slate-600 shadow-sm text-slate-800 dark:text-slate-100 font-semibold' : 'text-slate-500 dark:text-slate-400'}`}>
                        Top {num}
                    </button>
                ))}
            </div>
          </div>
          <button type="button" onClick={onClose} className="p-1 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700">
            <XMarkIcon className="h-6 w-6" />
          </button>
        </div>
        <div className="p-6 overflow-y-auto">
          {displayedProducts.length > 0 ? (
            <table className="min-w-full text-sm">
              <thead className="sticky top-0 bg-slate-50 dark:bg-slate-700/50">
                <tr>
                  <th className="w-12 text-center font-medium p-2 text-slate-500 dark:text-slate-400">Rank</th>
                  <th className="text-left font-medium p-2 text-slate-500 dark:text-slate-400">Product Name</th>
                  <th className="text-right font-medium p-2 text-slate-500 dark:text-slate-400">Quantity Sold</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                {displayedProducts.map((item, index) => (
                  <tr key={item.name + index}>
                    <td className="p-2 text-center text-slate-500 dark:text-slate-400">{index + 1}</td>
                    <td className="p-2 font-medium text-slate-800 dark:text-slate-100">{item.name}</td>
                    <td className="p-2 text-right font-semibold text-slate-700 dark:text-slate-200">{item.quantity}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
             <div className="text-center py-10 text-slate-500 dark:text-slate-400">
              <ChartBarIcon className="mx-auto h-12 w-12 text-slate-400" />
              <p className="mt-2">No product sales data to display.</p>
            </div>
          )}
        </div>
        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-900/50 border-t border-slate-200 dark:border-slate-700 flex justify-end flex-shrink-0">
          <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md hover:bg-slate-50 dark:hover:bg-slate-600 transition-colors">Close</button>
        </div>
      </div>
    </div>
  );
};

export default TopProductsModal;