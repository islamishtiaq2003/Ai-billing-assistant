
import React, { useState, useEffect } from 'react';
import type { StaffMember } from '../../types.ts';
import XMarkIcon from '../icons/XMarkIcon.tsx';
import PlusCircleIcon from '../icons/PlusCircleIcon.tsx';

interface AddStaffModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (staff: StaffMember) => void;
  staffToEdit: StaffMember | null;
}

const AddStaffModal: React.FC<AddStaffModalProps> = ({ isOpen, onClose, onSave, staffToEdit }) => {
  const [name, setName] = useState('');
  const [contactNumbers, setContactNumbers] = useState(['']);
  const [monthlySalary, setMonthlySalary] = useState('');

  useEffect(() => {
    if (isOpen) {
      if (staffToEdit) {
        setName(staffToEdit.name);
        setContactNumbers(staffToEdit.contactNumbers.length > 0 ? staffToEdit.contactNumbers : ['']);
        setMonthlySalary(staffToEdit.monthlySalary.toString());
      } else {
        setName('');
        setContactNumbers(['']);
        setMonthlySalary('');
      }
    }
  }, [isOpen, staffToEdit]);

  const handleContactChange = (index: number, value: string) => {
    const newContacts = [...contactNumbers];
    newContacts[index] = value;
    setContactNumbers(newContacts);
  };

  const addContactField = () => {
    setContactNumbers([...contactNumbers, '']);
  };

  const removeContactField = (index: number) => {
    if (contactNumbers.length > 1) {
      setContactNumbers(contactNumbers.filter((_, i) => i !== index));
    } else {
      setContactNumbers(['']);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !monthlySalary) {
        alert('Staff name and monthly salary are required.');
        return;
    }
    
    const newStaffMember: StaffMember = {
      id: staffToEdit?.id || crypto.randomUUID(),
      name: name.trim(),
      contactNumbers: contactNumbers.filter(n => n.trim() !== ''),
      monthlySalary: parseFloat(monthlySalary) || 0,
      payments: staffToEdit?.payments || [],
    };
    onSave(newStaffMember);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 backdrop-blur-sm" aria-modal="true" role="dialog">
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-md m-4">
        <form onSubmit={handleSubmit}>
          <div className="p-5 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center">
            <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">{staffToEdit ? 'Edit' : 'Add New'} Staff Member</h3>
            <button type="button" onClick={onClose} className="p-1 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700">
              <XMarkIcon className="h-6 w-6" />
            </button>
          </div>
          <div className="p-6 space-y-4">
            <div>
              <label htmlFor="staffName" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Staff Name</label>
              <input
                type="text"
                id="staffName"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="block w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Contact Numbers</label>
              <div className="space-y-2">
                {contactNumbers.map((number, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <input
                      type="text"
                      placeholder="e.g. 0300-1234567"
                      value={number}
                      onChange={(e) => handleContactChange(index, e.target.value)}
                      className="block w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    />
                    {index > 0 && (
                      <button type="button" onClick={() => removeContactField(index)} className="text-slate-400 hover:text-red-500">
                        <XMarkIcon className="h-5 w-5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
              <button
                type="button"
                onClick={addContactField}
                className="mt-2 flex items-center text-sm font-medium text-primary-600 hover:text-primary-800 dark:text-primary-400 dark:hover:text-primary-200"
              >
                <PlusCircleIcon className="h-5 w-5 mr-1" /> Add Another Number
              </button>
            </div>
            <div>
              <label htmlFor="monthlySalary" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Monthly Salary (Rs.)</label>
              <input
                type="number"
                id="monthlySalary"
                placeholder="e.g. 25000"
                value={monthlySalary}
                onChange={(e) => setMonthlySalary(e.target.value)}
                required
                className="block w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              />
            </div>
          </div>
          <div className="px-6 py-4 bg-slate-50 dark:bg-slate-900/50 border-t border-slate-200 dark:border-slate-700 flex justify-end space-x-2">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md hover:bg-slate-50 dark:hover:bg-slate-600 transition-colors">Cancel</button>
            <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">{staffToEdit ? 'Update Staff' : 'Save Staff'}</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddStaffModal;
