
import React, { useState, useEffect } from 'react';
import type { Customer } from '../../types.ts';
import XMarkIcon from '../icons/XMarkIcon.tsx';
import PlusCircleIcon from '../icons/PlusCircleIcon.tsx';

interface AddCustomerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (customer: Customer) => void;
  customerToEdit?: Customer | null;
}

const AddCustomerModal: React.FC<AddCustomerModalProps> = ({ isOpen, onClose, onSave, customerToEdit }) => {
  const [name, setName] = useState('');
  const [contactNumbers, setContactNumbers] = useState(['']);
  const [balance, setBalance] = useState('');

  const isEditing = !!customerToEdit;

  useEffect(() => {
    if (isOpen) {
      if (isEditing && customerToEdit) {
        setName(customerToEdit.name);
        setContactNumbers(customerToEdit.contactNumbers.length > 0 ? customerToEdit.contactNumbers : ['']);
        setBalance(customerToEdit.balance.toString());
      } else {
        setName('');
        setContactNumbers(['']);
        setBalance('');
      }
    }
  }, [isOpen, customerToEdit, isEditing]);

  const handleContactChange = (index: number, value: string) => {
    const newContacts = [...contactNumbers];
    newContacts[index] = value;
    setContactNumbers(newContacts);
  };

  const addContactField = () => {
    setContactNumbers([...contactNumbers, '']);
  };

  const removeContactField = (index: number) => {
    if (contactNumbers.length > 1) {
      setContactNumbers(contactNumbers.filter((_, i) => i !== index));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
        alert('Customer name is required.');
        return;
    }
    const newBalance = parseFloat(balance) || 0;
    
    const customerData: Customer = {
      id: customerToEdit?.id || crypto.randomUUID(),
      name: name.trim(),
      contactNumbers: contactNumbers.filter(n => n.trim() !== ''),
      balance: newBalance,
      transactions: customerToEdit?.transactions || (newBalance > 0 ? [{
        id: crypto.randomUUID(),
        date: new Date().toISOString().split('T')[0],
        description: 'Opening Balance',
        amount: newBalance,
        balanceAfter: newBalance,
        type: 'opening_balance',
      }] : []),
      claims: customerToEdit?.claims || [],
    };
    onSave(customerData);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 backdrop-blur-sm" aria-modal="true" role="dialog">
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-md m-4">
        <form onSubmit={handleSubmit}>
          <div className="p-5 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center">
            <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">{isEditing ? 'Edit Customer' : 'Add New Customer'}</h3>
            <button type="button" onClick={onClose} className="p-1 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700">
              <XMarkIcon className="h-6 w-6" />
            </button>
          </div>
          <div className="p-6 space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Customer Name</label>
              <input type="text" name="name" id="name" value={name} onChange={e => setName(e.target.value)} required className="block w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Contact Numbers</label>
              <div className="space-y-2">
                {contactNumbers.map((number, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <input type="text" placeholder="e.g. 0300-1234567" value={number} onChange={e => handleContactChange(index, e.target.value)} className="block w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm" />
                    {index > 0 && (
                      <button type="button" onClick={() => removeContactField(index)} className="text-slate-400 hover:text-red-500">
                        <XMarkIcon className="h-5 w-5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
              <button type="button" onClick={addContactField} className="mt-2 flex items-center text-sm font-medium text-primary-600 hover:text-primary-800 dark:text-primary-400 dark:hover:text-primary-200">
                 <PlusCircleIcon className="h-5 w-5 mr-1" /> Add Another Number
              </button>
            </div>
             <div>
              <label htmlFor="balance" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{isEditing ? 'Current Balance' : 'Opening Balance (Optional)'}</label>
              <input 
                type="number" 
                name="balance" 
                id="balance" 
                placeholder={isEditing ? 'Manual balance adjustment' : "Enter if customer has a balance"} 
                value={balance} 
                onChange={e => setBalance(e.target.value)} 
                className="block w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm" 
              />
              {isEditing && (
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  Changing this value will require security code confirmation and create a "Manual Balance Adjustment" transaction.
                </p>
              )}
            </div>
          </div>
          <div className="px-6 py-4 bg-slate-50 dark:bg-slate-900/50 border-t border-slate-200 dark:border-slate-700 flex justify-end space-x-2">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md hover:bg-slate-50 dark:hover:bg-slate-600 transition-colors">Cancel</button>
            <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">{isEditing ? 'Update Customer' : 'Save Customer'}</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddCustomerModal;