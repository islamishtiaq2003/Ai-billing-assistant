

import React from 'react';
import type { PurchaseBill, Vendor } from '../../types';
import XMarkIcon from '../icons/XMarkIcon';

interface ViewPurchaseBillModalProps {
  isOpen: boolean;
  onClose: () => void;
  purchaseBill: PurchaseBill;
  vendor: Vendor | null;
}

const ViewPurchaseBillModal: React.FC<ViewPurchaseBillModalProps> = ({ isOpen, onClose, purchaseBill, vendor }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-2xl m-4 max-h-[90vh] flex flex-col" onClick={e => e.stopPropagation()}>
        <div className="p-5 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center flex-shrink-0">
          <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">Purchase Bill Details</h3>
          <button type="button" onClick={onClose} className="p-1 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700">
            <XMarkIcon className="h-6 w-6" />
          </button>
        </div>
        <div className="p-6 overflow-y-auto">
          <div className="grid grid-cols-3 gap-4 text-sm mb-4">
            <div>
              <p className="text-slate-500 dark:text-slate-400">Vendor</p>
              <p className="font-semibold text-slate-800 dark:text-slate-100">{vendor?.name || 'N/A'}</p>
            </div>
            <div>
              <p className="text-slate-500 dark:text-slate-400">Bill ID</p>
              <p className="font-semibold font-mono text-slate-800 dark:text-slate-100">#{purchaseBill.id.slice(-6)}</p>
            </div>
            <div>
              <p className="text-slate-500 dark:text-slate-400">Date</p>
              <p className="font-semibold text-slate-800 dark:text-slate-100">{new Date(purchaseBill.date).toLocaleDateString()}</p>
            </div>
          </div>
          <div className="border rounded-lg overflow-hidden border-slate-200 dark:border-slate-700">
            <table className="min-w-full text-sm">
              <thead className="bg-slate-50 dark:bg-slate-700/50">
                <tr>
                  <th className="p-2 text-left font-semibold text-slate-600 dark:text-slate-300">Item</th>
                  <th className="p-2 text-center font-semibold text-slate-600 dark:text-slate-300">Qty</th>
                  <th className="p-2 text-right font-semibold text-slate-600 dark:text-slate-300">Price</th>
                  <th className="p-2 text-right font-semibold text-slate-600 dark:text-slate-300">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                {purchaseBill.items.map((item) => (
                  <tr key={item.id}>
                    <td className="p-2 font-medium">{item.name}</td>
                    <td className="p-2 text-center">{item.quantity}</td>
                    <td className="p-2 text-right font-mono">Rs.{item.price.toFixed(2)}</td>
                    <td className="p-2 text-right font-semibold font-mono">Rs.{(item.quantity * item.price).toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-slate-50 dark:bg-slate-700/50">
                <tr>
                  <td colSpan={3} className="p-2 text-right font-bold text-slate-800 dark:text-slate-100">Grand Total</td>
                  <td className="p-2 text-right font-bold text-slate-800 dark:text-slate-100 font-mono">Rs.{purchaseBill.total.toFixed(2)}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-900/50 border-t border-slate-200 dark:border-slate-700 flex justify-end flex-shrink-0">
          <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md hover:bg-slate-50 dark:hover:bg-slate-600 transition-colors">Close</button>
        </div>
      </div>
    </div>
  );
};

export default ViewPurchaseBillModal;
