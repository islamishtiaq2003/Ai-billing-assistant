
import React, { useState, useEffect } from 'react';
import type { StaffMember, StaffPaymentType } from '../../types';
import XMarkIcon from '../icons/XMarkIcon';

interface RecordStaffPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (payment: { type: StaffPaymentType, amount: number, notes: string }) => void;
  staff: StaffMember;
}

const RecordStaffPaymentModal: React.FC<RecordStaffPaymentModalProps> = ({ isOpen, onClose, onSave, staff }) => {
  const [paymentType, setPaymentType] = useState<StaffPaymentType>('Advance');
  const [amount, setAmount] = useState('');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (isOpen) {
        setPaymentType('Advance');
        setAmount('');
        setNotes('');
    }
  }, [isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const paymentAmount = parseFloat(amount);
    if (isNaN(paymentAmount) || paymentAmount <= 0) {
        alert('Please enter a valid payment amount.');
        return;
    }
    onSave({ type: paymentType, amount: paymentAmount, notes: notes.trim() });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 backdrop-blur-sm" aria-modal="true" role="dialog">
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-md m-4">
        <form onSubmit={handleSubmit}>
          <div className="p-5 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center">
            <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">Record Payment</h3>
            <button type="button" onClick={onClose} className="p-1 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700">
              <XMarkIcon className="h-6 w-6" />
            </button>
          </div>
          <div className="p-6 space-y-4">
            <p className="text-sm text-slate-600 dark:text-slate-300">
              Recording payment for <span className="font-semibold">{staff.name}</span>.
            </p>
            
            <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Payment Type</label>
                <div className="flex space-x-2 rounded-md bg-slate-100 dark:bg-slate-700 p-1">
                    {(['Advance', 'Salary Payment'] as const).map(type => (
                        <button
                            key={type}
                            type="button"
                            onClick={() => setPaymentType(type === 'Salary Payment' ? 'Salary' : 'Advance')}
                            className={`w-full px-3 py-1.5 text-sm font-semibold rounded-md transition-colors ${paymentType === (type === 'Salary Payment' ? 'Salary' : 'Advance') ? 'bg-white dark:bg-slate-600 shadow text-slate-800 dark:text-slate-50' : 'text-slate-600 dark:text-slate-300 hover:bg-white/50 dark:hover:bg-slate-600/50'}`}
                        >
                            {type}
                        </button>
                    ))}
                </div>
            </div>

            <div>
              <label htmlFor="amount" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Amount</label>
              <input
                type="number"
                id="amount"
                placeholder="Enter payment amount"
                value={amount}
                onChange={e => setAmount(e.target.value)}
                required
                className="block w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              />
            </div>
            <div>
              <label htmlFor="notes" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Notes (Optional)</label>
              <textarea
                id="notes"
                rows={3}
                placeholder="e.g., Eid bonus, medical emergency"
                value={notes}
                onChange={e => setNotes(e.target.value)}
                className="block w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              />
            </div>
          </div>
          <div className="px-6 py-4 bg-slate-50 dark:bg-slate-900/50 border-t border-slate-200 dark:border-slate-700 flex justify-end space-x-2">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md hover:bg-slate-50 dark:hover:bg-slate-600 transition-colors">Cancel</button>
            <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">Record Payment</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default RecordStaffPaymentModal;