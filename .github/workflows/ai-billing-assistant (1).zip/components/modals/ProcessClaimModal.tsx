import React, { useState, useEffect } from 'react';
import type { Claim, Product } from '../../types.ts';
import XMarkIcon from '../icons/XMarkIcon.tsx';
import ChevronDownIcon from '../icons/ChevronDownIcon.tsx';
import WrenchIcon from '../icons/WrenchIcon.tsx';

interface ProcessClaimModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (data: { replacementProductId?: string; claimCharges: number; }) => void;
  claim: Claim;
  products: Product[];
}

const ProcessClaimModal: React.FC<ProcessClaimModalProps> = ({ isOpen, onClose, onConfirm, claim, products }) => {
    const [replacementProductId, setReplacementProductId] = useState('');
    const [claimCharges, setClaimCharges] = useState('');

    useEffect(() => {
        if (isOpen) {
            setReplacementProductId('');
            setClaimCharges('');
        }
    }, [isOpen]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onConfirm({
            replacementProductId: replacementProductId || undefined,
            claimCharges: parseFloat(claimCharges) || 0
        });
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 backdrop-blur-sm" aria-modal="true" role="dialog">
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-md m-4">
                <form onSubmit={handleSubmit}>
                    <div className="p-5 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center">
                        <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">Process Warranty Claim</h3>
                        <button type="button" onClick={onClose} className="p-1 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700">
                        <XMarkIcon className="h-6 w-6" />
                        </button>
                    </div>

                    <div className="p-6 space-y-4">
                        <div>
                            <p className="text-sm font-medium text-slate-500 dark:text-slate-400">Claim Request:</p>
                            <p className="text-slate-800 dark:text-slate-100 font-semibold">{claim.description}</p>
                        </div>
                        
                        <div className="border-t border-slate-200 dark:border-slate-700 pt-4">
                            <label htmlFor="replacementProduct" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Replacement Product</label>
                            <div className="relative mt-1">
                                <select 
                                    id="replacementProduct" 
                                    value={replacementProductId} 
                                    onChange={e => setReplacementProductId(e.target.value)} 
                                    className="block w-full appearance-none rounded-md border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 px-3 py-2 shadow-sm focus:border-primary-500 focus:outline-none focus:ring-primary-500 sm:text-sm"
                                >
                                    <option value="">Select a product to give as replacement</option>
                                    {products.map(p => <option key={p.id} value={p.id}>{p.name} (In Stock: {p.quantity})</option>)}
                                </select>
                                <ChevronDownIcon className="pointer-events-none absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
                            </div>
                            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">The selected product will be deducted from inventory.</p>
                        </div>

                        <div className="p-4 rounded-lg bg-yellow-50 dark:bg-yellow-900/50">
                             <label htmlFor="claimCharges" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Amount Adjustment (Optional)</label>
                             <input 
                                type="number" 
                                id="claimCharges"
                                value={claimCharges}
                                onChange={e => setClaimCharges(e.target.value)}
                                placeholder="e.g. 150 for fee, -500 for credit"
                                className="mt-1 block w-full rounded-md border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 px-3 py-2 shadow-sm focus:border-primary-500 focus:outline-none focus:ring-primary-500 sm:text-sm"
                            />
                            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">This amount will be added to (or subtracted from) the bill total.</p>
                        </div>

                    </div>

                    <div className="px-6 py-4 bg-slate-50 dark:bg-slate-900/50 border-t border-slate-200 dark:border-slate-700 flex justify-end space-x-2">
                        <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md hover:bg-slate-50 dark:hover:bg-slate-600 transition-colors">Cancel</button>
                        <button type="submit" className="flex items-center space-x-2 px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
                           <WrenchIcon className="h-5 w-5" />
                           <span>Confirm and Add to Bill</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default ProcessClaimModal;