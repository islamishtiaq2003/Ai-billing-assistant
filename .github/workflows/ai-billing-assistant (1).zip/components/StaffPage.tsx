import React, { useState, useMemo } from 'react';
import type { StaffMember, StaffPayment, StaffPaymentType, BillSettings } from '../types.ts';
import SearchIcon from './icons/SearchIcon.tsx';
import UserPlusIcon from './icons/UserPlusIcon.tsx';
import StaffIcon from './icons/StaffIcon.tsx';
import AddStaffModal from './modals/AddStaffModal.tsx';
import RecordStaffPaymentModal from './modals/RecordStaffPaymentModal.tsx';
import SalaryReceiptModal from './modals/SalaryReceiptModal.tsx';
import PencilIcon from './icons/PencilIcon.tsx';
import TrashIcon from './icons/TrashIcon.tsx';
import ConfirmationModal from './modals/ConfirmationModal.tsx';

interface StaffPageProps {
  staff: StaffMember[];
  setStaff: React.Dispatch<React.SetStateAction<StaffMember[]>>;
  billSettings: BillSettings;
  securityCode: string;
}

const StaffPage: React.FC<StaffPageProps> = ({ staff, setStaff, billSettings, securityCode }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStaffId, setSelectedStaffId] = useState<string | null>(null);

  const [modal, setModal] = useState<'add' | 'payment' | 'receipt' | null>(null);
  const [staffToEdit, setStaffToEdit] = useState<StaffMember | null>(null);
  const [itemToDelete, setItemToDelete] = useState<string | null>(null);

  const filteredStaff = useMemo(() => {
    return staff.filter(member =>
      member.name.toLowerCase().includes(searchTerm.toLowerCase())
    ).sort((a, b) => a.name.localeCompare(b.name));
  }, [staff, searchTerm]);

  const selectedStaff = useMemo(() => {
    return staff.find(s => s.id === selectedStaffId) || null;
  }, [staff, selectedStaffId]);

  const monthlySummary = useMemo(() => {
    if (!selectedStaff) return { advances: 0, salaryPaid: 0, netPayable: 0, payPeriod: '' };
    
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    const payPeriod = now.toLocaleString('default', { month: 'long', year: 'numeric' });

    const paymentsThisMonth = selectedStaff.payments.filter(p => {
        const paymentDate = new Date(p.date);
        return paymentDate.getMonth() === currentMonth && paymentDate.getFullYear() === currentYear;
    });

    const advances = paymentsThisMonth
        .filter(p => p.type === 'Advance')
        .reduce((sum, p) => sum + p.amount, 0);

    const salaryPaid = paymentsThisMonth
        .filter(p => p.type === 'Salary')
        .reduce((sum, p) => sum + p.amount, 0);
        
    const netPayable = selectedStaff.monthlySalary - advances - salaryPaid;

    return { advances, salaryPaid, netPayable, payPeriod };
  }, [selectedStaff]);

  const handleOpenAddModal = (staffMember: StaffMember | null = null) => {
    setStaffToEdit(staffMember);
    setModal('add');
  };
  
  const handleSaveStaff = (staffMember: StaffMember) => {
    setStaff(prev => {
        const exists = prev.some(s => s.id === staffMember.id);
        if (exists) {
            return prev.map(s => s.id === staffMember.id ? staffMember : s);
        }
        return [...prev, staffMember];
    });
    setModal(null);
  };
  
  const handleDeleteStaff = (staffId: string) => {
    setItemToDelete(staffId);
  };

  const confirmDeleteStaff = () => {
    if (!itemToDelete) return;
    setStaff(prev => prev.filter(s => s.id !== itemToDelete));
    if (selectedStaffId === itemToDelete) {
        setSelectedStaffId(null);
    }
    setItemToDelete(null);
  };

  const handleSavePayment = (payment: { type: StaffPaymentType, amount: number, notes: string }) => {
    if (!selectedStaffId) return;
    const newPayment: StaffPayment = {
        id: crypto.randomUUID(),
        date: new Date().toISOString(),
        ...payment
    };
    setStaff(prev => prev.map(s => s.id === selectedStaffId ? { ...s, payments: [newPayment, ...s.payments] } : s));
    setModal(null);
    alert('Payment recorded!');
  };

  return (
    <div className="container mx-auto p-4 sm:p-6 lg:p-8 h-full">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
        {/* Left Panel: Staff List */}
        <div className="lg:col-span-1 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm flex flex-col h-[calc(100vh-10rem)]">
          <div className="p-4 border-b border-slate-200 dark:border-slate-700">
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">Staff Members</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400">Select a staff member to view details.</p>
            <div className="mt-4 flex items-center space-x-2">
              <div className="relative flex-grow">
                  <SearchIcon className="h-5 w-5 text-slate-400 absolute top-1/2 left-3 -translate-y-1/2" />
                  <input
                      type="text"
                      placeholder="Search staff..."
                      value={searchTerm}
                      onChange={e => setSearchTerm(e.target.value)}
                      className="pl-10 pr-4 py-2 w-full border border-slate-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-900 focus:ring-2 focus:ring-primary-500 focus:outline-none text-sm"
                  />
              </div>
              <button onClick={() => handleOpenAddModal()} className="flex-shrink-0 p-2 text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500">
                  <UserPlusIcon className="h-5 w-5" />
              </button>
            </div>
          </div>
          <div className="overflow-y-auto flex-1">
            {filteredStaff.length > 0 ? (
                <ul>
                    {filteredStaff.map(member => (
                        <li key={member.id} onClick={() => setSelectedStaffId(member.id)} className={`group relative p-4 border-b border-slate-200 dark:border-slate-700 cursor-pointer transition-colors ${selectedStaffId === member.id ? 'bg-primary-50 dark:bg-primary-900/50' : 'hover:bg-slate-50 dark:hover:bg-slate-700/50'}`}>
                           <div className="flex justify-between items-center">
                                <p className="font-semibold text-slate-800 dark:text-slate-100">{member.name}</p>
                                <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <button 
                                        onClick={(e) => { e.stopPropagation(); handleOpenAddModal(member); }} 
                                        className="p-2 text-slate-500 hover:text-primary-600 dark:hover:text-primary-400 rounded-full hover:bg-slate-200 dark:hover:bg-slate-600"
                                        aria-label={`Edit ${member.name}`}
                                    >
                                        <PencilIcon className="h-4 w-4" />
                                    </button>
                                    <button 
                                        onClick={(e) => { e.stopPropagation(); handleDeleteStaff(member.id); }} 
                                        className="p-2 text-slate-500 hover:text-red-600 dark:hover:text-red-400 rounded-full hover:bg-slate-200 dark:hover:bg-slate-600"
                                        aria-label={`Delete ${member.name}`}
                                    >
                                        <TrashIcon className="h-4 w-4" />
                                    </button>
                                </div>
                            </div>
                        </li>
                    ))}
                </ul>
            ) : (
                <p className="text-center p-8 text-slate-500 dark:text-slate-400">No staff members found.</p>
            )}
          </div>
        </div>

        {/* Right Panel: Staff Details */}
        <div className="lg:col-span-2 space-y-6">
          {selectedStaff ? (
            <>
              <div className="bg-white dark:bg-slate-800 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                 <div className="flex justify-between items-start">
                    <div>
                        <h3 className="text-2xl font-bold text-slate-800 dark:text-slate-100">{selectedStaff.name}</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">
                            {selectedStaff.contactNumbers.length > 0 ? selectedStaff.contactNumbers.join(', ') : 'No contact info'}
                        </p>
                    </div>
                    <div className="text-right">
                        <p className="text-sm text-slate-500 dark:text-slate-400">Monthly Salary</p>
                        <p className="text-3xl font-bold text-primary-600 dark:text-primary-400">Rs.{selectedStaff.monthlySalary.toFixed(2)}</p>
                    </div>
                 </div>
              </div>
              
              <div className="bg-white dark:bg-slate-800 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                 <div className="flex justify-between items-center">
                    <h4 className="text-xl font-bold text-slate-800 dark:text-slate-100">
                        Monthly Summary ({monthlySummary.payPeriod})
                    </h4>
                    <div className="flex items-center space-x-2">
                        <button
                            onClick={() => setModal('payment')}
                            className="px-3 py-1.5 text-sm font-semibold text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700"
                        >
                            Record Payment
                        </button>
                        <button
                            onClick={() => setModal('receipt')}
                            className="px-3 py-1.5 text-sm font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-700 rounded-md hover:bg-slate-200 dark:hover:bg-slate-600"
                        >
                            Generate Receipt
                        </button>
                    </div>
                 </div>
                 <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-700/50">
                        <p className="text-sm text-slate-500 dark:text-slate-400">Salary Paid</p>
                        <p className="text-xl font-bold text-slate-800 dark:text-slate-100">Rs.{monthlySummary.salaryPaid.toFixed(2)}</p>
                    </div>
                    <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-700/50">
                        <p className="text-sm text-slate-500 dark:text-slate-400">Advances</p>
                        <p className="text-xl font-bold text-slate-800 dark:text-slate-100">Rs.{monthlySummary.advances.toFixed(2)}</p>
                    </div>
                    <div className="p-4 rounded-lg bg-green-50 dark:bg-green-900/50">
                        <p className="text-sm text-green-600 dark:text-green-400">Net Payable</p>
                        <p className="text-xl font-bold text-green-800 dark:text-green-300">Rs.{monthlySummary.netPayable.toFixed(2)}</p>
                    </div>
                 </div>
              </div>
              <div className="bg-white dark:bg-slate-800 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                  <h4 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-4">Payment History</h4>
                  <div className="overflow-x-auto">
                      {selectedStaff.payments.length > 0 ? (
                      <table className="min-w-full text-sm">
                          <thead className="bg-slate-50 dark:bg-slate-700/50">
                              <tr>
                                  <th className="text-left font-medium p-2 text-slate-500 dark:text-slate-400">Date</th>
                                  <th className="text-left font-medium p-2 text-slate-500 dark:text-slate-400">Type</th>
                                  <th className="text-left font-medium p-2 text-slate-500 dark:text-slate-400">Notes</th>
                                  <th className="text-right font-medium p-2 text-slate-500 dark:text-slate-400">Amount</th>
                              </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                              {selectedStaff.payments.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(p => (
                                  <tr key={p.id}>
                                      <td className="p-2 whitespace-nowrap text-slate-500 dark:text-slate-400">{new Date(p.date).toLocaleDateString()}</td>
                                      <td className="p-2"><span className={`px-2 py-0.5 text-xs font-semibold rounded-full ${p.type === 'Salary' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300' : 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300'}`}>{p.type}</span></td>
                                      <td className="p-2 text-slate-700 dark:text-slate-200">{p.notes || '-'}</td>
                                      <td className="p-2 text-right font-semibold font-mono text-slate-800 dark:text-slate-100">Rs.{p.amount.toFixed(2)}</td>
                                  </tr>
                              ))}
                          </tbody>
                      </table>
                      ) : (
                          <p className="text-center p-8 text-slate-500 dark:text-slate-400">No payments found for this staff member.</p>
                      )}
                  </div>
              </div>
            </>
          ) : (
             <div className="bg-white dark:bg-slate-800 p-8 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm text-center h-full flex flex-col justify-center items-center">
                 <StaffIcon className="h-16 w-16 text-slate-300 dark:text-slate-600" />
                <h3 className="mt-4 text-xl font-semibold text-slate-800 dark:text-slate-100">Select a Staff Member</h3>
                <p className="mt-1 text-slate-500 dark:text-slate-400">Choose a staff member from the list to see their payment history and details.</p>
             </div>
          )}
        </div>
      </div>
      <AddStaffModal 
        isOpen={modal === 'add'} 
        onClose={() => setModal(null)} 
        onSave={handleSaveStaff} 
        staffToEdit={staffToEdit} 
      />
      {selectedStaff && (
        <>
            <RecordStaffPaymentModal 
                isOpen={modal === 'payment'} 
                onClose={() => setModal(null)} 
                onSave={handleSavePayment} 
                staff={selectedStaff} 
            />
            <SalaryReceiptModal
                isOpen={modal === 'receipt'}
                onClose={() => setModal(null)}
                staff={selectedStaff}
                advances={monthlySummary.advances}
                salaryPaid={monthlySummary.salaryPaid}
                payPeriod={monthlySummary.payPeriod}
                billSettings={billSettings}
            />
        </>
      )}
      <ConfirmationModal
        isOpen={!!itemToDelete}
        onClose={() => setItemToDelete(null)}
        onConfirm={confirmDeleteStaff}
        title="Delete Staff Member"
        message="Are you sure you want to delete this staff member? This will remove them and their payment history."
        requiresCode={true}
        securityCode={securityCode}
        confirmButtonText="Confirm Deletion"
      />
    </div>
  );
};

export default StaffPage;