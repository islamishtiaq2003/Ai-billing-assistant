import React, { useState, useMemo } from 'react';
import type { Customer, Product, Transaction, Invoice, BillSettings } from '../types.ts';
import SearchIcon from './icons/SearchIcon.tsx';
import UserPlusIcon from './icons/UserPlusIcon.tsx';
import DocumentTextIcon from './icons/DocumentTextIcon.tsx';
import CurrencyRupeeIcon from './icons/CurrencyRupeeIcon.tsx';
import AddCustomerModal from './modals/AddCustomerModal.tsx';
import LogClaimModal from './modals/LogClaimModal.tsx';
import RecordPaymentModal from './modals/RecordPaymentModal.tsx';
import CustomersIcon from './icons/CustomersIcon.tsx';
import PencilIcon from './icons/PencilIcon.tsx';
import TrashIcon from './icons/TrashIcon.tsx';
import ConfirmationModal from './modals/ConfirmationModal.tsx';
import ViewInvoiceModal from './modals/ViewInvoiceModal.tsx';

interface CustomersPageProps {
  customers: Customer[];
  setCustomers: React.Dispatch<React.SetStateAction<Customer[]>>;
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  securityCode: string;
  invoices: Invoice[];
  billSettings: BillSettings;
}

const CustomersPage: React.FC<CustomersPageProps> = ({ customers, setCustomers, products, setProducts, securityCode, invoices, billSettings }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);

  const [isAddModalOpen, setAddModalOpen] = useState(false);
  const [isClaimModalOpen, setClaimModalOpen] = useState(false);
  const [isPaymentModalOpen, setPaymentModalOpen] = useState(false);
  const [customerToEdit, setCustomerToEdit] = useState<Customer | null>(null);
  const [itemToDelete, setItemToDelete] = useState<string | null>(null);
  const [pendingBalanceChange, setPendingBalanceChange] = useState<{ customer: Customer; originalBalance: number } | null>(null);
  const [viewingInvoice, setViewingInvoice] = useState<Invoice | null>(null);

  const filteredCustomers = useMemo(() => {
    return customers.filter(customer =>
      customer.name.toLowerCase().includes(searchTerm.toLowerCase())
    ).sort((a, b) => b.balance - a.balance);
  }, [customers, searchTerm]);

  const selectedCustomer = useMemo(() => {
    return customers.find(c => c.id === selectedCustomerId) || null;
  }, [customers, selectedCustomerId]);

  const handleOpenAddModal = () => {
    setCustomerToEdit(null);
    setAddModalOpen(true);
  };

  const handleOpenEditModal = (customer: Customer) => {
    setCustomerToEdit(customer);
    setAddModalOpen(true);
  };

  const handleSaveCustomer = (customer: Customer) => {
    const originalCustomer = customers.find(c => c.id === customer.id);

    if (originalCustomer && originalCustomer.balance !== customer.balance) {
      setPendingBalanceChange({ customer, originalBalance: originalCustomer.balance });
    } else {
      setCustomers(prev => {
        const exists = prev.some(c => c.id === customer.id);
        if (exists) {
          return prev.map(c => (c.id === customer.id ? customer : c));
        }
        return [...prev, customer];
      });
    }
    setAddModalOpen(false);
  };

  const confirmBalanceChange = () => {
    if (!pendingBalanceChange) return;

    const { customer, originalBalance } = pendingBalanceChange;
    const adjustmentAmount = customer.balance - originalBalance;
    
    const adjustmentTransaction: Transaction = {
      id: crypto.randomUUID(),
      date: new Date().toISOString(),
      description: 'Manual Balance Adjustment',
      amount: adjustmentAmount,
      balanceAfter: customer.balance,
      type: 'adjustment',
    };

    setCustomers(prev => prev.map(c => 
      c.id === customer.id 
        ? { ...customer, transactions: [adjustmentTransaction, ...c.transactions] } 
        : c
    ));
    setPendingBalanceChange(null);
  };

  const handleDeleteCustomer = (customerId: string) => {
    setItemToDelete(customerId);
  };

  const confirmDeleteCustomer = () => {
    if (!itemToDelete) return;
    setCustomers(prevCustomers => prevCustomers.filter(c => c.id !== itemToDelete));
    if (selectedCustomerId === itemToDelete) {
      setSelectedCustomerId(null);
    }
    setItemToDelete(null);
  };
  
  const handleSaveClaim = ({ description, amount, replacementProductId }: { description: string; amount: number; replacementProductId?: string; }) => {
    if (!selectedCustomerId) return;
    
    const isImmediateResolution = amount !== 0 || !!replacementProductId;

    setCustomers(prev => prev.map(c => {
      if (c.id === selectedCustomerId) {
        let newBalance = c.balance;
        const transactionsToAdd: Transaction[] = [];

        if (amount !== 0) {
          newBalance += amount;
          transactionsToAdd.push({
            id: crypto.randomUUID(),
            date: new Date().toISOString(),
            description: `Claim: ${description}`,
            amount: amount,
            balanceAfter: newBalance,
            type: 'claim',
          });
        }
        
        if (replacementProductId) {
          const product = products.find(p => p.id === replacementProductId);
          if (product) {
            transactionsToAdd.push({
              id: crypto.randomUUID(),
              date: new Date().toISOString(),
              description: `Replacement Provided: ${product.name}`,
              amount: 0,
              balanceAfter: newBalance,
              type: 'claim',
            });
          }
        }

        const newClaim = {
            id: crypto.randomUUID(),
            date: new Date().toISOString(),
            description,
            amount,
            status: isImmediateResolution ? 'Resolved' as const : 'Pending' as const,
        };

        if (!isImmediateResolution) {
             transactionsToAdd.push({
                id: crypto.randomUUID(),
                date: new Date().toISOString(),
                description: `Claim Logged: ${description}`,
                amount: 0, 
                balanceAfter: c.balance,
                type: 'claim',
            });
        }

        return {
          ...c,
          balance: newBalance,
          claims: [newClaim, ...c.claims],
          transactions: [...transactionsToAdd, ...c.transactions],
        };
      }
      return c;
    }));
    
    if (replacementProductId) {
        setProducts(prev => prev.map(p => 
            p.id === replacementProductId ? { ...p, quantity: p.quantity - 1 } : p
        ));
    }

    setClaimModalOpen(false);
    alert(`Claim ${isImmediateResolution ? 'processed' : 'logged'} successfully!`);
  };


  const handleToggleClaimStatus = (claimId: string) => {
    if (!selectedCustomerId) return;
    setCustomers(prev => prev.map(c => {
        if (c.id === selectedCustomerId) {
            return {
                ...c,
                claims: c.claims.map(claim => 
                    claim.id === claimId 
                    ? { ...claim, status: claim.status === 'Pending' ? 'Resolved' : 'Pending' }
                    : claim
                )
            };
        }
        return c;
    }));
  };

  const handleSavePayment = (amount: number) => {
    if (!selectedCustomerId) return;
    
    setCustomers(prev => prev.map(c => {
        if (c.id === selectedCustomerId) {
            const newBalance = c.balance - amount;
            const newTransaction: Transaction = {
                id: crypto.randomUUID(),
                date: new Date().toISOString(),
                description: 'Payment Received',
                amount: -amount,
                balanceAfter: newBalance,
                type: 'payment',
            };
            return { ...c, balance: newBalance, transactions: [newTransaction, ...c.transactions] };
        }
        return c;
    }));
    
    setPaymentModalOpen(false);
    alert('Payment recorded successfully!');
  };

  return (
    <div className="container mx-auto p-4 sm:p-6 lg:p-8 h-full">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
        {/* Left Panel: Customer List */}
        <div className="lg:col-span-1 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm flex flex-col h-[calc(100vh-10rem)]">
          <div className="p-4 border-b border-slate-200 dark:border-slate-700">
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">Customers</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400">Select a customer to view details.</p>
            <div className="mt-4 flex items-center space-x-2">
              <div className="relative flex-grow">
                  <SearchIcon className="h-5 w-5 text-slate-400 absolute top-1/2 left-3 -translate-y-1/2" />
                  <input
                      type="text"
                      placeholder="Search customers..."
                      value={searchTerm}
                      onChange={e => setSearchTerm(e.target.value)}
                      className="pl-10 pr-4 py-2 w-full border border-slate-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-900 focus:ring-2 focus:ring-primary-500 focus:outline-none text-sm"
                  />
              </div>
              <button onClick={handleOpenAddModal} className="flex-shrink-0 p-2 text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500">
                  <UserPlusIcon className="h-5 w-5" />
              </button>
            </div>
          </div>
          <div className="overflow-y-auto flex-1">
            {filteredCustomers.length > 0 ? (
                <ul>
                    {filteredCustomers.map(customer => (
                        <li key={customer.id} onClick={() => setSelectedCustomerId(customer.id)} className={`group relative p-4 border-b border-slate-200 dark:border-slate-700 cursor-pointer transition-colors ${selectedCustomerId === customer.id ? 'bg-primary-50 dark:bg-primary-900/50' : 'hover:bg-slate-50 dark:hover:bg-slate-700/50'}`}>
                            <p className="font-semibold text-slate-800 dark:text-slate-100">{customer.name}</p>
                            <p className="text-sm text-slate-500 dark:text-slate-400">Balance: Rs.{customer.balance.toFixed(2)}</p>
                             <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button onClick={(e) => { e.stopPropagation(); handleOpenEditModal(customer); }} className="p-2 text-slate-500 hover:text-primary-600 dark:hover:text-primary-400 rounded-full hover:bg-slate-200 dark:hover:bg-slate-600" aria-label={`Edit ${customer.name}`}><PencilIcon className="h-4 w-4" /></button>
                                <button onClick={(e) => { e.stopPropagation(); handleDeleteCustomer(customer.id); }} className="p-2 text-slate-500 hover:text-red-600 dark:hover:text-red-400 rounded-full hover:bg-slate-200 dark:hover:bg-slate-600" aria-label={`Delete ${customer.name}`}><TrashIcon className="h-4 w-4" /></button>
                            </div>
                        </li>
                    ))}
                </ul>
            ) : (
                <p className="text-center p-8 text-slate-500 dark:text-slate-400">No customers found.</p>
            )}
          </div>
        </div>

        {/* Right Panel: Customer Details */}
        <div className="lg:col-span-2 space-y-6 overflow-y-auto h-[calc(100vh-8.5rem)] pr-2">
          {selectedCustomer ? (
            <>
              <div className="bg-white dark:bg-slate-800 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                 <div className="flex justify-between items-start">
                    <div>
                        <h3 className="text-2xl font-bold text-slate-800 dark:text-slate-100">{selectedCustomer.name}</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">{selectedCustomer.contactNumbers.length > 0 ? selectedCustomer.contactNumbers.join(', ') : 'No contact info'}</p>
                    </div>
                    <div className="text-right">
                        <p className="text-sm text-slate-500 dark:text-slate-400">Current Balance</p>
                        <p className={`text-3xl font-bold ${selectedCustomer.balance > 0 ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>Rs.{selectedCustomer.balance.toFixed(2)}</p>
                    </div>
                 </div>
                 <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-700 flex flex-wrap gap-2">
                    <button onClick={() => setClaimModalOpen(true)} className="flex items-center space-x-2 px-3 py-2 text-sm text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-700 rounded-md hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors"><DocumentTextIcon className="h-5 w-5" /><span>Log a Claim</span></button>
                    <button onClick={() => setPaymentModalOpen(true)} className="flex items-center space-x-2 px-3 py-2 text-sm text-white bg-green-600 rounded-md hover:bg-green-700 transition-colors"><CurrencyRupeeIcon className="h-5 w-5" /><span>Record Payment</span></button>
                 </div>
              </div>
              <div className="bg-white dark:bg-slate-800 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                  <h4 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-4">Transaction History</h4>
                   <div className="overflow-x-auto">
                    {selectedCustomer.transactions.length > 0 ? (
                      <table className="min-w-full text-sm">
                       <thead className="bg-slate-50 dark:bg-slate-700/50"><tr><th className="text-left font-medium p-2 text-slate-500 dark:text-slate-400">Date</th><th className="text-left font-medium p-2 text-slate-500 dark:text-slate-400">Description</th><th className="text-right font-medium p-2 text-slate-500 dark:text-slate-400">Debit</th><th className="text-right font-medium p-2 text-slate-500 dark:text-slate-400">Credit</th><th className="text-right font-medium p-2 text-slate-500 dark:text-slate-400">Balance</th></tr></thead>
                       <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                          {[...selectedCustomer.transactions].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(tx => {
                            const isInvoice = tx.type === 'invoice' && tx.relatedId;
                            return(
                                <tr key={tx.id} onClick={() => { if(isInvoice) { const inv = invoices.find(i => i.id === tx.relatedId); if(inv) setViewingInvoice(inv); }}} className={isInvoice ? 'cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700' : ''}>
                                <td className="p-2 whitespace-nowrap text-slate-500 dark:text-slate-400">{new Date(tx.date).toLocaleDateString()}</td>
                                <td className={`p-2 text-slate-700 dark:text-slate-200 ${isInvoice ? 'font-semibold text-primary-600 dark:text-primary-400' : ''}`}>{tx.description}</td>
                                <td className="p-2 text-right font-mono text-red-600 dark:text-red-400">{tx.amount > 0 ? tx.amount.toFixed(2) : '-'}</td>
                                <td className="p-2 text-right font-mono text-green-600 dark:text-green-400">{tx.amount < 0 ? (-tx.amount).toFixed(2) : '-'}</td>
                                <td className="p-2 text-right font-semibold font-mono text-slate-800 dark:text-slate-100">Rs.{tx.balanceAfter.toFixed(2)}</td>
                               </tr>
                           )})}
                       </tbody>
                      </table>
                    ) : (
                       <p className="text-center p-8 text-slate-500 dark:text-slate-400">No transactions found</p>
                    )}
                 </div>
              </div>
               <div className="bg-white dark:bg-slate-800 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                  <h4 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-4">Claim History</h4>
                  <div className="overflow-x-auto">
                    {selectedCustomer.claims.length > 0 ? (
                      <table className="min-w-full text-sm">
                       <thead className="bg-slate-50 dark:bg-slate-700/50"><tr><th className="text-left font-medium p-2 text-slate-500 dark:text-slate-400">Date</th><th className="text-left font-medium p-2 text-slate-500 dark:text-slate-400">Description</th><th className="text-right font-medium p-2 text-slate-500 dark:text-slate-400">Amount</th><th className="text-center font-medium p-2 text-slate-500 dark:text-slate-400">Status</th></tr></thead>
                       <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                          {selectedCustomer.claims.map(claim => (<tr key={claim.id}><td className="p-2 whitespace-nowrap text-slate-500 dark:text-slate-400">{new Date(claim.date).toLocaleDateString()}</td><td className="p-2 text-slate-700 dark:text-slate-200">{claim.description}</td><td className="p-2 text-right font-semibold font-mono text-slate-800 dark:text-slate-100">Rs.{claim.amount.toFixed(2)}</td><td className="p-2 text-center">{claim.status === 'Pending' ? (<button onClick={() => handleToggleClaimStatus(claim.id)} className="px-2 py-0.5 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300 hover:bg-yellow-200">{claim.status}</button>) : (<span className="px-2 py-0.5 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">{claim.status}</span>)}</td></tr>))}</tbody>
                      </table>
                    ) : (
                       <p className="text-center p-8 text-slate-500 dark:text-slate-400">No claims found</p>
                    )}
                  </div>
              </div>
            </>
          ) : (
             <div className="bg-white dark:bg-slate-800 p-8 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm text-center h-full flex flex-col justify-center items-center">
                 <CustomersIcon className="h-16 w-16 text-slate-300 dark:text-slate-600" />
                <h3 className="mt-4 text-xl font-semibold text-slate-800 dark:text-slate-100">Select a Customer</h3>
                <p className="mt-1 text-slate-500 dark:text-slate-400">Choose a customer from the list to see their transaction history and details.</p>
             </div>
          )}
        </div>
      </div>
      <AddCustomerModal isOpen={isAddModalOpen} onClose={() => setAddModalOpen(false)} onSave={handleSaveCustomer} customerToEdit={customerToEdit} />
      {selectedCustomer && (<><LogClaimModal isOpen={isClaimModalOpen} onClose={() => setClaimModalOpen(false)} onSave={handleSaveClaim} party={selectedCustomer} products={products} partyType="customer" /><RecordPaymentModal isOpen={isPaymentModalOpen} onClose={() => setPaymentModalOpen(false)} onSave={handleSavePayment} party={selectedCustomer} /></>)}
      <ConfirmationModal isOpen={!!itemToDelete} onClose={() => setItemToDelete(null)} onConfirm={confirmDeleteCustomer} title="Delete Customer" message="Are you sure you want to delete this customer? This action cannot be undone." requiresCode securityCode={securityCode} confirmButtonText="Confirm Deletion" />
      <ConfirmationModal isOpen={!!pendingBalanceChange} onClose={() => setPendingBalanceChange(null)} onConfirm={confirmBalanceChange} title="Confirm Balance Change" message={`You are about to manually change the balance for ${pendingBalanceChange?.customer.name}. This will be recorded as a new transaction. Please confirm.`} requiresCode securityCode={securityCode} confirmButtonText="Confirm Change" />
      {viewingInvoice && <ViewInvoiceModal isOpen={!!viewingInvoice} onClose={() => setViewingInvoice(null)} invoice={viewingInvoice} billSettings={billSettings} />}
    </div>
  );
};

export default CustomersPage;