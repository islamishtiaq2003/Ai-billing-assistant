import React from 'react';
import type { Page } from '../App.tsx';

import DashboardIcon from './icons/DashboardIcon.tsx';
import InventoryIcon from './icons/InventoryIcon.tsx';
import BillingIcon from './icons/BillingIcon.tsx';
import CustomersIcon from './icons/CustomersIcon.tsx';
import VendorsIcon from './icons/VendorsIcon.tsx';
import StaffIcon from './icons/StaffIcon.tsx';
import ExpensesIcon from './icons/ExpensesIcon.tsx';
import SettingsIcon from './icons/SettingsIcon.tsx';
import LockIcon from './icons/LockIcon.tsx';

const menuItems: { name: Page, icon: React.FC<React.SVGProps<SVGSVGElement>> }[] = [
  { name: 'Dashboard', icon: DashboardIcon },
  { name: 'Inventory', icon: InventoryIcon },
  { name: 'Billing', icon: BillingIcon },
  { name: 'Customers', icon: CustomersIcon },
  { name: 'Vendors', icon: VendorsIcon },
  { name: 'Staff', icon: StaffIcon },
  { name: 'My Expenses', icon: ExpensesIcon },
  { name: 'Settings', icon: SettingsIcon },
];

const lockedPages: Page[] = ['Dashboard', 'Vendors', 'Staff', 'My Expenses'];

interface SidebarProps {
  activeItem: Page;
  onSelectItem: (page: Page) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeItem, onSelectItem }) => {
  return (
    <aside className="w-64 bg-white dark:bg-gray-900 p-4 flex flex-col flex-shrink-0 border-r border-gray-200 dark:border-gray-800">
      <nav aria-label="Main navigation">
        <ul className="flex-1 space-y-2">
          {menuItems.map((item) => (
            <li key={item.name}>
              <a
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onSelectItem(item.name);
                }}
                className={`
                  flex items-center p-3 rounded-lg text-sm font-medium transition-colors
                  ${item.name === activeItem
                    ? 'bg-primary-100 text-primary-700 dark:bg-primary-900/50 dark:text-primary-300'
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                  }
                `}
                aria-current={item.name === activeItem ? 'page' : undefined}
              >
                <item.icon className="h-6 w-6 mr-3 flex-shrink-0" aria-hidden="true" />
                <span className="flex-1">{item.name}</span>
                {lockedPages.includes(item.name) && <LockIcon className="h-4 w-4 text-gray-400 dark:text-gray-500 flex-shrink-0" aria-label="Locked page" />}
              </a>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;