import React, { useState, useEffect, useMemo } from 'react';
import type { Invoice, LineItem } from '../types.ts';
import { InvoiceStatus } from '../types.ts';
import { generateDescription } from '../services/geminiService.ts';
import TrashIcon from './icons/TrashIcon.tsx';
import PlusIcon from './icons/PlusIcon.tsx';
import SparklesIcon from './icons/SparklesIcon.tsx';

interface InvoiceFormProps {
  invoice: Invoice | null;
  onSave: (invoice: Invoice) => void;
  onCancel: () => void;
}

const createNewInvoiceData = (): Omit<Invoice, 'id' | 'grandTotal'> => ({
  invoiceNumber: `INV-${Date.now().toString().slice(-6)}`,
  customerName: '',
  invoiceDate: new Date().toISOString().split('T')[0],
  dueDate: new Date(new Date().setDate(new Date().getDate() + 30)).toISOString().split('T')[0],
  items: [{ id: crypto.randomUUID(), name: '', quantity: 1, price: 0 }],
  status: InvoiceStatus.Draft,
  type: 'Retail',
});

const InvoiceForm: React.FC<InvoiceFormProps> = ({ invoice, onSave, onCancel }) => {
  const [formData, setFormData] = useState(createNewInvoiceData());
  const [aiLoading, setAiLoading] = useState<string | null>(null); // holds the id of the item being processed

  useEffect(() => {
    if (invoice) {
      const { id, grandTotal, ...invoiceData } = invoice;
      setFormData(invoiceData);
    } else {
      setFormData(createNewInvoiceData());
    }
  }, [invoice]);

  const subtotal = useMemo(() => {
    return formData.items.reduce((sum, item) => sum + (item.quantity * item.price || 0), 0);
  }, [formData.items]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleItemChange = (itemId: string, field: keyof Omit<LineItem, 'id'>, value: string | number) => {
    setFormData((prev) => ({
      ...prev,
      items: prev.items.map((item) => (item.id === itemId ? { ...item, [field]: value } : item)),
    }));
  };

  const addItem = () => {
    setFormData((prev) => ({
      ...prev,
      items: [...prev.items, { id: crypto.randomUUID(), name: '', quantity: 1, price: 0 }],
    }));
  };

  const removeItem = (itemId: string) => {
    setFormData((prev) => ({
      ...prev,
      items: prev.items.filter((item) => item.id !== itemId),
    }));
  };
  
  const handleGenerateDescription = async (item: LineItem) => {
    if (!item.name.trim()) {
        alert("Please enter a basic product or service name first.");
        return;
    }
    setAiLoading(item.id);
    try {
        const generatedText = await generateDescription(item.name);
        handleItemChange(item.id, 'name', generatedText);
    } catch (error) {
        alert((error as Error).message);
    } finally {
        setAiLoading(null);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const invoiceToSave: Invoice = {
        ...formData,
        id: invoice?.id || crypto.randomUUID(),
        grandTotal: subtotal,
    };
    onSave(invoiceToSave);
  };

  return (
    <div className="container mx-auto p-4 sm:p-6 lg:p-8">
      <form onSubmit={handleSubmit} className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-lg space-y-8">
        <div className="flex justify-between items-center border-b border-gray-200 dark:border-gray-700 pb-6">
            <h2 className="text-3xl font-bold text-gray-800 dark:text-gray-100">{invoice ? 'Edit Invoice' : 'New Invoice'}</h2>
            <div>
                 <button type="button" onClick={onCancel} className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-200 bg-gray-100 dark:bg-gray-700 rounded-md hover:bg-gray-200 dark:hover:bg-gray-600 mr-2 transition-colors">Cancel</button>
                 <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">Save Invoice</button>
            </div>
        </div>

        {/* Invoice Header */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label htmlFor="customerName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Customer Name</label>
            <input type="text" name="customerName" id="customerName" value={formData.customerName} onChange={handleInputChange} required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
                <label htmlFor="invoiceNumber" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Invoice #</label>
                <input type="text" name="invoiceNumber" id="invoiceNumber" value={formData.invoiceNumber} onChange={handleInputChange} required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm" />
            </div>
             <div>
                <label htmlFor="status" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Status</label>
                <select id="status" name="status" value={formData.status} onChange={handleInputChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md">
                    {Object.values(InvoiceStatus).map(status => <option key={status} value={status}>{status}</option>)}
                </select>
             </div>
          </div>
           <div className="grid grid-cols-2 gap-4">
            <div>
                <label htmlFor="invoiceDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Invoice Date</label>
                <input type="date" name="invoiceDate" id="invoiceDate" value={formData.invoiceDate} onChange={handleInputChange} required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm" />
            </div>
            <div>
                <label htmlFor="dueDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Due Date</label>
                <input type="date" name="dueDate" id="dueDate" value={formData.dueDate} onChange={handleInputChange} required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm" />
            </div>
           </div>
        </div>
        
        {/* Line Items */}
        <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-200 border-b border-gray-200 dark:border-gray-700 pb-2">Items</h3>
            {formData.items.map((item) => (
                <div key={item.id} className="grid grid-cols-12 gap-x-4 items-center">
                    <div className="col-span-6">
                        <label htmlFor={`name-${item.id}`} className="sr-only">Item Name</label>
                        <div className="relative">
                            <input type="text" id={`name-${item.id}`} value={item.name} onChange={(e) => handleItemChange(item.id, 'name', e.target.value)} placeholder="Item Name or Description" className="block w-full px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm pr-10"/>
                             <button type="button" onClick={() => handleGenerateDescription(item)} disabled={aiLoading === item.id} className="absolute inset-y-0 right-0 flex items-center pr-3 text-primary-500 hover:text-primary-700 disabled:opacity-50 disabled:cursor-wait" aria-label="Generate description with AI">
                                {aiLoading === item.id ? (
                                    <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                                ) : <SparklesIcon className="h-5 w-5" />}
                            </button>
                        </div>
                    </div>
                    <div className="col-span-2">
                        <label htmlFor={`quantity-${item.id}`} className="sr-only">Quantity</label>
                        <input type="number" id={`quantity-${item.id}`} value={item.quantity} onChange={(e) => handleItemChange(item.id, 'quantity', parseFloat(e.target.value) || 0)} className="block w-full px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm" />
                    </div>
                    <div className="col-span-2">
                         <label htmlFor={`price-${item.id}`} className="sr-only">Price</label>
                        <input type="number" id={`price-${item.id}`} value={item.price} onChange={(e) => handleItemChange(item.id, 'price', parseFloat(e.target.value) || 0)} className="block w-full px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm" />
                    </div>
                     <div className="col-span-1 text-right text-sm text-gray-600 dark:text-gray-300 font-medium">
                        Rs.{(item.quantity * item.price).toFixed(2)}
                    </div>
                    <div className="col-span-1 flex justify-end">
                        <button type="button" onClick={() => removeItem(item.id)} className="text-gray-400 hover:text-red-500 transition-colors p-1" aria-label="Remove item">
                            <TrashIcon className="h-5 w-5" />
                        </button>
                    </div>
                </div>
            ))}
             <button type="button" onClick={addItem} className="flex items-center space-x-2 px-4 py-2 text-sm text-primary-600 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/50 rounded-lg hover:bg-primary-100 dark:hover:bg-primary-900/80 focus:outline-none focus:ring-2 focus:ring-primary-500 transition-colors">
                 <PlusIcon className="h-5 w-5" />
                 <span>Add Item</span>
             </button>
        </div>

        {/* Total */}
        <div className="flex justify-end">
            <div className="w-full md:w-1/3">
                <div className="flex justify-between py-2 border-b border-gray-200 dark:border-gray-700">
                    <span className="text-gray-600 dark:text-gray-300">Subtotal</span>
                    <span className="font-medium text-gray-800 dark:text-gray-100">Rs.{subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-gray-200 dark:border-gray-700">
                    <span className="text-gray-600 dark:text-gray-300">Tax (0%)</span>
                    <span className="font-medium text-gray-800 dark:text-gray-100">Rs.0.00</span>
                </div>
                <div className="flex justify-between pt-4">
                    <span className="text-xl font-bold text-gray-900 dark:text-gray-50">Total</span>
                    <span className="text-xl font-bold text-gray-900 dark:text-gray-50">Rs.{subtotal.toFixed(2)}</span>
                </div>
            </div>
        </div>
      </form>
    </div>
  );
};

export default InvoiceForm;